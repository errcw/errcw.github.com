package ca.ericw.dungeon;

import java.util.Arrays;
import java.util.Random;
import java.util.Stack;

/**
 * Constructs randomised dungeons layouts.
 */
public class DungeonGenerator {
    
    /**
     * Test entry point.
     */
    public static void main (String[] args) {
        DungeonGenerator dg = new DungeonGenerator();
        dg.setStraightness(70);
        dg.setSparseness(6);
        dg.setRoomCount(10);
        dg.setRoomMaxHeight(5);
        dg.setRoomMaxWidth(5);
        
        FloorType[][] d = dg.generate(25, 25);
        
        // toss the dungeon to stdout
        for(int i = 0; i < d.length; i++) {
            for(int j = 0; j < d[i].length; j++) {
                switch(d[i][j]) {
                    case WALL:  System.out.print('#'); break;
                    case FLOOR: System.out.print('.'); break;
                    case ROOM:  System.out.print(' '); break;
                    case FRESH: System.out.print('*'); break;
                    
                }
            }
            System.out.println();
        }
    }
    
    /** Type of floor occupying a certain position in a dungeon */
    public enum FloorType { WALL, FLOOR, ROOM, FRESH };
    
    /**
     * Creates a new dungeon generator with a random seed.
     */
    public DungeonGenerator () {
        this(System.currentTimeMillis());
    }
    
    /**
     * Creates a new dungeon generator.
     * @param seed seed value for the random number generator
     */
    public DungeonGenerator (long seed) {
        _random = new Random(seed);
        _twistPercent = 50;
        _sparseness = 1;
        _roomCount = 1;
        _roomMinWidth = 5;
        _roomMaxWidth = 10;
        _roomMinHeight = 5;
        _roomMaxHeight = 10;
    }
    
    /**
     * Sets how straight the dungeon corridors should be.
     * @param straightness a number between 0 and 100 inclusive
     */
    public void setStraightness (int straightness) {
        _twistPercent = 100 - straightness;
    }
    
    /**
     * Sets how sparsely the dungeon corridors should occur. Default is one.
     */
    public void setSparseness (int sparseness) {
        this._sparseness = sparseness;
    }
    
    /**
     * Sets the number of rooms to be generated in the dungeon.
     */
    public void setRoomCount (int rooms) {
        _roomCount = rooms;
    }
    
    /**
     * Sets the maximum width for rooms. The minimum width is half of the
     * maximum.
     */
    public void setRoomMaxWidth (int maxWidth) {
        _roomMaxWidth = maxWidth;
        _roomMinWidth = maxWidth / 2;
    }
    
    /**
     * Sets the maximum height for rooms. The minimum height is half of the
     * maximum.
     */
    public void setRoomMaxHeight (int maxHeight) {
        _roomMaxHeight = maxHeight;
        _roomMinHeight = maxHeight  / 2;
    }
    
    /**
     * Generates a new random dungeon layout.
     * @param width width of the dungeon environs, in cells; must be odd
     * @param height height of the dungeon environs, in cells; must be odd
     * @return a description of the dungeon
     */
    public FloorType[][] generate (int width, int height) {
        if ((width % 2 == 0) || (height % 2 == 0)) {
            throw new IllegalArgumentException("Width and height must be odd");
        }
        
        _dungeon = new FloorType[height][width];
        
        initializeBlank();
        mazeify();
        sparseify();
        addRooms();
        
        return _dungeon;
    }
    
    /**
     * Creates a grid of cells.
     */
    private void initializeBlank () {
        // blank out the entire area
        for(int i = 0; i < _dungeon.length; i++) {
            Arrays.fill(_dungeon[i], FloorType.WALL);
        }
        
        // now punch holes in it to represent cells
        for(int y = 1; y < _dungeon.length; y += 2) {
            for(int x = 1; x < _dungeon[y].length; x += 2) {
                _dungeon[y][x] = FloorType.FRESH;
            }
        }
    }
    
    /**
     * Creates a maze out of a blank dungeon. The maze is orthogonal (all
     * intersections occur at right angles) and perfect (no loops or
     * inaccessible areas). The maze is generated using a recursive
     * backtracking algorithm.
     */
    private void mazeify () {
        Stack<Coord> backtracker = new Stack<Coord>();
        Coord cur = new Coord(1, 1);
        Direction d = Direction.SOUTH;
        
        do {
            // mark the current cell visited
            _dungeon[cur.y][cur.x] = FloorType.FLOOR;
            
            if (hasUnvisited(cur)) {
                // push the current cell on to the stack
                backtracker.push(cur);
                
                // choose one of the unvisited directions
                if (!isUnvisited(cur, d) || _random.nextInt(100) < _twistPercent) {
                    do {
                        d = Direction.values()[_random.nextInt(4)];
                    } while(!isUnvisited(cur, d));
                }
                
                // knock down the wall between the cells,
                // and make the chosen cell the current one
                int dx = 0, dy = 0;
                switch(d) {
                    case NORTH: dx = 0; dy = -1; break;
                    case EAST:  dx = 1; dy = 0; break;
                    case SOUTH: dx = 0; dy = 1; break;
                    case WEST:  dx = -1; dy = 0; break;
                }
                    
                _dungeon[cur.y + dy][cur.x + dx] = FloorType.FLOOR;
                cur = new Coord(cur.x + (2*dx), cur.y + (2*dy));
                
            } else {
                // no available cells, so backtrack
                cur = backtracker.pop();
            }
            
        } while (!backtracker.isEmpty());
    }
    
    /**
     * Fills in dead ends to create a more sparse dungeon maze. The filling
     * process is iterated sparseness times.
     */
    private void sparseify () {
        for(int i = 0; i < _sparseness; i++) {
            
            // mark all the dead end cells
            for(int y = 1; y < _dungeon.length; y += 2) {
                for(int x = 1; x < _dungeon[y].length; x += 2) {
                    Coord crd = new Coord(x, y);
                    if (getDeadEndDirection(crd) != null) {
                        _dungeon[y][x] = FloorType.FRESH;
                    }
                }
            }
            
            // fill in all the dead ends
            for(int y = 1; y < _dungeon.length; y += 2) {
                for(int x = 1; x < _dungeon[y].length; x += 2) {
                    // found a marked dead end
                    if (_dungeon[y][x] == FloorType.FRESH) {
                        Coord pos = new Coord(x, y);
                        Direction dir = getDeadEndDirection(pos);
                        
                        // cx/cy: direction to check for corridor walls
                        // dx/dy: direction to move to fill in the corridor
                        int cx = 0, cy = 0, dx = 0, dy = 0;
                        switch(dir) {
                            case NORTH: cx = 1; cy = 0; dx = 0; dy = -1; break;
                            case EAST:  cx = 0; cy = 1; dx = 1; dy = 0; break;
                            case SOUTH: cx = 1; cy = 0; dx = 0; dy = 1; break;
                            case WEST:  cx = 0; cy = 1; dx = -1; dy = 0; break;
                        }
                        
                        while (_dungeon[pos.y + cy][pos.x + cx] == FloorType.WALL &&
                               _dungeon[pos.y - cy][pos.x - cx] == FloorType.WALL) {
                            _dungeon[pos.y][pos.x] = FloorType.WALL;
                            pos.x += dx;
                            pos.y += dy;
                        }
                    }
                }
            }
            
        }
    }
    
    /**
     * Adds rooms to the dungeon.
     */
    private void addRooms () {
        for(int i = 0; i < _roomCount; i++) {
            // randomise the size of the room
            int width = _random.nextInt(_roomMaxWidth - _roomMinWidth + 1) + _roomMinWidth;
            int height = _random.nextInt(_roomMaxHeight - _roomMinHeight + 1) + _roomMinHeight;
            
            // find the optimal placement
            Coord c = getRoomPlacement(width, height);
            
            // lay down the room
            for(int y = 0; y < height; y++) {
                for(int x = 0; x < width; x++) {
                    _dungeon[c.y + y][c.x + x] = FloorType.ROOM;
                }
            }
        }
    }
    
    private Coord getRoomPlacement (int width, int height) {
        int bestScore = Integer.MAX_VALUE;
        Coord bestCoord = new Coord(1, 1);
        
        // check all positions
        for(int y = 1; y < _dungeon.length - height; y += 2) {
            for(int x = 1; x < _dungeon[y].length - width; x += 2) {
                Coord pos = new Coord(x, y);
                
                // evaluate the score at this position
                int score = getRoomPlacementScore(pos, width, height);
                
                // replace the coord if we found a better spot
                if (score > 0 && score < bestScore) {
                    bestScore = score;
                    bestCoord = pos;
                }
            }
        }
        
        return bestCoord;
    }
    
    /**
     * Returns the goodness of placing a room at the given location. A lower
     * relative score indicates a better candidate position.
     */
    private int getRoomPlacementScore (Coord placement, int width, int height) {
        int score = 0;
        
        for(int x = -1; x < width+1; x++) {
            for(int y = -1; y < height+1; y++) {
                // discard the diagonal positions
                if (x == -1 && y == -1     ||
                    x == -1 && y == height ||
                    x == width && y == -1  ||
                    x == width && y == height) {
                    continue;
                }
                
                if (_dungeon[placement.y + y][placement.x + x] == FloorType.ROOM) {
                    // strongly disfavour overlapping rooms
                    score += 100;
                } else if (_dungeon[placement.y + y][placement.x + x] == FloorType.FLOOR) {
                    // mildly disfavour overlapping corridors over those entering the room
                    score += (x == -1 || y == -1 || x == width || y == height) ? 1 : 3;
                }
            }
        }
        
        return score;
    }
    
    /**
     * Returns true if and only if the cell in the direction from the start
     * coordinate is unvisited.
     */
    private boolean isUnvisited (Coord start, Direction dir) {
        int dx = 0, dy = 0;
        switch(dir) {
            case NORTH: dx = 0; dy = -2; break;
            case EAST:  dx = 2; dy = 0; break;
            case SOUTH: dx = 0; dy = 2; break;
            case WEST:  dx = -2; dy = 0; break;
        }
        
        // make sure we're not looking outside the dungeon environs
        if (start.x + dx < 0 || start.x + dx >= _dungeon[0].length ||
            start.y + dy < 0 || start.y + dy >= _dungeon.length) {
            return false;
        }
        
        // now simply check that the coord is fresh
        return _dungeon[start.y + dy][start.x + dx] == FloorType.FRESH;
    }
    
    /**
     * Returns true if and only if there is an unvisited cell to the north,
     * east, south, or west of the starting coordinate.
     */
    private boolean hasUnvisited (Coord start) {
        return isUnvisited(start, Direction.NORTH) ||
               isUnvisited(start, Direction.EAST)  ||
               isUnvisited(start, Direction.SOUTH) ||
               isUnvisited(start, Direction.WEST);
    }
    
    /**
     * Returns the opening direction if the specified coordinate is a dead end.
     * A dead end is a cell such that all sides but one are surrounded by wall.
     * If the coordinate is not a dead end, this method returns null.
     */
    private Direction getDeadEndDirection (Coord coord) {
        // four cases for deadend-ness... bah.
        
        // opening to the north
        if (_dungeon[coord.y-1][coord.x] == FloorType.FLOOR &&
            _dungeon[coord.y+1][coord.x] == FloorType.WALL &&
            _dungeon[coord.y][coord.x-1] == FloorType.WALL &&
            _dungeon[coord.y][coord.x+1] == FloorType.WALL) {
            return Direction.NORTH;
        }
        
        // opening to the east
        if (_dungeon[coord.y][coord.x+1] == FloorType.FLOOR &&
            _dungeon[coord.y+1][coord.x] == FloorType.WALL &&
            _dungeon[coord.y-1][coord.x] == FloorType.WALL &&
            _dungeon[coord.y][coord.x-1] == FloorType.WALL) {
            return Direction.EAST;
        }
        
        // opening to the south
        if (_dungeon[coord.y+1][coord.x] == FloorType.FLOOR &&
            _dungeon[coord.y-1][coord.x] == FloorType.WALL &&
            _dungeon[coord.y][coord.x-1] == FloorType.WALL &&
            _dungeon[coord.y][coord.x+1] == FloorType.WALL) {
            return Direction.SOUTH;
        }
        
        // opening to the west
        if (_dungeon[coord.y][coord.x-1] == FloorType.FLOOR &&
            _dungeon[coord.y+1][coord.x] == FloorType.WALL &&
            _dungeon[coord.y-1][coord.x] == FloorType.WALL &&
            _dungeon[coord.y][coord.x+1] == FloorType.WALL) {
            return Direction.WEST;
        }        
        
        return null;
    }
    
    /**
     * Represents a position in the dungeon.
     */
    private class Coord {
        public int x;
        public int y;
        public Coord(int x, int y) { this.x = x; this.y = y; }
    }
    
    private enum Direction { NORTH, EAST, SOUTH, WEST };
    
    private FloorType[][] _dungeon;
    
    private Random _random;
    
    private int _twistPercent;
    private int _sparseness;
    private int _roomCount;
    private int _roomMinWidth, _roomMaxWidth;
    private int _roomMinHeight, _roomMaxHeight;
}

the void README // 2004-06-08

the void � 2004 Eric Industries Conglomerate. All rights reserved.

------------------------------------------------
Video Requirements
------------------------------------------------
the void requires a video card with full OpenGL support.  99% of all problems experienced with the void are because of video drivers.  Windows XP does not install OpenGL drivers.  If the void is not working correctly, running very slowly, exiting or crashing at new screens, or the mouse is very jerky You need to install video drivers from your video card install CD, or even better download the latest drivers from your video card manufacturers web site.

------------------------------------------------
System Requirements
------------------------------------------------
Minimum:
Java 1.4.2_03 (must be in your PATH for the run!.bat file to work correctly)
Windows 98/ME/2000/XP, Linux
AMD or Intel 400 MHz processor or better 
OpenGL video card with 8 MB of memory
64MB of free memory

------------------------------------------------
the void
------------------------------------------------
Your objective is simple: avoid being sucked into the star in the lower left corner of the screen. To survive, you will need to use mass ejection to change your velocity. Simply hold down the mass launch key and then release. The longer you hold the key down, the faster the mass will be launched. Use the masses to ram your opponent or give yourself a boost. Last man standing wins!

------------------------------------------------
Credits
------------------------------------------------
Eric Woroshow
-with-
Matthew Stannard
Hemesh Yasotharan
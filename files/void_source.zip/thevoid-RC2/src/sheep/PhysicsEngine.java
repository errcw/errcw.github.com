package sheep;

import org.lwjgl.util.vector.Vector2f;

import sheep.attributes.*;

/**
 * @author Hemesh
 */
public class PhysicsEngine {
    
    private static float G;
    private static Vector2f starpos;
    private static int starmass, shipmass, ejectmass;
    
    public static float STAR_GRAVITY = 5.0f;
    
    /**
     * 
     * @param maxdis the masximum distance from the star
     * @throws Exception the Resources
     */
    public static void init (float maxdis) throws Exception{
        StarAttributes star = (StarAttributes) Resources.get("normal.star");
        ShipAttributes ship = (ShipAttributes) Resources.get("basic.ship");
        starpos = star.getPosition();
        starmass = star.getMass();
        shipmass = ship.getMass();
        ejectmass = ship.getEjectionMass();
        G = (float) Math.abs(((maxdis * maxdis)/(starmass*shipmass)));
    }
    
    public float getG (){
        return G;
    }
    
    public int getShipMass (){
        return shipmass;
    }
    
    public int getEjectionMass (){
        return ejectmass;
    }
    
    /**
     * Calcuates the magnitude of the force of gravity on an object.
     * @param dist the distance between the star and the ship
     * @return the force of gravity
     */
    public  float  Fg (float dist){
        return (float) ((G*starmass*shipmass)/(dist * dist));
    }
    
    /** 
     * The distance between two objects.
     * @param pos1 position of object 1
     * @param pos2 position of object 2
     * @return float distance between the objects
     */
    public  float distance (Vector2f pos1, Vector2f pos2){
        return (float) (Math.sqrt((Math.pow(pos2.getX()-pos1.getX(),2)) + (Math.pow(pos2.getY()-pos1.getY(),2))));
    }
    
    /** 
     * Calculates the acceleration due to gravity.
     * @param currentvel - the current velocity
     * @param currentpos - the current position
     * @return - the new velocoty
     */
    public  Vector2f gravitationForce (Vector2f currentvel, Vector2f currentpos) {
        Vector2f scratch = new Vector2f();
        
        Vector2f.sub(starpos, currentpos, scratch);
        float len2 = scratch.lengthSquared();
        Vector2f accel = (Vector2f) new Vector2f().set(scratch).scale(STAR_GRAVITY * 0.2f / len2);
        scratch.set(currentvel).translate(accel.getX(), accel.getY());
        
        return scratch;
    }
    
    /** when a collision takes place between objects of a same mass
     * 
     * @param one the velocity of the first object
     * @param two the velocity of the second object
     * @return the final velocity of the first object
     */
    public Vector2f sameMassCollision (Vector2f one, Vector2f two){
        return two;
    }
        
    private Vector2f diffMassCollision(float ratio, Vector2f hitVel, Vector2f strikeVel) {
        Vector2f newv = new Vector2f();
        if (hitVel.length() == 0 && ratio > 1) {
            newv = hitVel;
        } else if (hitVel.length() == 0 && ratio < 1) {
            newv.setX(-strikeVel.getX());
            newv.setY(-strikeVel.getY());
        } else {
            if (ratio < 1)
                newv = (Vector2f) strikeVel.scale(-1 / strikeVel.length());
            else
                newv = (Vector2f) strikeVel.scale(1 / strikeVel.length());
            newv.scale(ratio);
        }
        return newv;
    }
    
    /**
     * @param first the object making the call
     * @param second the object not making the cal
     * @return the veolocity of the object who got hit. i.e whoever is making the call 
     */
    public Vector2f diffMassCollision(Entity first, Entity second) {
        float ratio;
        if (first instanceof Ship)
            ratio = (float) shipmass / ejectmass;
        else
            // if there is a class Ejection Mass insert: else if (first
            // instanceof Ejectmass)
            ratio = (float) ejectmass / shipmass;
        Vector2f hit = new Vector2f(first.getVelocity());
        Vector2f oldv = new Vector2f(second.getVelocity());
        Vector2f newv = new Vector2f();
        if (hit.length() > oldv.length() && Vector2f.angle(hit, oldv) < 90) {
            newv = diffMassCollision(ratio, oldv, hit);
        } else {
            if (hit.length() == 0 && ratio > 1) {
                newv.setX(hit.getX() + 1 / ratio);
                newv.setY(hit.getY() + 1 / ratio);
            } else if (hit.length() == 0 && ratio < 1) {
                newv.setX(-oldv.getX());
                newv.setY(-oldv.getY());
            } else if (oldv.length() == 0 && ratio < 1) {
                newv = (Vector2f) hit.scale(-1);
            } else if (Vector2f.angle(hit, oldv) < 90) {
                newv.setX(hit.getX() + 1 / ratio);
                newv.setY(hit.getY() + 1 / ratio);
            } else {
                newv.setX(oldv.getX() / (ratio));
                newv.setY(oldv.getY() / (ratio));
            }
        }
        return newv;
    }
    
    /**
     * Calculates the velocity of the ship after ejection.
     * @param angle - angle in standard position to positive x-axis in radians
     * @param speed - speed of the ejection
     * @param vel - the velocity of the ship
     * @return - the new velocity of the ship
     */
    public Vector2f shipEjectionVelocity (float angle, float speed, Vector2f vel){
        Vector2f total = new Vector2f (0,0);
        Vector2f orientationBasis = new Vector2f ((float)Math.cos (angle), (float)Math.sin (angle));
        Vector2f p1 = new Vector2f ();
        Vector2f p2 = new Vector2f ();
        p1 =(Vector2f) vel.scale(shipmass + ejectmass);
        p2 = Vector2f.add (p1,(Vector2f)orientationBasis.scale(speed*ejectmass),null);
        p2.scale ((float)1/shipmass);
        return p2;
    }
    
    /**
     * Calculates the velocity of the mass after ejection.
     * @param angle - angle in standard position to positive x-axis in radians
     * @param speed - speed of the ejection
     * @return - the new velocity of the mass
     */
    public Vector2f massEjectionVelocity(float angle, float speed) {
        Vector2f total = new Vector2f(0, 0);
        Vector2f oBasis = new Vector2f((float) Math.cos(angle), (float) Math.sin(angle));
        Vector2f newvel = new Vector2f(oBasis.getX() * -1 * speed, oBasis.getY() * -1 * speed);
        return newvel;
    }
}
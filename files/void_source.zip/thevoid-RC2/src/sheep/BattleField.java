package sheep;

import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.OpenGLException;
import org.lwjgl.util.vector.Vector2f;

import sheep.attributes.ShipAttributes;
import sheep.attributes.StarAttributes;

import com.shavenpuppy.jglib.Resources;
import com.shavenpuppy.jglib.opengl.GLDisplayList;
import com.shavenpuppy.jglib.opengl.GLTexture;
import com.shavenpuppy.jglib.sprites.Sprite;
import com.shavenpuppy.jglib.sprites.SpriteEngine;

import net.puppygames.gui.MessageBox;
import net.puppygames.gui.Dialog;
import net.puppygames.gui.MessageBoxListener;

/**
 * @author Eric Woroshow
 */
public class BattleField extends Dialog {
    
    private static SpriteEngine spriteEngine;
    private static GLDisplayList background;
    private static ShipAttributes shipAttributes;
    private static StarAttributes starAttributes;
    
    public static void init() throws Exception {
        spriteEngine = new SpriteEngine(false, 256, VoidGame.TICK_RATE);
        spriteEngine.create();
        shipAttributes = (ShipAttributes)sheep.Resources.get("basic.ship");
        starAttributes = (StarAttributes)sheep.Resources.get("normal.star");
        createBackground();
    }
    
    /**
     * Creates a display list with the background quad.
     */
    private static void createBackground() throws Exception {
        final GLTexture tex = (GLTexture)Resources.get("background.texture");
        background = new GLDisplayList() {
            protected void drawGraphics() throws OpenGLException {                
                GL11.glEnable(GL11.GL_TEXTURE_2D);
                GL11.glColor3f(1f, 1f, 1f);
                tex.render();
                GL11.glBegin(GL11.GL_QUADS);
                {
                    GL11.glTexCoord2f(0.0f, 0.0f);
                    GL11.glVertex2f(0, 0);

                    GL11.glTexCoord2f(1.0f, 0.0f);
                    GL11.glVertex2f(VoidGame.WIDTH, 0);

                    GL11.glTexCoord2f(1.0f, 1.0f);
                    GL11.glVertex2f(VoidGame.WIDTH, VoidGame.HEIGHT);

                    GL11.glTexCoord2f(0.0f, 1.0f);
                    GL11.glVertex2f(0, VoidGame.HEIGHT);
                }
                GL11.glEnd();
            }
        };
        background.create();
    }
    
    private static final int STATE_STOPPED = 0;
    private static final int STATE_GAMEOVER = 1;
    private static final int STATE_PAUSED = 2;
    private static final int STATE_PLAYING = 3;
    
    private int state;
    private int players;
    
    
    private Ship[] ships;
    private Star star;

    public BattleField() {
        super();
        
        state = STATE_STOPPED;
        createGUI();
    }
    
    private void createGUI() {
        setBounds(0, 0, VoidGame.WIDTH, VoidGame.HEIGHT);
    }
    
    public void startNewGame(int players) {
        this.players = players;
        
        star = new Star(starAttributes);
        PhysicsEngine.STAR_GRAVITY = starAttributes.getGravity();
        star.spawn();
        
        ships = new Ship[players];
        for (int i = 0; i < players; i++) {
            ships[i] = new Ship(shipAttributes, i);
            ships[i].setPosition(new Vector2f(300 + (60 * i), 350));
            ships[i].spawn();
            ships[i].update();
        }
        
        state = STATE_PLAYING;
        open();
    }
    
    public void endGame() {
        Entity.clearEntities();
        spriteEngine.clear();
        state = STATE_STOPPED;
        close();
    }
    
    protected boolean doTick() {
        switch (state) {        
        case STATE_PAUSED:
        case STATE_STOPPED:
            break;
        case STATE_GAMEOVER:
            star.update();
            spriteEngine.tick();
            break;
        case STATE_PLAYING:
            handleInput();
            handleGameState();
            Entity.updateEntities();
            spriteEngine.tick();
            break;
        }
        
        return true;
    }
    
    protected void renderBackground() {
        background.render();
    }
    
    protected void renderSelf() {
        Entity.renderEntities();
        spriteEngine.render();
    }
    
    private void handleGameState() {
        //Increase gravity just a bit for this frame
        PhysicsEngine.STAR_GRAVITY += starAttributes.getGravityIncrease();
        
        int bodycount = 0;
        for (int i = 0; i < ships.length; i++) {
            if (!ships[i].isAlive()) //One ship has been crushed!
                bodycount++;
        }
        
        if (bodycount >= players - 1) {
            int winner = 0;
            for (int i = 0; i < ships.length; i++)
                if (ships[i].isAlive()) {
                    winner = i;
                    break;
                }
                
                state = STATE_GAMEOVER;
                try {
                    new MessageBox("Game Over", "Player " + (winner+1) + " wins!!!",
                                   -1, MessageBox.OK_DIALOG,
                            new MessageBoxListener() {
                                public void messageBoxChoiceMade(MessageBox mbox, int choice) {
                                    VoidGame.displayRootMenu();
                                }
                            }).open();
                } catch (Exception e) {
                    Log.log(e);
                }
        }
    }
    
    private void handleInput() {
        if (Keyboard.isKeyDown(Keyboard.KEY_ESCAPE)) {
            state = STATE_PAUSED;
            try {
                new MessageBox(
                        "Exit",
                        "Exit this match?",
                        -1,
                        MessageBox.YES_NO_DIALOG,
                        new MessageBoxListener() {
                            public void messageBoxChoiceMade(MessageBox mbox, int choice) {
                                if (choice == MessageBoxListener.YES_SELECTED)
                                    VoidGame.displayRootMenu();
                                else
                                    state = STATE_PLAYING;
                            }
                        }).open();
            } catch (Exception e) {
                Log.log(e);
            }
        }
    }
    
    public static Sprite allocateSprite(Object owner) {
        return spriteEngine.allocate(owner);
    }
}
package sheep;

/**
 * Describes an Entity that can exist in three states. It has a
 * lifespan of Creating -> Alive -> Dying.
 * 
 * @author Hemesh
 */
public abstract class LivingEntity extends Entity {

    public final int STATE_CREATING = 0;
    public final int STATE_ALIVE = 1;
    public final int STATE_DYING = 2;

    protected int state = STATE_CREATING;

    private final void setState(int nstate) {
        if (state == nstate) return;
        
        switch (nstate) {
        case STATE_ALIVE:
            state = STATE_ALIVE;
            onCreation();
            update();
            break;
        case STATE_DYING:
            state = STATE_DYING;
            onDeath();
            update();
        default:
            assert false : "Illegal state.";
            break;
        }
    }

    /**
     * Creates this Entity. This Entity will now be in the ALIVE state.
     */
    public final void create(){
        setState(STATE_ALIVE);
    }
    
    /**
     * Destroys this Entity. This Entity will now be in the DYING state.
     */
    public final void kill() {
        setState(STATE_DYING);
    }

    /**
     * @return if this Entity is being created
     */
    public boolean isCreating() {
        return state == STATE_CREATING;
    }

    /**
     * @return if this Entity is alive
     */
    public boolean isAlive() {
        return state == STATE_ALIVE;
    }

    /**
     * @return if this Entity is dying
     */
    public boolean isDying() {
        return state == STATE_DYING;
    }

    /**
     * Called when this Entity transitions from the creating state to being
     * alive.
     */
    public void onCreation() {}

    /**
     * Called when this Entity transitions from the alive state to dying.
     */
    public void onDeath() {}

    public abstract void doCreationUpdate();
    public abstract void doAliveUpdate();
    public abstract void doDyingUpdate();

    /**
     * Updates this Entity for a frame. Calls the state-specific update method
     * depending on the current state of this Entity.
     * 
     * @see sheep.Entity#update()
     */
    public final void update() {
        switch (state) {
        case STATE_CREATING:
            doCreationUpdate();
            break;
        case STATE_ALIVE:
            doAliveUpdate();
            break;
        case STATE_DYING:
            doDyingUpdate();
            break;
        default:
            assert false;
            break;
        }
    }

    /** 
     * @return if this Entity is alive
     * @see sheep.Entity#canCollide()
     */
    public boolean canCollide() {
        return isAlive();
    }
    
    /**
     * Kills this Entity instantly.
     * @see sheep.Entity#inCollisonWithStar(Star)
     */
    public void inCollisonWithStar(Star s){
        kill();
    }
}
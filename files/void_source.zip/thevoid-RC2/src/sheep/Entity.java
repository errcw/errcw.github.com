package sheep;

import java.util.ArrayList;

import org.lwjgl.util.vector.Vector2f;

/**
 * Describes an object that exists in a game world. It has both a position and
 * velocity.
 * 
 * @author Eric Woroshow
 */
public abstract class Entity {

    /** List of all Entities that exist in the game world */
    private static final ArrayList entities = new ArrayList(256);
    /** Scratch vector for use in calculations */
    protected static final Vector2f scratch = new Vector2f();
    
    //Entity management

    /**
     * Updates all Entities in the game world.
     */
    public static void updateEntities() {
        //Thanks to princec for the method of dealing with removed Entities!
        for (int i = 0; i < entities.size(); ) {
            Entity entity = (Entity)entities.get(i);
            entity.update();
            
            if (entity.index != -1)
                i++;
        }
        
        //Perform collision detection at this point
        for (int i = 0; i < entities.size(); ){
            Entity e1 = (Entity)entities.get(i);
            for (int j = 1; j < entities.size(); ){
                Entity e2 = (Entity)entities.get(j);
                if (e1.canCollide() && e2.canCollide() && e1.isInCollisonWith(e2)){
                    e1.inCollisionWith(e2);
                    e2.inCollisionWith(e1);
                }
                
                if (e2.index != -1)
                    j++;
            }
            if (e1.index != -1)
                i++;
        }
    }

    /**
     * Renders all Entities in the game world.
     */
    public static void renderEntities() {
        final int nentities = entities.size();
        for (int i = 0; i < nentities; i++)
            ((Entity) entities.get(i)).render();
    }
    
    /**
     * Clears all the Entities from the game world.
     */
    public static void clearEntities() {
        entities.clear();
    }

    //Index in the global Entities list
    private int index;

    /** Current position in the game world of this Entity */
    protected final Vector2f position = new Vector2f();
    /** Current velocity of this Entity */
    protected final Vector2f velocity = new Vector2f();
    /** Collision detection radius of this Entity */
    protected float radius;
    /** Physics handling */
    protected final PhysicsEngine physicsEngine = new PhysicsEngine();

    //Entity management

    /**
     * Adds this Entity to the game world. Until it is removed, it will be
     * updated and rendered every frame.
     */
    public final void spawn() {
        Log.log(this + " has been spawn()-ed");
        
        index = entities.size();
        entities.add(this);
        onSpawn();
    }

    /**
     * Removes this Entity from the game world. It will no longer be updated or
     * rendered.
     */
    public final void remove() {
        Log.log(this + " has been remove()-ed");
        
        index = -1;
        entities.remove(this);
        onRemoval();
    }

    /**
     * Called when this Entity is spawned into the game world.
     */
    protected void onSpawn() {}

    /**
     * Called when this Entity is removed from the game world.
     */
    protected void onRemoval() {}

    //Position

    /**
     * @return the position of this Entity
     */
    public Vector2f getPosition() {
        return position;
    }

    /**
     * Sets the position of this Entity.
     */
    public void setPosition(Vector2f nposition) {
        position.set(nposition);
    }

    //Velocity

    /**
     * @return the velocity of this Entity
     */
    public Vector2f getVelocity() {
        return velocity;
    }

    /**
     * Sets the velocity of this Entity.
     */
    public void setVelocity(Vector2f nvelocity) {
        velocity.set(nvelocity);
    }

    //Logic

    /**
     * @return the collision detection radius
     */
    public float getRadius() {
        return radius;
    }

    /**
     * Updates this Entity for each frame.
     */
    public abstract void update();

    /**
     * Renders this Entity for each frame.
     */
    public abstract void render();

    /**
     * @return if this Entity can collide with another Entity
     */
    public abstract boolean canCollide();
    
    /**
     * @return if the collision circle of this Entity intersects the collison
     *         circle of the other Entity
     */
    public boolean isInCollisonWith(Entity other){
        if (this == other) return false;
        Vector2f.sub(other.getPosition(), getPosition(), scratch);
        return scratch.length() < (getRadius() + other.getRadius());
    }

    /**
     * Notifies this Entity that it is in collision with another Entity.
     * @param entity the Entity in collision
     */
    public abstract void inCollisionWith(Entity entity);    

    public abstract void inCollisonWithStar(Star s);
    public abstract void inCollisionWithShip(Ship s);
    public abstract void inCollisonWithMass(Mass m);
}
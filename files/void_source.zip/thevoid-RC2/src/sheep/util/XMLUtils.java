package sheep.util;

import java.util.ArrayList;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * Utililty methods for manipulating XML files.
 * @author Eric Woroshow
 */
public class XMLUtils {
    
    /**
     * @return all child nodes of the given Element with the specified name
     */
    public static ArrayList getChildren(Element elem, String name) {
        ArrayList list = new ArrayList();
        NodeList children = elem.getChildNodes();
        for (int i = 0; i < children.getLength(); i++) {
            Node node = children.item(i);
            if (node.getNodeName().equals(name) && node.getNodeType() == Node.ELEMENT_NODE)
                list.add(node);
        }
        return list;
    }
    
    /**
     * @return a String value of the specified attribute in the given element
     */
    public static String getString(Element elem, String attrib){
        String s = elem.getAttribute(attrib);
        return s;
    }
    
    /**
     * @return the float value of the specified attribute in the given element
     */
    public static float getFloat(Element elem, String attrib){
        String s = elem.getAttribute(attrib);
        return Float.parseFloat(s);
    }
    
    /**
     * @param defaultval the default value to return if the attribute doesn't exist
     * @return the float value of the specified attribute in the given element, or
     *         the default value
     */
    public static float getFloat(Element elem, String attrib, float defaultval){
        String s = elem.getAttribute(attrib);
        if (s == null || "".equals(s))
            return defaultval;
        else
            return Float.parseFloat(s);
    }
    
    /**
     * @return if the specified attribute has a value of "true"
     */
    public static boolean getBoolean(Element elem, String attrib){
        String s = elem.getAttribute(attrib);
        return Boolean.valueOf(s).booleanValue();
    }
    
   /**
     * @param defaultval the default value to return if the attribute doesn't exist
     * @return if the specified attribute has a value of "true"
     */
    public static boolean getBoolean(Element elem, String attrib, boolean defaultval){
        String s = elem.getAttribute(attrib);
        if (s == null || "".equals(s))
            return defaultval;
        else
            return Boolean.valueOf(s).booleanValue();
    }
    
    /**
     * @return the int value of the specified attribute in the given element
     */
    public static int getInt(Element elem, String attrib){
        String s = elem.getAttribute(attrib);
        return Integer.parseInt(s);
    }
    
    /**
     * @param defaultval the default value to return if the attribute doesn't exist
     * @return the int value of the specified attribute in the given element
     */
    public static int getInt(Element elem, String attrib, int defaultval){
        String s = elem.getAttribute(attrib);
        if (s == null || "".equals(s))
            return defaultval;
        else
            return Integer.parseInt(s);
    }
}

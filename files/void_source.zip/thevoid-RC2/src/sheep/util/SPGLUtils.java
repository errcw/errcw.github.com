package sheep.util;

/*import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;*/

public class SPGLUtils {

    public static void main(String[] args) throws Exception {
        /*String[] arg = { "spritedata2", "sprites", "sprites", "spr", "sprites2.xml",
                "none.txt", "none.txt", "none.txt", "128" };
        com.shavenpuppy.jglib.tools.TexturePacker.main(arg);*/
        
        String[] arg = { "spgl_res.xml", "spgl_res.dat" };
        com.shavenpuppy.jglib.tools.ResourceConverter.main(arg);
        
        /*String[] arg = { "Arial-PLAIN-12", "arial12.jgfont", "65536",
                "Impact-PLAIN-18", "impact18.jgfont", "65536",
                "Impact-PLAIN-24", "impact24.jgfont", "65536"};
        com.shavenpuppy.jglib.tools.FontConverter.main(arg);*/
        
        /*String[] arg = { "res", "res" };
        com.shavenpuppy.jglib.tools.ImageConverter.main(arg);*/
        
        /*for (int i = 1; i < 43; i++) {
        String file = "spritedata2/Explode00" + ((i < 10) ? "0" : "") + i + ".png";
        
        BufferedImage img = ImageIO.read(new File(file));
        BufferedImage nimg = new BufferedImage(128, 128, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = nimg.createGraphics();
        
        for (int x = 0; x < 128; x++)
            for (int y = 0; y < 128; y++) {
                Color c = new Color(img.getRGB(x, y));
                if (c.getRed() != 0 || c.getBlue() != 0 || c.getGreen() != 0) {
                    //System.out.println("Pixel at [" + x + "," + y + "] is non-black");
                    g.setColor(c);
                    g.drawLine(x, y, x, y);
                }
            }

        ImageIO.write(nimg, "png", new File(file));
        }*/
    }
}
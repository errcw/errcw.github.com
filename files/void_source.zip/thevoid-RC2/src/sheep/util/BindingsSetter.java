package sheep.util;

import java.io.FileOutputStream;

import org.lwjgl.opengl.Window;

import sheep.VoidGame;
import sheep.Bindings;

/**
 * Provides a command-line interface for setting key bindings.
 * @author Eric Woroshow
 */
public class BindingsSetter {

    public static void main(String[] args) throws Exception {
        Window.create(VoidGame.GAME_TITLE, 0, 0, 50, 50, 32, 0, 0, 0);
        
        for (int i = 0; i < VoidGame.MAX_PLAYERS; i++) {
            System.out.println("--Bindings for Player " + (i+1));
            
            Bindings.Binding[] bindings = Bindings.getPlayerBindings(i).getBindingsArray();
            for (int j = 0; j < bindings.length; j++) {
                System.out.println("\tBind: " + bindings[j].getName());
                
                while (!bindings[j].determine()) {
                    Window.update();
                    Thread.sleep(100);
                }
                
                System.out.println("\tBound to: " + bindings[j]);
                
                Thread.sleep(1000);
            }
        }
        System.out.println("--Bindings complete");
        
        FileOutputStream fos = new FileOutputStream("res/bindings.dat");
        Bindings.save(fos);
        fos.flush();
        fos.close();
        
        System.out.println("--Bindings saved to res/bindings.dat");
    }
}

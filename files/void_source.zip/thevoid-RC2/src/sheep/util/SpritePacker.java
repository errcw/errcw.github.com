package sheep.util;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileFilter;
import java.io.FileWriter;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

import javax.imageio.ImageIO;

/**
 * Creates a power-of-two image containing a number of smaller images arranged
 * in the most compact manner possible.
 * 
 * @author Eric Woroshow
 */
public class SpritePacker {
    /** Size of the packed texture image */
    public final int MAX_IMG_SIZE = 256;
    
    private String sourceDir;
    private String destDir;
    private String outputXMLFile;
    private String namePrefix;
    
    private int texIDs = 0;

    /**
     * A node in a storage tree.
     */
    private class Node {
        Rectangle rect;
        Node[] child = null;
        boolean used = false;
        
        Node() {}

        Node insert(PackedSprite img) {
            if (child != null) {
                //If we're a parent, try inserting into our children
                Node n = child[0].insert(img);
                if (n != null) return n;
                return child[1].insert(img);
            } else {
                //Otherwise, create children in which to store the image
                if (used) return null;
                if (img.w > rect.width || img.h > rect.height) return null;                
                if (img.w == rect.width && img.h == rect.height) return this;
                
                child = new Node[2];
                child[0] = new Node();
                child[1] = new Node();
                
                int dw = rect.width - img.w;
                int dh = rect.height - img.h;
                
                if (dw > dh) {
                    child[0].rect = new Rectangle(rect.x, rect.y, img.w, rect.height);
                    child[1].rect = new Rectangle(rect.x + img.w, rect.y, rect.width - img.w, rect.height);
                } else {
                    child[0].rect = new Rectangle(rect.x, rect.y, rect.width, img.h);
                    child[1].rect = new Rectangle(rect.x, rect.y + img.h, rect.width, rect.height - img.h);
                }
                
                return child[0].insert(img);
            }
        }
    }
    
    /**
     * A sprite image packed into a larger texture.
     */
    private class PackedSprite implements Comparable {
        final String name;
        final BufferedImage image;
        final int w, h;
        Node pos;
        
        PackedSprite(File file) throws Exception { 
            name = file.getName().substring(0, file.getName().length() - 4);
            image = ImageIO.read(file);
            w = image.getWidth();
            h = image.getHeight();
        }
        
        /**
         * Assumes that the Object being compared is a PackedSprite. Causes
         * the objects to be sorted in reverse order by reporting the opposite
         * of what compareTo is supposed to.
         * @see java.lang.Comparable#compareTo(java.lang.Object)
         */
        public int compareTo(Object o){
            PackedSprite other = (PackedSprite)o;
            if (other.w == w && other.h == h) //We're exactly the same size
                return 0;
            else if (other.w > w || other.h > h) //We're smaller
                return 1;
            else //We're bigger
                return -1;
        }
    }
    
    private class PackedTexture {
        Node texture;
        BufferedImage image;
        ArrayList sprites;
        
        int id;
        
        PackedTexture(){
            id = texIDs++;
            
            texture = new Node();
            texture.rect = new Rectangle(0, 0, MAX_IMG_SIZE, MAX_IMG_SIZE);
            image = new BufferedImage(MAX_IMG_SIZE, MAX_IMG_SIZE, BufferedImage.TYPE_4BYTE_ABGR);
            sprites = new ArrayList(16);
        }
        
        /**
         * Packs a sprite into this texture.
         * @return if the sprite was successfully inserted
         */
        public boolean insert(PackedSprite sprite) {
            sprite.pos = texture.insert(sprite);
            if (sprite.pos == null)
                return false;
            
            sprite.pos.used = true;
            
            Graphics g = image.getGraphics();
            g.drawImage(sprite.image, sprite.pos.rect.x, sprite.pos.rect.y, null);
            sprites.add(sprite);
            
            return true;
        }
        
        public void output(BufferedWriter out) throws Exception {
            String name = namePrefix + id;

            //Create the packed image png
            ImageIO.write(image, "png", new File(destDir + name + ".png"));

            out.write("\t<packedimage name=\"");
            out.write(name + ".packedimage");
            out.write("\" file=\"");
            out.write(name + ".png");
            out.write("\" >\n");

            for (Iterator i = sprites.iterator(); i.hasNext();) {
                PackedSprite sprite = (PackedSprite) i.next();
                out.write("\t\t<spriteimage name=\"");
                out.write(sprite.name + ".img\"");
                out.write(" x=\"" + sprite.pos.rect.x + "\"");
                out.write(" y=\"" + sprite.pos.rect.y + "\"");
                out.write(" w=\"" + sprite.pos.rect.width + "\"");
                out.write(" h=\"" + sprite.pos.rect.height + "\"");
                out.write(" />\n");
            }

            out.write("\t</packedimage>\n");
        }
    }
    
    /**
     * Creates a new SpritePacker.
     * 
     * @param sourceDir
     * @param destDir
     * @param outputFile
     */
    public SpritePacker(String sourceDir, String destDir, String outputXMLFile, String outputImgFile) {
        this.sourceDir = sourceDir;
        this.destDir = destDir;
        this.outputXMLFile = outputXMLFile;
        this.namePrefix = outputImgFile;
    }
    
    private void getSourceImages(File dir, ArrayList imgs) {
        System.out.println("Grabbing files from " + dir);
        
        File[] files = dir.listFiles(new FileFilter(){
            public boolean accept(File pathname){
                return (pathname.getName().endsWith(".png") || pathname.isDirectory());
            }
        });
        
        for (int i = 0; i < files.length; i++)
            if (files[i].isFile())
                try {
                    imgs.add(new PackedSprite(files[i]));
                } catch (Exception e) {
                    System.out.println("ERROR: Unable to add " + files[i]);
                }
            else
                getSourceImages(files[i], imgs);
    }
    
    private void pack() throws Exception {
        File dir = new File(sourceDir);
        ArrayList pngs = new ArrayList(64);
        getSourceImages(dir, pngs);
        
        PackedSprite[] sprites = new PackedSprite[pngs.size()];
        pngs.toArray(sprites);
        Arrays.sort(sprites);

        ArrayList textures = new ArrayList(8);
        for (int i = 0; i < sprites.length; i++) {
            boolean packed = false;
            //Try to fit the image in all the textures
            for (int j = 0; j < textures.size() && !packed; j++) {
                PackedTexture tex = (PackedTexture) textures.get(j);
                System.out.println("PACKING: " + sprites[i].name);
                packed = tex.insert(sprites[i]);
            }

            //Couldn't find a texture where the image fit, so create a new texture
            if (!packed) {
                System.out.println(sprites[i].name + " did not fit. Creating a new packed image.");
                PackedTexture tex = new PackedTexture();
                packed = tex.insert(sprites[i]);
                if (!packed)
                    System.out.println("ERROR: Could not pack " + sprites[i].name);
                textures.add(tex);
            }
        }

        //Finalize the output by creating the XML
        File outfile = new File(destDir + outputXMLFile);
        BufferedWriter out = new BufferedWriter(new FileWriter(outfile));
        
        out.write("<?xml version='1.0' encoding='utf-8'?>\n");
        out.write("<resources>\n");
        
        for (int j = 0; j < textures.size(); j++)
            ((PackedTexture) textures.get(j)).output(out);
        
        out.write("</resources>\n");
        out.close();
        
        System.out.println("Done!");
    }
    
    /**
     * Entry point for the application.
     * 
     * Usage: SpritePacker <sourcedir> <destdir> <outputxml> <outputimg>
     */
    public static void main(String[] args) throws Exception {
        if (args.length != 4){
            System.out.println("Usage:");
            System.out.println("\tSpritePacker <sourcedir> <destdir> <outputxml> <nameprefix>");
            System.exit(-1);
        }
        
        new SpritePacker(args[0], args[1], args[2], args[3]).pack();
    }
}
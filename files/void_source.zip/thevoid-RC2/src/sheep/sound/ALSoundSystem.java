package sheep.sound;

import java.nio.IntBuffer;
import java.util.ArrayList;
import java.util.Iterator;

import org.lwjgl.BufferUtils;
import org.lwjgl.openal.AL;
import org.lwjgl.openal.AL10;

/**
 * Core of AAL. (AAL: Audio Library).
 * 
 * @author Eric Woroshow
 * @version 0.32a
 */
public class ALSoundSystem {

    /** Useful scratch memory */
    protected static final IntBuffer scratch = BufferUtils.createIntBuffer(16);

    /** All available sources with which to play sound */
    private static ALSource[] sources;

    /** A list of currently playing sounds */
    private static ArrayList managedsounds;
    
    private static final ALListener listener = new ALListener();

    public static void init(int nsources) throws Exception {
        AL.create();

        managedsounds = new ArrayList();

        sources = new ALSource[nsources];
        for (int i = 0; i < sources.length; i++)
            sources[i] = new ALSource();

        AL10.alDistanceModel(AL10.AL_INVERSE_DISTANCE_CLAMPED);
        listener.set(AL10.AL_GAIN, 1.0f);
    }
    
    /**
     * @return gets the listener
     */
    public static ALListener getListener() {
        return listener;
    }

    public static ALSound play(ALSoundData data) {
        ALSource source = getAvailableSource();
        if (source == null) return null;

        ALSound sound = new ALSound(data, source);
        sound.play();
        managedsounds.add(sound);

        return sound;
    }

    public static ALStreamingSound playStream(ALSoundStream stream) {
        ALSource source = getAvailableSource();
        if (source == null) return null;

        ALStreamingSound sound = new ALStreamingSound(stream, source);
        sound.play();
        managedsounds.add(sound);

        return sound;
    }

    public static void update() {
        for (Iterator i = managedsounds.iterator(); i.hasNext();) {
            ALSound sound = (ALSound) i.next();
            sound.update();

            if (!sound.isAlive())
            //collect the sound and reclaim the source
                    i.remove();
        }
    }

    public static void stopAll() {
        for (Iterator i = managedsounds.iterator(); i.hasNext();) {
            ALSound sound = (ALSound) i.next();
            sound.destroy();
            i.remove();
        }
    }

    /**
     * Destroys the sound system and all accompanying native resources.
     */
    public static void destroy() {
        for (int i = 0; i < sources.length; i++)
            sources[i].destroy();

        AL.destroy();
    }

    private static ALSource getAvailableSource() {
        for (int i = 0; i < sources.length; i++)
            if (sources[i].isControllable()) return sources[i];
        return null;
    }
}
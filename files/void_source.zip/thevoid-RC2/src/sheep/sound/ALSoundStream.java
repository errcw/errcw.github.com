package sheep.sound;

import java.io.IOException;
import java.nio.ByteBuffer;

/**
 * Defines a common interface for streaming in sound.
 * @author Eric Woroshow
 */
public interface ALSoundStream {

    /**
     * Gets the format of the audio stream. 
     * @return the OAL audio format id
     */
    public int getFormat();

    /**
     * Gets the rate of the PCM audio.
     */
    public int getRate();

    /**
     * Reads up to len bytes of data from the input stream into a ByteBuffer.
     * The data in the ByteBuffer must be in raw PCM data form.
     * 
     * @param b the buffer into which the data is read.
     * @param off the start offset of the data.
     * @param len the maximum number of bytes read.
     * @return the total number of bytes read into the buffer, or -1 if there
     *         is no more data because the end of the stream has been reached.
     */
    public int read(ByteBuffer b, int off, int len) throws IOException;
    
    /**
     * Attempts to restream the audio data from the beginning.
     * @return if the restreaming was successful
     */
    public boolean restream();
}
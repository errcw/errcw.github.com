package sheep.sound;

import org.lwjgl.BufferUtils;
import org.lwjgl.openal.*;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;

/**
 * @author Eric Woroshow
 */
public class ALStreamingSound extends ALSound {

    //Number of bytes of audio data to buffer
    private final int BUFFER_SIZE = 4096 * 32;
    //Temporary storage for audio data
    private ByteBuffer databuffer = BufferUtils.createByteBuffer(BUFFER_SIZE);
    //Front and back buffers
    private IntBuffer buffers = BufferUtils.createIntBuffer(2);

    private ALSoundStream stream;
    private boolean looping = false;
    
    protected ALStreamingSound(ALSoundStream stream, ALSource source){
        this.stream = stream;
        this.source = source;
        alive = true;
        
        AL10.alGenBuffers(buffers);

        source.setController(this);
        
        setPosition(0.0f, 0.0f, 0.0f);
        setVelocity(0.0f, 0.0f, 0.0f);
        source.set(AL10.AL_DIRECTION, 0.0f, 0.0f, 0.0f, this);
        source.set(AL10.AL_ROLLOFF_FACTOR, 0.0f, this);
        source.set(AL10.AL_SOURCE_RELATIVE, AL10.AL_TRUE, this);
    }
    
    /**
     * Cleans up after the file has been played.
     */
    public void destroy() {
        source.stop(this);
        empty();
        source.setController(null);
        alive = false;
        
        AL10.alDeleteBuffers(buffers);
    }

    /**
     * Plays the Ogg file. This method has no effect if the file is already
     * being played. <code>update</code> must be called every frame to
     * stream more audio data into the buffers.
     */
    public void play() {
        if (isPlaying()) return;
        
        for (int i = 0; i < buffers.capacity(); i++)
            stream(buffers.get(i));

        AL10.alSourceQueueBuffers(source.getALSourceID(), buffers);
        source.play(this);
    }

    /**
     * Uploads audio data from the ogg stream to OpenAL. This method must be
     * called often to supply enough data to the buffers.
     */
    public void update() {
        if (!isAlive()) return;
        
        boolean active = true;
        int processed = source.getInt(AL10.AL_BUFFERS_PROCESSED);

        //For every buffer that has been played...
        while (processed-- > 0) {
            ALSoundSystem.scratch.clear().limit(1);
            //Pop it off the queue
            AL10.alSourceUnqueueBuffers(source.getALSourceID(), ALSoundSystem.scratch);

            //Fill it with audio data
            active = stream(ALSoundSystem.scratch.get(0));

            //Push it back onto the queue for playback
            AL10.alSourceQueueBuffers(source.getALSourceID(), ALSoundSystem.scratch);
        }
        
        alive = active;
        if (!alive)
            destroy();
    }

    /**
     * Fills the buffer with raw PCM audio data from the stream.
     * 
     * @param buffer the buffer in which to store the data
     * @return if the next section of the stream was successfully buffered
     */
    private boolean stream(int buffer) {
        try {

            int bytes = stream.read(databuffer, 0, BUFFER_SIZE);
            if (bytes >= 0) {
                databuffer.flip();
                AL10.alBufferData(buffer, stream.getFormat(), databuffer, stream.getRate());
                return true;
            }

        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }

        return false;
    }

    private void empty() {
        int queued = source.getInt(AL10.AL_BUFFERS_QUEUED);
        ALSoundSystem.scratch.clear().limit(1);
        while (queued-- > 0) {
            AL10.alSourceUnqueueBuffers(source.getALSourceID(), ALSoundSystem.scratch);
        }
    }
    
    public void setLooping(boolean loop){
        looping = loop;
    }
}

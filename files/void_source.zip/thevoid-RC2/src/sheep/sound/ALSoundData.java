package sheep.sound;

import java.io.FileInputStream;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;


import org.lwjgl.BufferUtils;
import org.lwjgl.openal.AL10;

import sheep.Resource;
import sheep.Resources;
import sheep.util.XMLUtils;

/**
 * Raw sound data. Wraps an OpenAL Buffer.
 * @author Eric Woroshow
 */
public class ALSoundData extends Resource {

    private int bufferID;

    //must be 1 for PCM
    private int dataformat;
    /** OpenAL format of the audio data */
    protected int format;
    /** Number of channels in the audio */
    protected int channels;
    /** Frequency of the audio */
    protected int frequency;
    /** Number of bits per sample */
    protected int samplesize;
    
    private String file;    
    private float gain;
    private float pitch;
    private boolean looped;
    
    /**
     * Resource constructor.
     * @param name unique name of this resource
     */
    public ALSoundData(String name){
        super(name);
    }
    
    protected void load(org.w3c.dom.Element element) {
        file = XMLUtils.getString(element, "file");
        
        gain = XMLUtils.getFloat(element, "gain", 1.0f);
        pitch = XMLUtils.getFloat(element, "pitch", 1.0f);
        looped = XMLUtils.getBoolean(element, "looped", false);
    }
    
    protected void doCreate() throws Exception {
        ALSoundSystem.scratch.clear().limit(1);
        AL10.alGenBuffers(ALSoundSystem.scratch);
        bufferID = ALSoundSystem.scratch.get(0);
        
        FileInputStream in = new FileInputStream(Resources.getResource(file).getFile());
        read(in);
    }
    
    /**
     * Destroys the audio data this buffer contains.
     */
    protected void doDestroy() {
        ALSoundSystem.scratch.clear().limit(1);
        ALSoundSystem.scratch.put(0, bufferID);
        AL10.alDeleteBuffers(ALSoundSystem.scratch);
    }
    
    /**
     * @return the gain with which to play this sound data
     */
    public float getGain() {
        return gain;
    }
    
    /**
     * @return the pitch with which to play this sound data
     */
    public float getPitch() {
        return pitch;
    }
    
    /**
     * @return if the sound data should be looped infinitely
     */
    public boolean getLooping(){
        return looped;
    }

    /**
     * @return the ID of the buffered audio data
     */
    protected int getALBufferID() {
        return bufferID;
    }

    /**
     * Loads audio data from a .wav file. 
     * 
     * @param file file from which to load the audio
     * @throws Exception if an error occured reading the file
     */
    private void read(FileInputStream file) throws Exception {
        ByteBuffer header = BufferUtils.createByteBuffer(12);
        ByteBuffer fmtchunk = BufferUtils.createByteBuffer(24);
        ByteBuffer datachunk = BufferUtils.createByteBuffer(8);

        FileChannel in = file.getChannel();
        in.read(header);
        in.read(fmtchunk);
        in.read(datachunk);

        //read in info from the format chunk
        dataformat = fmtchunk.getShort(8); //must be 1 for PCM data
        channels = fmtchunk.getShort(10);
        frequency = fmtchunk.getInt(12);
        samplesize = fmtchunk.getShort(22);
        format = getALFormat();

        //read in the raw audio data
        int length = datachunk.getInt(4);
        ByteBuffer audio = BufferUtils.createByteBuffer(length);
        in.read(audio);

        in.close();

        audio.flip();
        AL10.alBufferData(bufferID, format, audio, frequency);
    }

    private int getALFormat() {
        if (channels == 1)
            if (samplesize == 8)
                return AL10.AL_FORMAT_MONO8;
            else
                return AL10.AL_FORMAT_MONO16;
        else if (samplesize == 8)
            return AL10.AL_FORMAT_STEREO8;
        else
            return AL10.AL_FORMAT_STEREO16;
    }
}
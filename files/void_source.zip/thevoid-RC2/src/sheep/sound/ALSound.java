package sheep.sound;

import org.lwjgl.openal.AL10;

/**
 * @author Eric Woroshow
 */
public class ALSound {
    
    /** Each sound is bound to a single source. */
    protected ALSource source;
    private ALSoundData sounddata;
    
    /** Whether the sound is active and can control its source */
    protected boolean alive = false;

    /**
     * Creates an invalid sound object. Attempting to call any methods
     * on it will throw a <code>NullPointerException</code>.
     */
    protected ALSound(){
        source = null;
        sounddata = null;
    }
    
    /**
     * Creates a new sound object defined by sound data and the source
     * that plays it. Attempting to create a new <code>ALSound</code>
     * with a null source will cause an NPE.
     * @param sounddata audio data to play
     * @param source source playing the audio
     */
    protected ALSound(ALSoundData sounddata, ALSource source) {
        this.sounddata = sounddata;
        this.source = source;
        alive = true;
        
        source.setController(this);

        source.set(AL10.AL_PITCH, sounddata.getPitch(), this);
        source.set(AL10.AL_GAIN, sounddata.getGain(), this);
        source.set(AL10.AL_POSITION, 0.0f, 0.0f, 0.0f, this);
        source.set(AL10.AL_VELOCITY, 0.0f, 0.0f, 0.0f, this);
        source.set(AL10.AL_DIRECTION, 0.0f, 0.0f, 0.0f, this);
        source.set(AL10.AL_ROLLOFF_FACTOR, 0.0f, this);
        source.setLooping(sounddata.getLooping(), this);
        
        source.attatch(sounddata, this);
    }
    
    /**
     * Updates the sound for the current frame. If the sound has stopped
     * playing then it is <code>destroy()</code>ed and its resources are
     * reclaimed.
     */
    public void update(){
        //do fading
        
        if (!isPlaying())
            destroy();
    }

    public void play() {
        source.play(this);
    }

    public void pause() {
        source.pause(this);
    }

    public void stop() {
        source.stop(this);
    }

    public void rewind() {
        source.rewind(this);
    }

    public void setSoundData(ALSoundData data) {
        source.attatch(data, this);
    }
    
    public void setGain(float gain){
        source.set(AL10.AL_GAIN, gain, this);
    }
    
    public void setPitch(float pitch){
        source.set(AL10.AL_GAIN, pitch, this);
    }
    
    public void setPosition(float x, float y, float z){
        source.set(AL10.AL_POSITION, x, y, z, this);
    }
    
    public void setVelocity(float x, float y, float z){
        source.set(AL10.AL_VELOCITY, x, y, z, this);
    }
    
    public void setAttenuation(boolean attenuated){
        source.set(AL10.AL_ROLLOFF_FACTOR, attenuated ? 1.0f : 0.0f, this);
    }
    
    /**
     * Sets if the sound will loop infinitely. Note that this method takes
     * precedence over <code>setLoopCount(int)</code>.
     * @param loop if the sound should loop forever until stopped
     */
    public void setLooping(boolean loop){
        source.setLooping(loop, this);
    }
    
    /**
     * Sets the number of times the sound should be looped before stopping.
     * @param loops number of times to loop the sound
     */
    public void setLoopCount(int loops){
        source.setLoopCount(loops, this);
    }
    
    /**
     * @return if the sound is playing
     */
    public boolean isPlaying() {
        //If the sound is no longer active, the sound is not considered to be
        //playing no matter the state of the source
        return alive ? source.isPlaying() : false;
    }

    /**
     * @return if the sound is still active
     */
    public boolean isAlive(){
        return alive;
    }
    
    /**
     * Destroys the sound and relinquishes control of the source.
     */
    public void destroy() {
        source.stop(this);
        source.setController(null);
        
        sounddata = null;
        alive = false;
    }
}
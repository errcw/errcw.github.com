package sheep.sound;

import org.lwjgl.openal.AL10;

/**
 * @author Eric Woroshow
 */
public class ALSource {

    private final int sourceID;

    private ALSoundData attatchedData = null;

    private final ALSound dummycontroller = new ALSound();
    private ALSound controller = null;

    /**
     * Creates a new OpenAL source.
     */
    protected ALSource() {
        ALSoundSystem.scratch.clear().limit(1);
        AL10.alGenSources(ALSoundSystem.scratch);
        sourceID = ALSoundSystem.scratch.get(0);
        
        setController(dummycontroller);
    }

    /**
     * Plays the buffer currently attatched to the source. Calling
     * <code>play()</code> on a source that is already playing will restart
     * the source from the beginning.
     */
    public void play(ALSound control) {
        if (!isControlledBy(control)) return;
        AL10.alSourcePlay(sourceID);
    }

    /**
     * Pauses the source. Calling <code>play()</code> will continue playing
     * the sample from the point where it was paused.
     */
    public void pause(ALSound control) {
        AL10.alSourcePause(sourceID);
    }

    /**
     * Stops the source. The source's state is preserved.
     */
    public void stop(ALSound control) {
        AL10.alSourceStop(sourceID);
    }

    /**
     * Rewinds the source. Stops the source and sets it to its initial state.
     * The source's state is preserved, except the sample position which is
     * reset to the beginning.
     */
    public void rewind(ALSound control) {
        AL10.alSourceRewind(sourceID);
    }

    /**
     * Sets a float property of the source.
     */
    public void set(int property, float value, ALSound control) {
        AL10.alSourcef(sourceID, property, value);
    }

    /**
     * Sets a vector property of the source.
     */
    public void set(int property, float x, float y, float z, ALSound control) {
        AL10.alSource3f(sourceID, property, x, y, z);
    }

    /**
     * Sets an integer property of the source.
     */
    public void set(int property, int value, ALSound control) {
        AL10.alSourcei(sourceID, property, value);
    }

    /**
     * Gets an integer property of the source.
     * @return the source integer property
     */
    public int getInt(int property) {
        return AL10.alGetSourcei(sourceID, property);
    }

    /**
     * Gets a float property of the source.
     * @return the source float property
     */
    public float getFloat(int property) {
        return AL10.alGetSourcef(sourceID, property);
    }
    
    /**
     * @return the ID of the source
     */
    protected int getALSourceID() {
        return sourceID;
    }

    /**
     * Sets the looping state of the source.
     * @param loop if the source should loop infinitely
     */
    public void setLooping(boolean loop, ALSound control) {
        set(AL10.AL_LOOPING, loop ? AL10.AL_TRUE : AL10.AL_FALSE, control);
    }

    /**
     * Sets the number of times the sample will loop when played. This method
     * can only be called <i>after </i> binding sound data to the source.
     * @param loops number of times to loop the sample
     */
    public void setLoopCount(int loops, ALSound control) {
        //clear any buffers previously queued
        set(AL10.AL_BUFFER, AL10.AL_NONE, control);

        ALSoundSystem.scratch.clear().limit(loops);
        for (int i = 0; i < loops; i++)
            ALSoundSystem.scratch.put(i, attatchedData.getALBufferID());

        AL10.alSourceQueueBuffers(sourceID, ALSoundSystem.scratch);
    }

    /**
     * @return if the source is playing
     */
    public boolean isPlaying() {
        int state = AL10.alGetSourcei(sourceID, AL10.AL_SOURCE_STATE);
        return state == AL10.AL_PLAYING;
    }

    /**
     * Attaches sound data to be played to the source.
     * 
     * @param data the sound to be played
     */
    public void attatch(ALSoundData data, ALSound control) {
        set(AL10.AL_BUFFER, data.getALBufferID(), control);
        attatchedData = data;
    }
    
    /**
     * @return if the source is not currently bound to a sound
     */
    public boolean isControllable(){
        return controller == dummycontroller;
    }
    
    /**
     * Sets the <code>ALSound</code> which currently has control of the source.
     * The <code>ALSound</code> will be the only object able to issue commands
     * to the source. Setting the controller to <code>null</code> results in
     * no sound being able to control the source until a new controller is set.
     * @param sound controller of the source
     */
    protected void setController(ALSound sound){
        if (sound != null)
            controller = sound;
        else
            //We cannot simply consider the controller to be null, as
            //that would result in the source still being controllable.
            //Instead, we assign control to a dummy sound so that
            //isControlledBy(ALSound) will never return true until a
            //proper controller is specified.
            controller = dummycontroller;
    }

    /**
     * @return if the source is controlled by the given sound
     */
    private boolean isControlledBy(ALSound sound) {
        return controller == sound;
    }

    /**
     * Destroys the source.
     */
    public void destroy() {
        ALSoundSystem.scratch.clear().limit(1);
        ALSoundSystem.scratch.put(0, sourceID);
        AL10.alDeleteSources(ALSoundSystem.scratch);
    }
}
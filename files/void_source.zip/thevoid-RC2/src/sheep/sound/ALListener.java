package sheep.sound;

import org.lwjgl.openal.AL10;

/**
 * Wraps an OpenAL Listener. 
 * @author Eric Woroshow
 */
public class ALListener {
    
    //Only allow package-level construction
    protected ALListener() {}
    
    /**
     * Sets a float value of the listener.
     */
    public void set(int property, float value) {
        AL10.alListenerf(property, value);
    }
    
    /**
     * Sets an integer value of the listener.
     */
    public void set(int property, int value) {
        AL10.alListeneri(property, value);
    }
    
    /**
     * Sets a vector value of the listener
     */
    public void set(int property, float x, float y, float z) {
        AL10.alListener3f(property, x, y, z);
    }
    
    /**
     * @return a float property of the listener
     */
    public float getFloat(int property) {
        return AL10.alGetListenerf(property);
    }
    
    /**
     * @return an integer property of the listener
     */
    public int getInt(int property) {
        return AL10.alGetListeneri(property);
    }
}

package sheep.attributes;

import org.w3c.dom.Element;

import sheep.Resource;
import sheep.util.XMLUtils;
import org.lwjgl.util.vector.Vector2f;

import com.shavenpuppy.jglib.Resources;
import com.shavenpuppy.jglib.sprites.Animation;

/**
 * Attributes for a normal star
 * @author Hemesh
 */
public class StarAttributes extends Resource {
    private String animationResource;
    private Animation animation;
    private Vector2f position = new Vector2f();
    
    private float radius;
    private float gravity;
    private float gravityInc;
    private int mass;

    /**
     * Resource constructor.
     * @param name unique name of this Resource
     */
    public StarAttributes(String name) {
        super(name);
    }

    protected void doCreate() throws Exception {
        animation = (Animation)Resources.get(animationResource);
    }
    
    protected void doDestroy() {}

    protected void load(Element e) {
        String location;
        float xcom, ycom;
        //Load resource pointers
        animationResource = XMLUtils.getString(e, "animation");

        //Load primitives
        mass = XMLUtils.getInt(e, "mass");
        radius = XMLUtils.getFloat(e, "radius");
        gravity = XMLUtils.getFloat(e, "gravity");
        gravityInc = XMLUtils.getFloat(e, "gravityinc");
        xcom = XMLUtils.getFloat(e, "locationx");
        ycom = XMLUtils.getFloat(e, "locationy");
        position.set (xcom, ycom);
    }

    /**
     * @return the collision radius of the sheep
     */
    public float getRadius() {
        return radius;
    }
    
    /**
     * @return the mass of the Ship
     */
    public int getMass(){
        return mass;
    }
    
    
    /**
     * @return the default gravity modifier
     */
    public float getGravity() {
        return gravity;
    }
    
    
    /**
     * @return the amount the gravity modifier increases each frame
     */
    public float getGravityIncrease() {
        return gravityInc;
    }
    
    public Vector2f getPosition (){
        return position;    
    }
    
    /**
     * @return the naming prefix for the rotated ship images
     */
    public Animation getAnimation() {
        return animation;
    }

}

package sheep.attributes;

import org.w3c.dom.Element;

import com.shavenpuppy.jglib.sprites.Animation;

import sheep.Resource;
import sheep.Resources;
import sheep.sound.ALSoundData;
import sheep.util.XMLUtils;

/**
 * A series of attributes that define a Ship Entity.
 * 
 * @author Eric Woroshow
 */
public class ShipAttributes extends Resource {

    private String spritebase;
    private String deathAnimation;
    private String enginesound;
    
    private Animation death;
    
    private float radius;
    private float rotationalvel;
    private int mass;
    private float maxmassvel;
    private int masslaunchdelay;
    private int ejectionmass;

    private ALSoundData engineSoundData;

    /**
     * Resource constructor.
     * @param name unique name of this Resource
     */
    public ShipAttributes(String name) {
        super(name);
    }

    protected void doCreate() throws Exception {
        engineSoundData = (ALSoundData)Resources.get(enginesound);
        death = (Animation)com.shavenpuppy.jglib.Resources.get(deathAnimation);
    }

    protected void doDestroy() {
        engineSoundData = null;
        death = null;
    }

    protected void load(Element e) {
        //Load resource pointers
        spritebase = XMLUtils.getString(e, "spritebase");
        deathAnimation = XMLUtils.getString(e, "deathanim");
        enginesound = XMLUtils.getString(e, "engines");
        //Load primitives
        rotationalvel = XMLUtils.getFloat(e, "rotationalvel");
        mass = XMLUtils.getInt(e, "mass");
        maxmassvel = XMLUtils.getFloat(e, "maxmassvel");
        masslaunchdelay = XMLUtils.getInt(e, "masslaunchdelay");
        ejectionmass = XMLUtils.getInt(e, "ejectionmass");
        radius = XMLUtils.getFloat(e, "radius");
    }
    
    /**
     * @return the baa sound of the sheep
     */
    public ALSoundData getEngineSound(){
        return engineSoundData;
    }    
    
    /**
     * @return the rotational velocity in radians/tick
     */
    public float getRotationalVel() {
        return rotationalvel;
    }

    /**
     * @return the collision radius of the sheep
     */
    public float getRadius() {
        return radius;
    }
    
    /**
     * @return the mass of the Ship
     */
    public int getMass(){
        return mass;
    }
    
    
    /**
     * @return the maximum velocity of a launched mass
     */
    public float getMaxMassVel() {
        return maxmassvel;
    }
    
    
    /**
     * @return the number of ticks between mass launches
     */
    public int getMassLaunchDelay() {
        return masslaunchdelay;
    }
    
    /**
     * @return the mass of the pellets ejected by the ship
     */
    public int getEjectionMass(){
        return ejectionmass;
    }
    
    /**
     * @return the naming prefix for the rotated ship images
     */
    public String getSpriteBase() {
        return spritebase;
    }
    
    /**
     * @return the death animation for the sheep
     */
    public Animation getDeathAnimation() {
        return death;
    }
}
package sheep;

import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.net.URL;
import java.util.HashMap;
import java.util.Iterator;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import sheep.util.XMLUtils;

/**
 * Resource management subsystem.
 * 
 * @author Eric Woroshow
 */
public class Resources {

    private static final HashMap resources = new HashMap(256);
    private static final HashMap types = new HashMap(10);

    //Disallow construction
    private Resources() {}
    
    /**
     * Provides a convenience method of calling
     * <code>Resources.class.getClassLoader().getResource(name)</code>
     * @param name the resource name
     * @return 	a URL object for reading the resource, or null if the resource could
     *          not be found or the invoker doesn't have adequate privileges to
     *          get the resource.
     */
    public static URL getResource(String name){
        return Resources.class.getClassLoader().getResource(name);
    }
    
    /**
     * Provides a convenience method of calling
     * <code>Resources.class.getClassLoader().getResourceAsStream(name)</code>
     * @param name the resource name
     * @return an input stream for reading the resource, or null if the resource
     *         could not be found
     */
    public static InputStream getResourceAsStream(String name){
        return Resources.class.getClassLoader().getResourceAsStream(name);
    }

    /**
     * Gets a resource by its name. If the resource has not yet been created,
     * then it is created.
     * 
     * @param name the name of the resource to return
     * @return the created resource
     * @throws Exception if the resource could not be gotten
     */
    public static Resource get(String name) throws Exception {
        Resource res = (Resource) resources.get(name);
        res.create();

        return res;
    }

    /**
     * Adds a resource to the set. Any resource having the same name will be
     * overwritten.
     * 
     * @param res the resource to add
     */
    public static void add(Resource res) {
        resources.put(res.getName(), res);
    }

    /**
     * Removes a resource by its name. If the resource has been created it will
     * be destroyed.
     * 
     * @param name name of the resource to remove
     */
    public static void remove(String name) {
        Resource res = (Resource) resources.remove(name);
        if (res != null && res.isCreated()) res.destroy();
    }

    /**
     * Resets all the resources. Any created resources are destoyed and then
     * recreated.
     * 
     * @throws Exception if any resource was not successfully recreated
     */
    public static void reset() throws Exception {
        for (Iterator i = resources.values().iterator(); i.hasNext();) {
            Resource res = (Resource) i.next();
            if (res.isCreated()) {
                res.destroy();
                res.create();
            }
        }
    }

    /**
     * Clears and destroys the all the resources.
     */
    public static void clear() {
        for (Iterator i = resources.values().iterator(); i.hasNext();) {
            Resource res = (Resource) i.next();
            if (res.isCreated()) res.destroy();
        }
        resources.clear();

        System.gc();
    }

    //
    //XML loading routines
    //

    public static void loadXML(InputStream in) throws Exception {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document doc = builder.parse(in);
        Element root = doc.getDocumentElement();

        NodeList nodes = root.getChildNodes();
        for (int i = 0; i < nodes.getLength(); i++) {
            if (nodes.item(i) instanceof Element) {
                Element element = (Element) nodes.item(i);
                parse(element);
            }
        }
    }

    private static void parse(Element e) throws Exception {
        if (e.getNodeName().equals("resourcetypes")) {
            createResourceTypes(e);
        } else if (e.getNodeName().equals("include")) {
            String file = XMLUtils.getString(e, "file");
            InputStream in = getResourceAsStream(file);

            if (in != null) {
                Log.log("Including resource file " + file);
                loadXML(in);
            }
        } else {
            String restype = e.getNodeName();
            Class clas = (Class) types.get(restype);
            if (clas != null) createResource(e, clas);
        }
    }

    private static void createResourceTypes(Element e) throws Exception {
        NodeList nodes = e.getChildNodes();
        for (int i = 0; i < nodes.getLength(); i++) {
            if (nodes.item(i) instanceof Element) {
                Element elem = (Element) nodes.item(i);
                if (!elem.getNodeName().equals("type")) continue;

                String tag = elem.getAttribute("tag");
                String className = elem.getAttribute("class");

                Class c = Class.forName(className);
                if (!Resource.class.isAssignableFrom(c)) //must be Resource subclass
                	throw new Exception("Class " + c + " is not a Resource.");

                Log.log("Defining new Resource type '" + tag + "' : " + c);
                types.put(tag, c);
            }
        }
    }

    private static void createResource(Element resElement, Class resClass) throws Exception {
        Resource resource;

        String name = XMLUtils.getString(resElement, "name");
        Log.log("Loading resource: " + name);

        try {
            Constructor ctor = resClass.getConstructor(new Class[] {String.class});
            resource = (Resource) ctor.newInstance(new Object[] {name});
            resource.load(resElement);
            add(resource);
        } catch (Exception e) {
            Log.log("Could not create resource " + name);
            Log.log(e);
        }
    }
}
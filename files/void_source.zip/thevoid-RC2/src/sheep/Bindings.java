package sheep;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.util.HashMap;

import org.lwjgl.input.Controller;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

/**
 * Defines a series of key-to-action bindings.
 * 
 * @author Eric Woroshow
 * @author princec, for general structure and ideas and some code
 */
public class Bindings {

    public static final int UNBOUND = 0;
    public static final int KEYBOARD = 1;
    public static final int MOUSE = 2;
    public static final int CONTROLLER = 3;

    private static final Bindings[] bindings = new Bindings[VoidGame.MAX_PLAYERS];

    static {
        for (int i = 0; i < bindings.length; i++)
            bindings[i] = new Bindings();
    }

    public static Bindings getPlayerBindings(int player) {
        return bindings[player];
    }

    public static void save(OutputStream out) throws IOException {
        DataOutputStream oout = new DataOutputStream(out);
        //write all the player's bindings
        for (int i = 0; i < bindings.length; i++) {
            Bindings bind = bindings[i];

            oout.writeInt(bind.BINDINGS.length);
            for (int j = 0; j < bind.BINDINGS.length; j++) {
                Binding binding = bind.BINDINGS[j];

                oout.writeUTF(binding.getName());
                oout.writeInt(binding.type);
                oout.writeInt(binding.id);
            }
        }
    }

    public static void load(InputStream in) throws Exception {
        DataInputStream oin = new DataInputStream(in);
        for (int i = 0; i < bindings.length; i++) {
            Bindings bind = bindings[i];

            final int nbindings = oin.readInt();
            for (int j = 0; j < nbindings; j++) {
                String name = oin.readUTF();
                int type = oin.readInt();
                int id = oin.readInt();

                //Try to retrieve the binding from the default bindings map
                Binding b = (Binding) bind.bindingsmap.get(name);
                //If it isn't there, create it and add it to the map
                if (b == null) {
                    b = bind.new Binding(name);
                    bind.bindingsmap.put(name, b);
                }
                b.bind(type, id);
            }
        }
    }

    public class Binding implements Serializable {
        /** Name of this Binding */
        private String name;
        /** Type of controller this Binding is bound to */
        private int type;
        /** Unique id of this Binding */
        private int id;

        private Binding(String name) {
            this.name = name;
        }

        public void bind(int type, int id) {
            this.type = type;
            this.id = id;
            //TODO: on bind, validate every other binding
        }

        /**
         * @return if this Binding is active
         */
        public boolean isDown() {
            switch (type) {
            case UNBOUND:
                return false;
            case KEYBOARD:
                return Keyboard.isKeyDown(id);
            case MOUSE:
                return Mouse.isButtonDown(id);
            case CONTROLLER:
                return Controller.isButtonDown(id);
            default:
                assert false; //should never reach this point
                return false;
            }
        }

        public boolean isValid() {
            switch (type) {
            case UNBOUND:
                return false;
            case KEYBOARD:
                return Keyboard.isCreated() && id < 256;
            case MOUSE:
                return Mouse.isCreated() && id < Mouse.getButtonCount();
            case CONTROLLER:
                return Controller.isCreated() && id < Controller.getButtonCount();
            default:
                assert false; //should never reach this point
                return false;
            }
        }

        /**
         * Attempts to bind this Binding to a control. Queries the state of the
         * keyboard, mouse, and keyboard (in that order) looking for a pressed
         * control. If one is found, this Binding is bound to it.
         * 
         * @return if a this Binding was successfully bound to a control
         */
        public boolean determine() {            
            while (Keyboard.next())
                if (Keyboard.getEventKeyState()) {
                    bind(KEYBOARD, Keyboard.getEventKey());
                    return true;
                }

            /*while(Mouse.next())
                if(Mouse.getEventButtonState()) {
                    bind(MOUSE, Mouse.getEventButton());
                    return true;
                }*/
                
            for (int i = 0; i < Controller.getButtonCount(); i++)
                if (Controller.isButtonDown(i)) {
                    bind(CONTROLLER, i);
                    return true;
                }

            return false;
        }

        /**
         * @return the name of this Binding
         */
        public String getName() {
            return name;
        }

        /**
         * @return if the Object is a Binding with identical type and id
         * @see java.lang.Object#equals(java.lang.Object)
         */
        public boolean equals(Object o) {
            return (o != null && o instanceof Binding && ((Binding) o).id == id && ((Binding) o).type == type);
        }

        /**
         * @return a String representation of the binding
         * @see java.lang.Object#toString()
         */
        public String toString() {
            switch (type) {
            case UNBOUND:
                return "Unbound";
            case KEYBOARD:
                String keyname = Keyboard.getKeyName(id);
                return (keyname != null) ? "Key " + keyname : "Unknown key";
            case MOUSE:
                switch (id) {
                case 0:
                    return "Left Mouse Button";
                case 1:
                    return "Right Mouse Button";
                case 2:
                    return "Middle Mouse Button";
                default:
                    return "Mouse button " + (id + 1);
                }
            case CONTROLLER:
                return "Controller button " + (id + 1);
            default:
                assert false; //should never reach this point
                return "xxx";
            }
        }
    }

    private boolean enabled = true;

    /** Map of names to Bindings */
    private final HashMap bindingsmap = new HashMap();

    private final Binding THRUST_RIGHT = new Binding("Thrust Right");
    private final Binding THRUST_LEFT = new Binding("Thrust Left");
    private final Binding LAUNCH_MASS = new Binding("Launch Mass");
    private final Binding[] BINDINGS = { THRUST_RIGHT, THRUST_LEFT, LAUNCH_MASS };

    public Bindings() {
        //register all the predefined bindings
        for (int i = 0; i < BINDINGS.length; i++)
            bindingsmap.put(BINDINGS[i].getName(), BINDINGS[i]);
    }
    
    /**
     * @return an array of Bindings
     */
    public Binding[] getBindingsArray() {
        return BINDINGS;
    }

    public boolean isThrustLeftDown() {
        return enabled && THRUST_RIGHT.isDown();
    }

    public boolean isThrustRightDown() {
        return enabled && THRUST_LEFT.isDown();
    }

    public boolean isLaunchMassDown() {
        return enabled && LAUNCH_MASS.isDown();
    }

    public boolean validate() {
        return false;
    }

    /**
     * Enables or disables all the Bindings for this player.
     */
    public void setEnabled(boolean on) {
        enabled = on;
    }
}
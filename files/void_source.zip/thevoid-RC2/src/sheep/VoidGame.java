package sheep;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

import net.puppygames.gui.Interface;

import org.lwjgl.Display;
import org.lwjgl.DisplayMode;
import org.lwjgl.Sys;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.Window;

import sheep.gui.RootMenuDialog;
import sheep.sound.ALOggStream;
import sheep.sound.ALSoundStream;
import sheep.sound.ALSoundSystem;
import sheep.sound.ALStreamingSound;

import com.shavenpuppy.jglib.Image;
import com.shavenpuppy.jglib.opengl.nvidia.NvidiaInitializer;

/**
 * Core game module. Contains the intialization and main loop code.
 * @author Eric Woroshow
 */
public final class VoidGame {

    public static final String GAME_TITLE = "the void";
    public static final String GAME_VERSION = "1.0";
    
    public static final int MAX_PLAYERS = 4;
    
    public static final int WIDTH = 640;
    public static final int HEIGHT = 480;
    
    public static final int TICK_RATE = 1;
    private static final float FRAMETIME = 1.0f / 60.0f;
    private static final String LOGFILE = "log.txt";

    private static boolean finished;
    
    private static RootMenuDialog rootmenu;
    private static BattleField battlefield;
    private static ALStreamingSound musStream;
    
    //Disallow construction
    private VoidGame() {}

    /**
     * Entry point for the application.
     * @param args command line arguments
     */
    public static void main(String[] args) {
        try {
            init();
            run();
        } catch (Exception e) {
            e.printStackTrace();
            Sys.alert(GAME_TITLE, "An error has occured and the game must exit.");
        } finally {
            cleanup();
        }
    }
    
    public static void init() throws Exception {
        Log.init(LOGFILE); //for release, pipe the log to a file
        Log.log("Log initialized");
        
        DisplayMode[] modes = org.lwjgl.util.Display.getAvailableDisplayModes(640, 480, 640, 480, 16, 32, 0, 85);
        org.lwjgl.util.Display.setDisplayMode(modes, new String[]{"freq"});
        Window.create(GAME_TITLE);
        Mouse.setGrabbed(true);
        Log.log("Window created");
        
        ALSoundSystem.init(16);
        playMusic();
        Log.log("Sound system initialized");
        
        NvidiaInitializer.initialize(2048 * 2048, 0);        
        Log.log("Memory allocated");
        
        Log.log("Loading resources...");
        Resources.loadXML(Resources.getResourceAsStream("resources.xml"));
        com.shavenpuppy.jglib.Resources.load(Resources.getResourceAsStream("spgl_res.dat"));
        Log.log("Resources loaded");
        
        Image.setDecompressor(new com.shavenpuppy.jglib.jpeg.SunJPEGDecompressor());
        
        Interface.init(WIDTH, HEIGHT, 640, 480);
        Interface.setTicksPerFrame(TICK_RATE);
        rootmenu = new RootMenuDialog();
        battlefield = new BattleField();
        Log.log("GUI initialized");
        
        Bindings.load(Resources.getResourceAsStream("bindings.dat"));
        Log.log("Control bindings loaded");
        
        Log.log("Intializing game...");
        BattleField.init();
        PhysicsEngine.init((float)WIDTH);
        displayRootMenu();
        
        Log.log("Initialization complete!");
    }

    public static void run() {
        while (!finished) {
            Window.update();

            if (Window.isCloseRequested()) {
                finished = true;
            } else if (Window.isActive()) {               
                logic();
                render();                
                
                Display.sync(60);
            } else {
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {}
                logic();
                if (Window.isVisible() || Window.isDirty())
                	render();
            }
        }
    }
    
    public static void logic() {
        ALSoundSystem.update();
        if (!musStream.isPlaying())
            playMusic();
        Interface.tick();
    }
    
    public static void render() {
        GL11.glClear(GL11.GL_COLOR_BUFFER_BIT | GL11.GL_DEPTH_BUFFER_BIT);
        GL11.glLoadIdentity();

        Interface.render();
    }

    public static void cleanup() {
        Log.log("Cleaning up...");
        //close the window
        if (Window.isCreated()) {
            Window.destroy();
            Display.resetDisplayMode();
        }
        
        Interface.cleanup();
        
        NvidiaInitializer.cleanup();
        
        //destroy all of the resources
        sheep.Resources.clear();
        com.shavenpuppy.jglib.Resources.clear();
        
        Log.log("Cleanup complete");
        System.gc();
    }
        
    public static void startNewGame(int players) {
        rootmenu.close();
        battlefield.startNewGame(players);
    }
    
    public static void displayRootMenu() {
        battlefield.endGame(); //end any game in progress
        rootmenu.open();
    }
    
    public static void finish() {
        finished = true;
    }
    
    private static void playMusic() {
        try {
            FileInputStream fin = new FileInputStream(sheep.Resources.getResource("battle.ogg").getFile());
            ALSoundStream mus = new ALOggStream(fin);
            musStream = ALSoundSystem.playStream(mus);
        } catch (FileNotFoundException e) {
            Log.log(e);
        }
    }
}
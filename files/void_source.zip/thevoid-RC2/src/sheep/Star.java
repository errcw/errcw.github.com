package sheep;

import java.util.ArrayList;
import java.util.Iterator;

import org.lwjgl.opengl.GL11;
import org.lwjgl.util.vector.Vector2f;

import sheep.attributes.StarAttributes;

import com.shavenpuppy.jglib.sprites.Sprite;

/**
 * Describes a star object.
 * @author Eric Woroshow
 */
public class Star extends Entity {
    /** Length modifier for Streaks */
    private static final float STREAK_MOD = 8.0f;
    /** Gravity modifier for Streaks */
    private static final float STAR_GRAVITY = 5.0f;
    
    private static float randomPosition() {
        return ((float)Math.random() - 0.5f) * 2.0f * 900.0f; 
    }
    
    private class Streak {
        final Vector2f position = new Vector2f(randomPosition() + getPosition().getX(), 
                                               randomPosition() + getPosition().getY());
        final Vector2f velocity = new Vector2f(0, 0);
    }
    
    private Sprite sprite;
    private StarAttributes attrs;
    /** List of streaks bound to this Star */
    private ArrayList streaks;
    
    public Star(StarAttributes attrs) {
        this.attrs = attrs;
        
        streaks = new ArrayList(64);
        setPosition(attrs.getPosition());
        radius = attrs.getRadius();
    }
    
    public void onSpawn() {
        sprite = BattleField.allocateSprite(this);
        sprite.setLocation((int)position.getX(), (int)position.getY(), 0);
        sprite.setAnimation(attrs.getAnimation());
        
        for (int i = 0; i < 300; i++)
            streaks.add(new Streak());
    }
    
    /**
     * Updates all the Streaks headed for this Star.
     */
    public void update() {
        for (Iterator i = streaks.iterator(); i.hasNext();) {
            Streak s = (Streak) i.next();

            Vector2f.sub(position, s.position, scratch);
            float len2 = scratch.lengthSquared();
            Vector2f accel = (Vector2f) new Vector2f().set(scratch).scale(PhysicsEngine.STAR_GRAVITY / len2);

            s.velocity.translate(accel.getX(), accel.getY());
            s.position.translate(s.velocity.getX(), s.velocity.getY());

            if (len2 < radius * radius) i.remove();
        }
        
        for (int i = 0; i < 3; i++)
            streaks.add(new Streak());
    }
    
    /**
     * Renders all of the streaks.
     */
    public void render() {
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        
        GL11.glEnable(GL11.GL_POINT_SMOOTH);
        GL11.glEnable(GL11.GL_LINE_SMOOTH);
        GL11.glHint(GL11.GL_LINE_SMOOTH_HINT, GL11.GL_NICEST);
        GL11.glHint(GL11.GL_POINT_SMOOTH_HINT, GL11.GL_NICEST);
        GL11.glLineWidth(3.0f);
        GL11.glPointSize(3.0f);
        
        GL11.glColor3f(1f, 1f, 1f);
        GL11.glBegin(GL11.GL_LINES);
        {
            for (int i = 0; i < streaks.size(); i++) {
                Streak s = (Streak) streaks.get(i);
                
                Vector2f v = new Vector2f();
                v.set(s.velocity);
                v.scale(STREAK_MOD);
                Vector2f.sub(s.position, v, scratch);
                
                GL11.glVertex2f(scratch.getX(), scratch.getY());
                GL11.glVertex2f(s.position.getX(), s.position.getY());
            }
        }
        GL11.glEnd();
    }

    /**
     * @return true
     */
    public boolean canCollide() {
        return true;
    }

    /**
     * @see sheep.Entity#inCollisionWith(sheep.Entity)
     */
    public void inCollisionWith(Entity entity) {
        entity.inCollisonWithStar(this);
    }

    /**
     * Immediately kills the ship.
     * @see sheep.Entity#inCollisionWithShip(Ship)
     */
    public void inCollisionWithShip(Ship s) {
        s.kill();
    }

    /**
     * Instantly destroys the mass.
     * @see sheep.Entity#inCollisonWithMass(Mass)
     */
    public void inCollisonWithMass(Mass m) {
        m.remove();
    }
    
    //Should never occur - at least not in v1.0
    public void inCollisonWithStar(Star s) {
        assert false;
    }
}

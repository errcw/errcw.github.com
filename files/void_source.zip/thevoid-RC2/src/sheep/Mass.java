package sheep;

import org.lwjgl.util.vector.Vector2f;

import sheep.sound.ALSoundData;
import sheep.sound.ALSoundSystem;

import com.shavenpuppy.jglib.Resources;
import com.shavenpuppy.jglib.sprites.Animation;
import com.shavenpuppy.jglib.sprites.Sprite;


/**
 * @author Eric Woroshow
 */
public class Mass extends Entity {
    private static ALSoundData collision;
    
    static {
        try {
            collision = (ALSoundData)sheep.Resources.get("massmasscollide.sound");
        } catch (Exception e) { Log.log(e); } 
    }
    
    private Sprite sprite;
    
    private Vector2f nvelocity = new Vector2f();
    private boolean updateVelocity = false;
    
    public Mass(Vector2f initPosition, Vector2f initVelocity) {
        position.set(initPosition);
        velocity.set(initVelocity);
        radius = 8;
    }
    
    protected void onSpawn() {
        sprite = BattleField.allocateSprite(this);
        try {
            sprite.setAnimation((Animation)Resources.get("mass.animation"));
        } catch (Exception e) { Log.log(e); }
    }
    
    protected void onRemoval() {
        sprite.deallocate();
    }

    /**
     * Updates the mass for this frame
     * @see sheep.Entity#update()
     */
    public void update() {
        //Update velocity from collisions
        if (updateVelocity) {
            velocity.set(nvelocity);
            updateVelocity = false;
        }
        
        //handle any physics
        position.translate(velocity.getX(), velocity.getY());
        sprite.setLocation((int)position.getX(), (int)position.getY(), 0);
        
        //Bounce off the edges
        if (   position.getX() < 0 || position.getX() > VoidGame.WIDTH
            || position.getY() < 0 || position.getY() > VoidGame.HEIGHT)
            velocity.negate();
    }

    /**
     * Does nothing.
     * @see sheep.Entity#render()
     */
    public void render() {}

    /**
     * @return true
     * @see sheep.Entity#canCollide()
     */
    public boolean canCollide() {
        return true;
    }

    /**
     * Notifies the other Entity of a collision with a Mass.
     * @see sheep.Entity#inCollisionWith(sheep.Entity)
     */
    public void inCollisionWith(Entity entity) {
        entity.inCollisonWithMass(this);
    }

    /**
     * We simply die.
     * @see sheep.Entity#inCollisonWithStar(sheep.Star)
     */
    public void inCollisonWithStar(Star s) {}

    /**
     * Alters this Mass's velocity.
     * @see sheep.Entity#inCollisionWithShip(sheep.Ship)
     */
    public void inCollisionWithShip(Ship s) {
        nvelocity.set(physicsEngine.diffMassCollision(this, s));
        updateVelocity = true;
    }

    /**
     * Alters velocity based on the collision.
     * @see sheep.Entity#inCollisonWithMass(Mass)
     */
    public void inCollisonWithMass(Mass m) {
        ALSoundSystem.play(collision);
        nvelocity.set(physicsEngine.sameMassCollision(velocity, m.getVelocity()));
        updateVelocity = true;
    }
}

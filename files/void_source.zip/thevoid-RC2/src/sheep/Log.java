package sheep;

import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.Date;

/**
 * A simple logging system. It is possible to redirect log output to either
 * the system output stream or a file. 
 *
 * @author Eric Woroshow
 */
public class Log {

    /** Output stream to which the log file is written */
    private static PrintStream output;
    /** True if logging is enabled */
    private static boolean enabled = false;
    
    /**
     * Initializes the logging system.
     * @param logfile name of the log file, or null for system output
     * @throws Exception if an error occurs directing output
     */
    public static void init(String logfile) throws Exception {    
        enabled = true;
        
        if (logfile == null) {
            output = System.out;
        } else {
            output = new PrintStream(new FileOutputStream(logfile));
        }
    }
    
    /**
     * Sets if logging is enabled.
     * @param on if the 
     */
    public static void setEnabled(boolean on){
        enabled = on;
    }

    /**
     * Logs a given message.
     * @param s message to record
     */
    public static void log(String s) {
        if (!enabled) return;
        
        output.print(new Date());
        output.print('\t');
        output.println(s);
    }

    /**
     * Logs a given exception.
     * @param e exception to record
     */
    public static void log(Throwable e) {
        if (!enabled) return;

        log("Throwable");
        e.printStackTrace(output);
    }
}
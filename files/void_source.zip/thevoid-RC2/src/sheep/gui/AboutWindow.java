/* 
 * Copyright (c) 2003 Shaven Puppy Ltd
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are 
 * met:
 * 
 * * Redistributions of source code must retain the above copyright 
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in the
 *   documentation and/or other materials provided with the distribution.
 *
 * * Neither the name of 'Shaven Puppy' nor the names of its contributors
 *   may be used to endorse or promote products derived from this software
 *   without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package sheep.gui;

import net.puppygames.gui.CommandButton;
import net.puppygames.gui.CommandButtonListener;
import net.puppygames.gui.ScrollPane;
import net.puppygames.gui.TextArea;
import net.puppygames.gui.Window;

import sheep.VoidGame;

import com.shavenpuppy.jglib.Resources;
import com.shavenpuppy.jglib.opengl.GLFont;
import com.shavenpuppy.jglib.resources.TextResource;

/**
 * The "About" window which brings up the credits and such.
 * 
 * @author foo
 */
public class AboutWindow extends Window {
    
    /** Scroll ticker */
    private int tick;

    /** A great big text area with all the blurb in it */
    private TextArea blurb;
    
    /** A scrollpane with the text in it */
    private ScrollPane scrollPane;
    
    /** OK button */
    private CommandButton okButton;

    /**
     * Constructor
     * @param title
     */
    public AboutWindow() throws Exception {
        super("About " + VoidGame.GAME_TITLE + " " + VoidGame.GAME_VERSION);
        
        blurb = new TextArea(((TextResource) Resources.get("about.text")).getText());
        blurb.setFont((GLFont) Resources.get("impact-plain-18.glfont"));
        blurb.setSize(500, 10000);
        
        scrollPane = new ScrollPane(ScrollPane.HORIZONTAL_SCROLLBAR_NEVER, ScrollPane.VERTICAL_SCROLLBAR_NEVER);
        scrollPane.setSize(500, 200);
        scrollPane.setLocation(0, 50);
        scrollPane.setView(blurb);
        
        okButton = new CommandButton("OK");
        okButton.setWidth(100);
        okButton.setLocation(200, 0);
        
        addChild(scrollPane);
        addChild(okButton);
        
        setSize(500, 300);
        setBorder(5, 5, 5, 5);
        centre().setY(100);

        okButton.addCommandButtonListener(new CommandButtonListener() {
            public boolean selected(CommandButton cb) {
                close();
                return false;
            }
        });

        open();

    }

    protected boolean doTick() {
        super.doTick();
        
        tick++;
        if (tick > (blurb.getHeight() + scrollPane.getHeight()) * 4)
            tick = 0;
        scrollPane.setViewLocation(0, blurb.getHeight() - tick / 4);
        
        return true;
    }
}

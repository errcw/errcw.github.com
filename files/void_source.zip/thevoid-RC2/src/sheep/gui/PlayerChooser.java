package sheep.gui;

import net.puppygames.gui.*;

import org.lwjgl.util.Color;

import sheep.VoidGame;

import com.shavenpuppy.jglib.Resources;
import com.shavenpuppy.jglib.opengl.GLFont;

/**
 * Allows a player to choose how many player ships will be present in the game.
 * @author Eric Woroshow / princec
 */
public class PlayerChooser extends Window {
    
    public PlayerChooser() throws Exception {
        super("Choose Players");
        createGUI();
    }

    /**
     * Creates the GUI.
     */
    private void createGUI() throws Exception {

        int n = VoidGame.MAX_PLAYERS + 1;
        GLFont font = (GLFont) Resources.get("impact-plain-24.glfont");
        Color white = new Color(255, 255, 255);
        for (int i = 2; i < n; i++) {
            final int players = i;
            CommandButton cb = new CommandButton(players + " Players");
            cb.pack().setLocation(50, (i-2) * 40).setWidth(150).setFont(font).setForegroundColor(white);
            cb.setEnabled(true);
            cb.addCommandButtonListener(new CommandButtonListener() {
                public boolean selected(CommandButton cb) {
                    // Close the dialog and start the game
                    close();
                    VoidGame.startNewGame(players);
                    return false;
                }
            });
            addChild(cb);
        }

        pack();
        setWidth(250);
        setBorder(5, 15, 5, 5);
        centre();
    }
}
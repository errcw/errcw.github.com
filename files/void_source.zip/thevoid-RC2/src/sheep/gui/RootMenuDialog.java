package sheep.gui;

import org.lwjgl.opengl.GL11;
import org.lwjgl.util.Color;

import sheep.Log;
import sheep.VoidGame;
import com.shavenpuppy.jglib.Resources;
import com.shavenpuppy.jglib.opengl.GLFont;
import com.shavenpuppy.jglib.opengl.GLTexture;
import com.shavenpuppy.jglib.sprites.Animation;

import net.puppygames.gui.CommandButton;
import net.puppygames.gui.CommandButtonListener;
import net.puppygames.gui.Dialog;
import net.puppygames.gui.Interface;
import net.puppygames.gui.MessageBox;
import net.puppygames.gui.MousePointer;
import net.puppygames.gui.Window;

/**
 * @author Eric Woroshow
 */
public class RootMenuDialog extends Dialog {
    
    private GLFont smallFont = (GLFont)Resources.get("impact-plain-18.glfont");
    private GLFont bigFont = (GLFont)Resources.get("impact-plain-24.glfont");
    
    private CommandButton newGameButton;
    private CommandButton optionsButton;
    private CommandButton bindingsButton;
    private CommandButton aboutButton;
    private CommandButton exitButton;
    
    static {
        try {
            MousePointer pointer = new MousePointer((Animation)Resources.get("pointer.animation"));
            
            Interface.setDefaultMousePointer(pointer);
            Interface.setWindowActiveTitleBarColor(new Color(196, 196, 196, 128));
            Interface.setWindowBackgroundColor(new Color(64, 64, 64, 128));
            Interface.setDefaultFont((GLFont) Resources.get("impact-plain-18.glfont"));
        } catch (Exception e) {
            Log.log("ERROR: exception setting GUI defaults");
            Log.log(e);
        }
    }
    
    private class EventHandler implements CommandButtonListener {
        public boolean selected(CommandButton button) {
            
            try {
                if (button == newGameButton) {
                    Log.log("GUI: new game event");
                    new PlayerChooser().open();
                } else if (button == optionsButton) {
                    Log.log("GUI: options dialog event");
                    new MessageBox("!", "Coming soon!", -1, MessageBox.OK_DIALOG, null).open();
                } else if (button == bindingsButton) {
                    Log.log("GUI: bindings dialog event");
                    new BindingsWindow();
                } else if (button == aboutButton) {
                    Log.log("GUI: about dialog event");
                    new AboutWindow();
                } else if (button == exitButton) {
                    Log.log("GUI: quit program event");                    
                    close();
                    VoidGame.finish();
                }
            } catch (Exception e) {
                Log.log(e);
            }
            
            return false;
        }
    }
    
    private class MainMenu extends Window  {
        private final EventHandler eventHandler = new EventHandler();
        
        MainMenu() throws Exception {
            super(VoidGame.GAME_TITLE);
            
            newGameButton = new CommandButton("Play Game");
            optionsButton = new CommandButton("Options");
            bindingsButton = new CommandButton("Controls");
            aboutButton = new CommandButton("About");
            exitButton = new CommandButton("Exit");
            
            createGUI();
            initEvents();
        }
        
        public void renderBackground() {
            Color backgroundColor = getBackgroundColor();
            setGLColor(backgroundColor.getRed(), backgroundColor.getGreen(), backgroundColor.getBlue(), backgroundColor.getAlpha());
            GL11.glEnable(GL11.GL_BLEND);
            GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
            GL11.glDisable(GL11.GL_TEXTURE_2D);
            GL11.glBegin(GL11.GL_QUADS);
            GL11.glVertex2f(0, 0);
            GL11.glVertex2f(size.getWidth() + border.getX() + border.getWidth(), 0);
            GL11.glVertex2f(size.getWidth() + border.getX() + border.getWidth(), size.getHeight() + border.getY() + border.getHeight());
            GL11.glVertex2f(0, size.getHeight() + border.getY() + border.getHeight());
            GL11.glEnd();
        }
        
        private void createGUI() throws Exception {
            setTitleFont(bigFont);
            
            addChild(newGameButton);
            addChild(optionsButton);
            addChild(bindingsButton);
            addChild(aboutButton);
            addChild(exitButton);
            
            newGameButton.setBounds(30, 225, 140, 32);
            optionsButton.setBounds(30, 175, 140, 32);
            bindingsButton.setBounds(30, 125, 140, 32);
            aboutButton.setBounds(30, 75, 140, 32);
            exitButton.setBounds(30, 25, 140, 32);

            pack();
            centre();
        }
        
        private void initEvents() {
            newGameButton.addCommandButtonListener(eventHandler);
            optionsButton.addCommandButtonListener(eventHandler);
            bindingsButton.addCommandButtonListener(eventHandler);
            aboutButton.addCommandButtonListener(eventHandler);
            exitButton.addCommandButtonListener(eventHandler);
        }
    }
    
    private final StreakingBackground streakingBackground;
    private final GLTexture blur1, blur2;
    private MainMenu mainmenu;

    public RootMenuDialog() throws Exception {
        super(VoidGame.GAME_TITLE);
        
        mainmenu = new MainMenu();
        
        streakingBackground = new StreakingBackground();
        streakingBackground.init();
        blur1 = (GLTexture)Resources.get("blur1.texture");
        blur2 = (GLTexture)Resources.get("blur2.texture");
        
        createGUI();
    }
    
    protected boolean doTick() {
        boolean ret = super.doTick();
        
        streakingBackground.update();
        
        return ret;
    }
    
    public void renderBackground() {
        final float half = VoidGame.HEIGHT / 2;
        
        GL11.glPushMatrix();
        GL11.glTranslatef(0, half / 2, 0);
        
        GL11.glColor3f(0.439f, 0.204f, 0.039f);
        GL11.glBegin(GL11.GL_QUADS);
        {
            GL11.glVertex2f(0, 0);
            GL11.glVertex2f(VoidGame.WIDTH, 0);
            GL11.glVertex2f(VoidGame.WIDTH, half);
            GL11.glVertex2f(0, half);
        }
        GL11.glEnd();
        
        //render small blurs
        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glEnable(GL11.GL_SCISSOR_TEST);
        GL11.glScissor(0, 0, VoidGame.WIDTH, (int)(half * 1.5f));
        
        GL11.glColor3f(1f, 1f, 1f);
        
        blur2.render();
        GL11.glBegin(GL11.GL_QUADS);
        {
            for (int i = 0; i < streakingBackground.sblur.length; i++) {
                StreakingBackground.Blur blur = streakingBackground.sblur[i];
                
                GL11.glTexCoord2f(0.0f, 0.0f);
                GL11.glVertex2f(blur.position.getX(), blur.position.getY());
                GL11.glTexCoord2f(1.0f, 0.0f);
                GL11.glVertex2f(blur.position.getX()+64, blur.position.getY());
                GL11.glTexCoord2f(1.0f, 1.0f);
                GL11.glVertex2f(blur.position.getX()+64, blur.position.getY()+8);
                GL11.glTexCoord2f(0.0f, 1.0f);
                GL11.glVertex2f(blur.position.getX(), blur.position.getY()+8);
            }
        }
        GL11.glEnd();
        
        blur1.render();
        GL11.glBegin(GL11.GL_QUADS);
        {
            for (int i = 0; i < streakingBackground.lblur.length; i++) {
                StreakingBackground.Blur blur = streakingBackground.lblur[i];
                
                GL11.glTexCoord2f(0.0f, 0.0f);
                GL11.glVertex2f(blur.position.getX(), blur.position.getY());
                GL11.glTexCoord2f(1.0f, 0.0f);
                GL11.glVertex2f(blur.position.getX()+256, blur.position.getY());
                GL11.glTexCoord2f(1.0f, 1.0f);
                GL11.glVertex2f(blur.position.getX()+256, blur.position.getY()+16);
                GL11.glTexCoord2f(0.0f, 1.0f);
                GL11.glVertex2f(blur.position.getX(), blur.position.getY()+16);
            }
        }
        GL11.glEnd();
        GL11.glDisable(GL11.GL_SCISSOR_TEST);
        GL11.glPopMatrix();
    }
    
    public void open() {
        super.open();
        mainmenu.open();
    }
    
    public void close() {
        super.close();
        mainmenu.close();
    }
    
    private void createGUI() throws Exception {
        setBounds(0, 0, VoidGame.WIDTH, VoidGame.HEIGHT).setClipped(false);        
        addChild(mainmenu);        
        centre();
    }
}

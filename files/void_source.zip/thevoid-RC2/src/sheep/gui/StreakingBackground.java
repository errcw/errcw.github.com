package sheep.gui;

import org.lwjgl.util.vector.Vector2f;

import sheep.VoidGame;

/**
 * @author Hemesh
 */
public class StreakingBackground {

    public class Blur {
        /** Current position of the Blur */
        public final Vector2f position = new Vector2f();
        /** Current position of the Blur */
        public final Vector2f velocity = new Vector2f();
        /** State of the Blur */
        protected boolean isAlive;

        /**
         * Initializes this Blur.
         */
        public void init(float defaultspeed) {
            position.setY((float) Math.random() * VoidGame.HEIGHT / 2);
            position.setX((float) Math.random() * VoidGame.WIDTH);
            velocity.setX(defaultspeed);
            isAlive = true;
        }

        /**
         * Creates a new blur when another blur is dying.
         */
        public void create(float defaultspeed, float offset, Blur dying) {
            position.setX((float) 0 - offset);
            position.setY((float) Math.random() * (VoidGame.HEIGHT / 2));
            velocity.setX(defaultspeed);
            isAlive = true;
        }

        /**
         * Kills this Blur.
         */
        public void kill() {
            isAlive = false;
        }

        /**
         * Updates the Blur with a new position.
         */
        public void update() {
            position.setX(position.getX() + velocity.getX());
        }

        public boolean isAlive() {
            return isAlive;
        }
    }

    /** Blur constants */
    public static final int LONGLEN = 256;
    private static final float LSPEED = 5;
    private static final int LSIZE = 35;
    
    public static final int SHORLEN = 64;
    private static final float SSPEED = 7;
    private static final int SSIZE = 150;

    private Blur temp = new Blur();

    /* The array of Blurs to be used for rendering */
    public Blur[] lblur = new Blur[LSIZE];
    public Blur[] sblur = new Blur[SSIZE];
    //public ArrayList lblur = new ArrayList(LSIZE);
    //public ArrayList sblur = new ArrayList(SSIZE);

    /**
     * initializes all the Blurs for display
     *  
     */
    public void init() {
        for (int i = 0; i < LSIZE; i++) {
            Blur temp = new Blur();
            temp.init(LSPEED);
            lblur[i] = temp;
            //lblur.add(temp);
        }
        for (int i = 0; i < SSIZE; i++) {
            Blur temp = new Blur();
            temp.init(SSPEED);
            sblur[i] = temp;
            //sblur.add(temp);
        }
    }

    /**
     * Updates the position of all the Blurs.
     */
    public void update() {
        for (int i = 0; i < lblur.length; i++) {
            temp = (Blur) lblur[i];
            temp.update();
            if (temp.position.getX() >= VoidGame.WIDTH) {
                temp.kill();
                temp.create(LSPEED, LONGLEN, temp);
            }
        }
        for (int i = 0; i < sblur.length; i++) {
            temp = (Blur) sblur[i];
            temp.update();
            if (temp.position.getX() >= VoidGame.WIDTH) {
                temp.kill();
                temp.create(SSPEED, SHORLEN, temp);
            }
        }
    }
}
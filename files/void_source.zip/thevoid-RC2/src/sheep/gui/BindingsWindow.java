package sheep.gui;

import java.util.HashMap;

import org.lwjgl.util.Color;

import sheep.Bindings;
import sheep.Log;
import sheep.Resources;
import sheep.VoidGame;

import net.puppygames.gui.*;

/**
 * @author Eric Woroshow
 * @author princec
 */
public class BindingsWindow extends Window {

    /**
     * A class to display and edit a single binding
     */
    class BindingEditor extends Panel implements CommandButtonListener {
        Bindings.Binding binding;
        Label nameLabel;
        CommandButton bindingButton;
        boolean captureMode;
        boolean waitMode;
        
        SwirlyBackground swirlyBackground = new SwirlyBackground(this, 64.0f, 64.0f, null);
        
        BindingEditor() throws Exception {            
            setBackgroundColor(Interface.getControlBackgroundColor());
            
            nameLabel = new Label();
            nameLabel.setAlignment(Label.RIGHT);
            bindingButton = new CommandButton();
            bindingButton.setUseEffect(false);
            
            nameLabel.setWidth(120).setY(7);
            bindingButton.setLocation(125, 5);
            bindingButton.setForegroundColor(Interface.getDefaultForeground());
            bindingButton.setWidth(200);            
            
            addChild(nameLabel);
            addChild(bindingButton);
            
            pack().setWidth(getWidth() + 17);
            
            bindingButton.addCommandButtonListener(this);
        }
        
        void setBinding(Bindings.Binding binding) {
            this.binding = binding;
            nameLabel.setText(binding.getName()).pack().setWidth(120);
            bindingButton.setText(binding.toString());
        }       
        
        protected boolean doTick() {
            boolean ret = super.doTick();
            
            if (captureMode) {
                ret = true;
                swirlyBackground.doTick();
                if (binding.determine()) {
                    bindingButton.setText(binding.toString());
                    setBindings(player);
                    captureMode = false;
                    waitMode = true;
                }
            } else if (waitMode) {
                ret = true;
                if (!binding.isDown()) {
                    Bindings.getPlayerBindings(0).setEnabled(false);
                    Interface.setIgnoreInput(false);
                    waitMode = false;
                }
            }
            
            return ret;
        }

        protected void renderBackground() {
            if (captureMode) {
                swirlyBackground.render();
            }
        }

        public boolean selected(CommandButton cb) {
            captureMode = true;
            Interface.setIgnoreInput(true);
            Bindings.getPlayerBindings(0).setEnabled(false);
            return false;
        }
    }
    
    /**
     * Event handling class
     */
    private class EventHandler implements OKCancelListener, GroupButtonListener {
        public boolean groupButtonChanged(GroupButton button, boolean selected) {
            if (selected) {
                String n = button.getName().substring(button.getName().indexOf(" ") + 1);
                int pl = Integer.parseInt(n) - 1;
                setBindings(pl);
            }
            return false;
        }
        
        public void cancelClicked() {
            // Load previous bindings           
            try {
                Bindings.load(Resources.getResourceAsStream("bindings.dat"));
            } catch (Exception e) {
                Log.log(e);
            }
            close();
        }

        public void okClicked() {
            // Save bindings
            try {
                Bindings.save(new java.io.FileOutputStream("bindings.dat"));
            } catch (Exception e) {
                Log.log(e);
            }
            close();
        }
    }
    
    /** Event handling instance */
    private final EventHandler eventHandler = new EventHandler();
    
    /** The player for which we are defining bindings */
    private int player;
    
    private OKCancelPanel okCancelPanel;
    private HashMap bindingsControls = new HashMap();
    private ScrollPane scrollPane;
    private Panel bindingsPanel;
    private ButtonGroup bindingsGroup;
    private RadioButton[] playerButtons;

    /**
     * Constructor
     */
    public BindingsWindow() throws Exception {
        super("Setup Controls");
        
        createGUI();
        initEvents();
        
        open();
    }
    
    /**
     * Create the GUI
     */
    private void createGUI() throws Exception {
        okCancelPanel = new OKCancelPanel();
        
        bindingsPanel = new Panel();
        bindingsPanel.setBackgroundColor(new Color(0, 128, 255, 64));
        
        scrollPane = new ScrollPane(ScrollPane.HORIZONTAL_SCROLLBAR_NEVER, ScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setSize(380, 110);
        scrollPane.setView(bindingsPanel);
        scrollPane.setLocation(0, 100);

        addChild(scrollPane);
        addChild(okCancelPanel);
        
        bindingsGroup = new ButtonGroup();
        playerButtons = new RadioButton[VoidGame.MAX_PLAYERS];
        for (int i = 0; i < VoidGame.MAX_PLAYERS; i++) {
            playerButtons[i] = new RadioButton("Player " + (i+1), bindingsGroup);
            playerButtons[i].setName("Player " + (i+1));
            //Creates two rows for the buttons: 1 2 / 3 4
            playerButtons[i].setBounds(40 + 160 * (i - ((i > 1) ? 2 : 0)), (i > 1) ? 40 : 80, 90, 22);
            addChild(playerButtons[i]);
        }
        playerButtons[0].setChecked(true);
        
        setBindings(0);
        bindingsPanel.pack();
        scrollPane.setWidth(bindingsPanel.getWidth());
        scrollPane.setViewLocation(0, bindingsPanel.getHeight() - scrollPane.getHeight());
        
        pack();
        setBorder(5, 5, 5, 5);
        centre();
    }
    
    /** 
     * Wire up events
     */
    private void initEvents() {
        okCancelPanel.addOkCancelListener(eventHandler);
        for (int i = 0; i < VoidGame.MAX_PLAYERS; i++)
            playerButtons[i].addGroupButtonListener(eventHandler);
    }
    
    private void setBindings(int player) {
        this.player = player;
        try {
            Bindings.Binding[] b = Bindings.getPlayerBindings(player).getBindingsArray();
            for (int i = 0; i < b.length; i++)
                setBinding(b[i]);
        } catch (Exception e) {
            Log.log(e);
        }
    }
    
    public void setBinding(Bindings.Binding binding) throws Exception {
        BindingEditor editor = (BindingEditor) bindingsControls.get(binding.getName());
        if (editor == null) {
            editor = new BindingEditor();
            bindingsPanel.addChild(editor);
            editor.setY(bindingsControls.size() * editor.getHeight() + 5);
            bindingsControls.put(binding.getName(), editor);
        }
        editor.setBinding(binding);
    }
}

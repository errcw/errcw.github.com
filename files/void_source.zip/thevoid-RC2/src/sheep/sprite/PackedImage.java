package sheep.sprite;

import java.util.ArrayList;

import org.w3c.dom.Element;

import sheep.Resource;
import sheep.Resources;
import sheep.util.XMLUtils;

/**
 * @author Eric Woroshow
 */
public class PackedImage extends Resource {

    /** Actual image file containing the packed SpriteImages */
    private String imageFile;
    
    /**
     * Resource constructor.
     * @param name unique name of this Resource
     */
    public PackedImage(String name) {
        super(name);
    }

    protected void doCreate() throws Exception {
        //grab the image and make it into an OpenGL texture
        //load all of the spriteimage tags
        //put all spriteimages into resources
    }
    
    protected void doDestroy() {}

    protected void load(Element e) {
        imageFile = XMLUtils.getString(e, "file");
        
        ArrayList nodes = XMLUtils.getChildren(e, "spriteimage");
        for (int i = 0; i < nodes.size(); i++) {
            Element elem = (Element)nodes.get(i);
            
            SpriteImage sprite = new SpriteImage(XMLUtils.getString(elem, "name"));
            sprite.load(elem);
            Resources.add(sprite);
        }
    }
}
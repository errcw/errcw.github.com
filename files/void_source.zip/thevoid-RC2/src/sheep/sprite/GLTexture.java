package sheep.sprite;

import org.w3c.dom.Element;

import sheep.Resource;

/**
 * @author Eric Woroshow
 */
public class GLTexture extends Resource {
    
    private String imagefile;    
    private int texID;
    
    /**
     * Resource constructor.
     * @param name unique name of this Resource
     */
    public GLTexture(String name) {
        super(name);
    }

    protected void doCreate() throws Exception {}
    
    protected void doDestroy() {}

    protected void load(Element e) {}
}
package sheep.sprite;

import org.w3c.dom.Element;

import sheep.Resource;
import sheep.util.XMLUtils;

/**
 * @author Eric Woroshow
 */
public class SpriteImage extends Resource {
    
    /** Image information */
    private int x, y, width, height;

    /**
     * Resource constructor.
     * @param name unique name of this Resource
     */
    public SpriteImage(String name) {
        super(name);
    }

    protected void doCreate() throws Exception {
    }
    
    protected void doDestroy() {}

    protected void load(Element e) {
        x = XMLUtils.getInt(e, "x");
        y = XMLUtils.getInt(e, "y");
        width = XMLUtils.getInt(e, "w");
        height = XMLUtils.getInt(e, "h");
    }
    
    /**
     * @return the width of this SpriteImage, in pixels
     */
    public int getWidth(){
        return width;
    }
    
    /**
     * @return the height of this SpriteImage, in pixels
     */
    public int getHeight(){
        return height;
    }
}
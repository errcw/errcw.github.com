package sheep;

import org.w3c.dom.Element;

/**
 * An abstract game resource.
 * 
 * @author Eric Woroshow
 */
public abstract class Resource {

    /** Unique name of the resource */
    protected String name;

    private boolean created;

    /**
     * Default public constructor.
     */
    public Resource() {}
    
    /**
     * Constructs a named resource.
     * @param name a unique name for this resource
     */
    public Resource(String name){
        this.name = name;
    }

    /**
     * Creates this resource.
     * @throws Exception if the resource could not be created
     */
    public final void create() throws Exception {
        if (!created) {
            doCreate();
            created = true;
        }
    }

    /**
     * Destroys this resource.
     */
    public final void destroy() {
        if (created) {
            doDestroy();
            created = false;
        }
    }

    /**
     * Performs the actual creation of this resource.
     * @throws Exception if the resource could not be created
     */
    protected void doCreate() throws Exception {}
    
    /**
     * Performs the actual destruction of this resource.
     */
    protected void doDestroy() {}
    
    /**
     * Loads this resource from an XML element.
     * @param element the element describing this resource
     */
    protected void load(Element element) {}

    /**
     * @return if this resource has been created
     */
    public final boolean isCreated() {
        return created;
    }

    /**
     * @return this resource's name
     */
    public final String getName() {
        return name;
    }

    /**
     * @return this resource's name
     * @see java.lang.Object#toString()
     */
    public String toString() {
        return name;
    }

    /**
     * @see java.lang.Object#hashCode()
     */
    public int hashCode() {
        return name.hashCode();
    }
}
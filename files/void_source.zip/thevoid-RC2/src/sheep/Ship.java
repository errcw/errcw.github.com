package sheep;

import org.lwjgl.util.vector.Vector2f;

import sheep.attributes.ShipAttributes;
import sheep.sound.ALSoundData;
import sheep.sound.ALSoundSystem;

import com.shavenpuppy.jglib.Resources;
import com.shavenpuppy.jglib.sprites.Sprite;
import com.shavenpuppy.jglib.sprites.SpriteImage;
import com.shavenpuppy.jglib.util.FPMath;


/**
 * Represents a Ship.
 * @author Eric Woroshow
 */
public class Ship extends LivingEntity {
    /** Map of Ship IDs to colours */
    private final static String[] SHIP_TYPES = { "red", "blue", "green", "yellow" };
    /** Ship sounds */
    private static ALSoundData death, collisionMass, collisionShip;
    
    static {
        try {
            death = (ALSoundData)sheep.Resources.get("shipdeath.sound");
            collisionShip = (ALSoundData)sheep.Resources.get("shipcollide.sound");
            collisionMass = (ALSoundData)sheep.Resources.get("masscollide.sound");
        } catch (Exception e) {
            Log.log(e);
        }
    }
    
    private Sprite sprite;
    private SpriteImage shipImage;
    /** Oreintation angle in standard basis, radians */
    private float orientation;
    /** Attributes of this Ship */
    private ShipAttributes attrs;
    /** Input bindings for this Ship */
    private Bindings bindings;
    
    /*
     * To accurately perform collision detections we need the initial velocities
     * of both Entities. However, if we preserve the inital velocity, we also need 
     * to temporarily store the resultant velocity vector for later update.
     */
    private Vector2f nvelocity = new Vector2f();
    private boolean updateVelocity = false;
    
    //Manage mass ejection
    private boolean massCharging;
    private float massCharge;
    private int massWaitTick;
    
    public Ship(ShipAttributes attrs, int id) {
        this.attrs = attrs;
        bindings = Bindings.getPlayerBindings(id);
        try {
            shipImage = (SpriteImage)Resources.get(attrs.getSpriteBase() + SHIP_TYPES[id]);
        } catch (Exception e) { Log.log(e); }
        radius = attrs.getRadius();
        orientation = 0;
    }

    /**
     * We have nothing to create, so ignore this state. 
     */
    public void doCreationUpdate() {
        create();
    }
    
    public void onCreation() {
        //allocate the sprites we need to display the ships
        sprite = BattleField.allocateSprite(this);
        sprite.setImage(shipImage);
        sprite.setLocation((int)position.getX(), (int)position.getY(), 0);
        sprite.setAngle(FPMath.fpYaklyDegrees(orientation));
        sprite.setLayer(1);
        
        velocity.set(0, 0);
    }

    /**
     * @see sheep.LivingEntity#doAliveUpdate()
     */
    public void doAliveUpdate() {
        //Parse player input
        if (bindings.isThrustLeftDown())
            orientation -= attrs.getRotationalVel();
        else if (bindings.isThrustRightDown())
            orientation += attrs.getRotationalVel();
        clamp(orientation);
        
        //Manage mass ejection
        if (bindings.isLaunchMassDown()) {
            if (massCharging && massCharge < attrs.getMaxMassVel())
                massCharge += 0.5;
            else if (!massCharging && massWaitTick > attrs.getMassLaunchDelay())
                massCharging = true;
        } else {
            massWaitTick++;
            if (massCharging) { //Player has released the key, launch mass
                ejectMass(massCharge);
                massCharging = false;
                massCharge = 0;
                massWaitTick = 0;
            }
        }
        
        //Update velocity from collisions
        if (updateVelocity) {
            velocity.set(nvelocity);
            updateVelocity = false;
        }
        
        //Gravitate towards the star
        velocity.set(physicsEngine.gravitationForce(velocity, position));
        
        //Update ship rotation image accordingly
        sprite.setAngle(FPMath.fpYaklyDegrees(orientation));
        
        //Update our position
        position.translate(velocity.getX(), velocity.getY());
        sprite.setLocation((int)position.getX(), (int)position.getY(), 0);
        
        //Bounce off the edges
        if (   position.getX() < 0 || position.getX() > VoidGame.WIDTH
            || position.getY() < 0 || position.getY() > VoidGame.HEIGHT)
            velocity.negate();
    }

    /**
     * @see sheep.LivingEntity#doDyingUpdate()
     */
    public void doDyingUpdate() {
        //do nothing
    }
    
    public void onDeath(){
        ALSoundSystem.play(death);
        sprite.setAnimation(attrs.getDeathAnimation());
    }
    
    protected void onRemoval() {
        sprite.deallocate();
    }

    /**
     * @see sheep.Entity#render()
     */
    public void render() {
        //Do what we need to do in order to get put on the screen somewhere
    }

    /**
     * @see sheep.Entity#inCollisionWith(sheep.Entity)
     */
    public void inCollisionWith(Entity entity) {
        entity.inCollisionWithShip(this);
    }

    /**
     * @see sheep.Entity#inCollisionWithShip(Ship)
     */
    public void inCollisionWithShip(Ship s) {
        ALSoundSystem.play(collisionShip);
        
        nvelocity.set(physicsEngine.sameMassCollision(velocity, s.getVelocity()));
        updateVelocity = true;
    }

    /**
     * Destroys the mass in the collision.
     * @see sheep.Entity#inCollisonWithMass(Mass)
     */
    public void inCollisonWithMass(Mass m) {
        ALSoundSystem.play(collisionMass);
        m.remove();
        nvelocity.set(physicsEngine.diffMassCollision(this, m));
        updateVelocity = true;
    }
    
    private void ejectMass(float speed) {
        Log.log("Launching mass with speed of " + speed);
        
        velocity.set(physicsEngine.shipEjectionVelocity(orientation, speed, velocity));
        
        Vector2f v = new Vector2f(position);
        Mass m = new Mass(rotatedVector(orientation, 25), 
                          physicsEngine.massEjectionVelocity(orientation, speed));
        m.spawn();
    }
    
    /**
     * @return the orientation value clamped between 0 and 2pi
     */
    private float clamp(float orientation) {
        if (orientation < 0f)
           return 0f;
        if (orientation > 2 * Math.PI)
            return 0f;
        
        return orientation;
    }
    
    private Vector2f rotatedVector(float angle, float magnitude) {
        Vector2f v = new Vector2f();
        v.setX((float)Math.cos(angle) * magnitude * -1);
        v.setY((float)Math.sin(angle) * magnitude * -1);
        v.translate(position.getX(), position.getY());
        return v;
    }
    
    public String toString() {
        return "Ship " + shipImage.getName();
    }
}

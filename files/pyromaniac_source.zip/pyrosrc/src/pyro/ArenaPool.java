/*
 * Created on May 11, 2003 at 7:37:49 PM
 * Project: Pyromaniac
 */
package pyro;

import java.util.ArrayList;
import java.io.*;

/**
 * @author MASTER
 * Class: ArenaPool
 */
public class ArenaPool {
	/** The location of all the arena files. */
	private final static String DIR = "pyro/res/levels/level";
	/** The pool of arenas. */
	private static Object[] pool;

	/**
	 * Reads all the available level files and writes them to a central pool.
	 */
	public static void init() {
		ArrayList levels = new ArrayList();
		int level = 0;
		File lvlFile = new File(DIR + level + ".txt");

		while (lvlFile.exists()) {
			try {
				int[][] data = loadLevel(lvlFile);
				levels.add(data);
			} catch (Exception e) {
				/*Don't add the level - the data or file is invalid. */
				System.err.println(" -- Level file " + level + " is invalid.");
			} finally {
				lvlFile = new File(DIR + (++level) + ".txt");
			}
		}

		pool = levels.toArray();
	}

	/**
	 * Loads a level from a text file.
	 * @param f the file to load
	 * @return the level data
	 * @throws Exception if an error occurs reading the level
	 */
	private static int[][] loadLevel(File f) throws Exception {
		BufferedReader in = new BufferedReader(new FileReader(f));
		String line;
		int[][] level = new int[11][13];

		for (int i = 0; i < level.length; i++) {
			line = in.readLine();
			for (int j = 0; j < level[i].length; j++) {
				level[i][j] = symbolToInt(line.charAt(j));
			}
		}

		return level;
	}

	/** Translates a character symbol to its corresponding integer
	 * representation. If the symbol is unknown, a value of 99 is returned.
	 * Refer to 'key.txt' inside the levels folder for details on the symbol
	 * system.
	 * @param c the character to translate
	 * @return the integer value.
	 */
	private static int symbolToInt(char c) {
		if (c == '=')
			return -3;
		if (c == '*')
			return -2;
		if (c == '-')
			return -1;
		if (c == ' ')
			return 0;
		if (c == '1')
			return 2;
		if (c == '2')
			return 3;
		if (c == '3')
			return 4;
		if (c == '4')
			return 5;
		return 99;
	}

	/**
	 * @return the number of arenas available to play 
	 */
	public static int getNumArenas() {
		return pool.length;
	}

	/**
	 * @param id the desired arena
	 * @return the 2d array representing the arena
	 * @throws ArrayIndexOutOfBoundsException if the arena ID is invalid
	 */
	public static int[][] getArena(int id) throws ArrayIndexOutOfBoundsException {
		if (id < 0 || id > pool.length)
			throw new ArrayIndexOutOfBoundsException("Invalid arena id.");

		int[][] level = (int[][])pool[id];
		int[][] temp = new int[11][13];
		for (int i = 0; i < temp.length; i++)
			System.arraycopy(level[i], 0, temp[i], 0, 13);

		return temp;
	}
}

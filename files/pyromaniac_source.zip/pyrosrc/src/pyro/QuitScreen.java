/*
 * QuitScreen.java
 *
 * Created on April 27, 2003, 6:02 PM
 */

package pyro;

import pyro.gui.*;
import pyro.res.Locator;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

/** Quit screen displayed when the user presses "Escape".
 * @author  MASTER
 */
public class QuitScreen extends Screen {
	/** The screen's backgrond. */
	private BufferedImage back;
	/** The screen's title */
	private BufferedImage title;
	/** The menu displayed on the screen */
	private CyclableMenu menu;
	/** If quit is selected */
	private boolean quit;
	/** If resume is selected*/
	private boolean resume;

	/** Creates a new instance of QuitScreen */
	public QuitScreen() throws Exception {
		back = Tools.loadImage(Locator.class.getResource("menu/back.jpg"));

		SpriteFont font = FontPool.getFont("white");
		title = font.createText("QUIT TO DESKTOP?");

		SingleMenuItem[] items =
			{
				new SingleMenuItem(font.createText("YES")),
				new SingleMenuItem(font.createText("NO"))};

		menu = new CyclableMenu(items, 30);
	}

	/** Initializes the Screen. Called every time the Screen is loaded into the
	 * ScreenDisplay.  As this method is called with relative frequency, image
	 * loading code should NOT appear in initialization, rather in the constructor.
	 */
	public void initialize() {
		quit = false;
		resume = false;
	}

	/**
	 * @return if the user has chosen to quit the program
	 */
	public boolean shouldQuit() {
		return quit;
	}
	
	/**
	 * @return if the user has chosen to resume the game
	 */
	public boolean shouldResume(){
		return resume;
	}

	/** Updates the Screen for the current frame.  */
	public void step() {
		menu.step(ScreenDisplay.getKeyState());
		if (menu.enterPressed())
			if (menu.getSelectedIndex() == 0)
				quit = true;
			else
				resume = true;
	}

	/** Draws the screen to a graphical context.
	 * @param g the graphical context on which to draw
	 */
	public void draw(Graphics g) {
		g.drawImage(back, 85, 150, null);
		g.drawImage(title, 95, 160, null);
		menu.draw(g, 150, 200);
	}
}

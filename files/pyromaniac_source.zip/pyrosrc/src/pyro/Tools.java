/*
 * Tools.java
 *
 * Created on March 28, 2003, 5:55 PM
 */

package pyro;

import pyro.res.Locator;

import java.awt.*;
import java.awt.image.BufferedImage;

import java.io.*;

import java.net.URL;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.IntBuffer;

import javax.imageio.ImageIO;

/** Utility class containing useful static methods.
 */
public class Tools {
	public final static int TILE_SIZE = 32;
	private final static GraphicsConfiguration gc;

	/** Statically initialize Tools, and retrieve the GraphicsConfiguration
	 */
	static {
		GraphicsEnvironment env = GraphicsEnvironment.getLocalGraphicsEnvironment();
		GraphicsDevice device = env.getDefaultScreenDevice();
		gc = device.getDefaultConfiguration();
	}

	/** Loads an image from the specified URL.  The image loaded is copied into 
	 * an accelerated BufferedImage. As Class.getResource() should be used to
	 * retrieve the location of the image, the method accepts only URLs.
	 * @param file the file to load
	 * @throws IOException loading the image was unsuccessful
	 */
	public static BufferedImage loadImage(URL file) throws IOException {
		BufferedImage src = ImageIO.read(file);
		BufferedImage dst =
			gc.createCompatibleImage(
				src.getWidth(),
				src.getHeight(),
				Transparency.BITMASK);
		Graphics2D g = dst.createGraphics();
		g.setComposite(AlphaComposite.Src);
		g.drawImage(src, 0, 0, null);
		g.dispose();
		return dst;
	}

	/** Creates a hardware accelerable image.
	 * @param width the width of the returned BufferedImage
	 * @param height the height of the returned BufferedImage
	 */
	public static BufferedImage createImage(int width, int height) {
		return gc.createCompatibleImage(width, height, Transparency.BITMASK);
	}

	/** Creates a preview of a given level.
	 * @param data the grid describing the level layout
	 * @return a 60% size version of the level
	 */
	public static BufferedImage createArenaPreview(int[][] data) {
		BufferedImage fullsize, preview;
		Graphics fg, pg;

		//Load the tile and player images
		BufferedImage[] heads = new BufferedImage[4];
		for (int i = 0; i < heads.length; i++)
			heads[i] = ImagePool.getImage("heads/bomber" + i + ".png");
		BufferedImage empty = ImagePool.getImage("tiles/empty.jpg");
		BufferedImage fblock = ImagePool.getImage("tiles/firmblock.jpg");
		BufferedImage block = ImagePool.getImage("tiles/block.jpg");
		BufferedImage edge = ImagePool.getImage("tiles/edge.jpg");

		//Determine the size of the level
		int width = 13 * TILE_SIZE;
		int height = 11 * TILE_SIZE;

		//Create a full-sized image of the level
		fullsize = Tools.createImage(width, height);
		//And a verison 60% of the original size
		preview = Tools.createImage(Math.round(width * .65f), Math.round(height * .65f));

		pg = preview.getGraphics();
		fg = fullsize.getGraphics();

		//For each element in the grid, draw the appropriate tile.
		//Note that the format for data is: data[row][column], so the x and
		//y must be reversed.
		int player = 0;
		for (int i = 0; i < data.length; i++)
			for (int j = 0; j < data[i].length; j++) {
				player = 0;
				switch (data[i][j]) {
					case -3 :
						fg.drawImage(edge, j * TILE_SIZE, i * TILE_SIZE, null);
						break;
					case -2 :
						fg.drawImage(fblock, j * TILE_SIZE, i * TILE_SIZE, null);
						break;
					case -1 :
						fg.drawImage(block, j * TILE_SIZE, i * TILE_SIZE, null);
						break;
					case 0 :
						fg.drawImage(empty, j * TILE_SIZE, i * TILE_SIZE, null);
						break;
					case 2 :
						player++;
					case 3 :
						player++;
					case 4 :
						player++;
					case 5 :
						player++;
						fg.drawImage(empty, j * TILE_SIZE, i * TILE_SIZE, null);
						fg.drawImage(
							heads[4 - player],
							j * TILE_SIZE,
							i * TILE_SIZE,
							null);
						break;
					default :
						break;
				}
			}

		//Scale the full level down to preview size
		pg.drawImage(fullsize, 0, 0, preview.getWidth(), preview.getHeight(), null);

		fg.dispose();
		pg.dispose();

		return preview;
	}

	/**
	 * Creates an integer buffer to hold specified ints
	 * - strictly a utility method
	 *
	 * @param size how many int to contain
	 * @return created IntBuffer
	 */
	public static IntBuffer createIntBuffer(int size) {
		ByteBuffer temp = ByteBuffer.allocateDirect(4 * size);
		temp.order(ByteOrder.nativeOrder());

		return temp.asIntBuffer();
	}

	/**
	 * Loads a Truetype font from a URL.
	 * @return the TT font in the given size
	 */
	public static Font loadTruetypeFont(URL location, int size) {
		try {
			InputStream fin = location.openStream();
			Font temp = Font.createFont(Font.TRUETYPE_FONT, fin);
			return temp.deriveFont(Font.PLAIN, size);
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * Creates a status display for the current round, showing the number
	 * of wins for each player, and the number of tie games. The information
	 * is retrieved from pyro.Config
	 * @return the status display image
	 */
	public static BufferedImage createStatusDisplay() {
		final int SPACE = 60;
		//Create the image
		BufferedImage status = createImage(300, 50);
		Graphics g = status.getGraphics();

		//Load the font
		Font font = loadTruetypeFont(Locator.class.getResource("fonts/credits.ttf"), 20);

		//Load the images
		BufferedImage[] heads = new BufferedImage[4];
		for (int i = 0; i < heads.length; i++)
			heads[i] = ImagePool.getImage("heads/bomber" + i + ".png");
		BufferedImage flag = ImagePool.getImage("heads/flag.jpg");

		//Retreive the current game state
		Config.PlayerInfo[] info = Config.get().players;

		//Draw the status display
		g.setColor(new Color(192, 192, 192));
		g.fillRect(0, 0, 300, 100);
		
		g.setFont(font);
		g.setColor(Color.WHITE);
		for (int i = 0; i < info.length; i++) {
			String wins = Integer.toString(info[i].wins);
			g.drawImage(heads[i], (i * SPACE), 0, null);
			g.drawString(wins, (i * SPACE) + 32, 20);
		}

		String ties = Integer.toString(Config.get().ties);
		g.drawImage(flag, (info.length * SPACE), 0, null);
		g.drawString(ties, (info.length * SPACE) + 20, 20);

		return status;
	}

	public static String ticksToTime(int ticks) {
		int seconds = (int) (ticks / 60);
		return secondsToTime(seconds);
	}

	public static String secondsToTime(int seconds) {
		String min = Integer.toString(seconds / 60);
		String sec = Integer.toString(- (((seconds / 60) * 60) - seconds));

		return min + ":" + ((sec.length() == 1) ? "0" : "") + sec;
	}
}

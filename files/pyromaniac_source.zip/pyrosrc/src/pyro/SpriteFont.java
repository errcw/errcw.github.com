/*
 * SpriteFont.java
 *
 * Created on April 18, 2003, 5:17 PM
 */

package pyro;


import java.awt.*;
import java.awt.image.*;

import java.net.URL;
import java.io.IOException;
import java.util.Properties;

/** Class representing a font based on an image.  The font is immutable once
 * it has been created.
 */
public class SpriteFont {
    private final BufferedImage[] images;
    private final String chars;
    private final int width, height;
    
    /** Creates a new instance of SpriteFont from a font descriptor. The file
     * describes the image, the size of the characters, and the characters available.
     * @param url location of the font descriptor
     */
    public SpriteFont(URL url) throws IOException {
        Properties p = new Properties();
        p.load( url.openStream() );
        
        String sURL = url.toExternalForm();
        String directory = sURL.substring(0, sURL.lastIndexOf("/") + 1 );
        URL file = new URL( directory + p.getProperty("file") );
        
        width = Integer.parseInt( p.getProperty("width") );
        height = Integer.parseInt( p.getProperty("height") );
        chars = p.getProperty("chars");
        images = new BufferedImage[chars.length()];
        
        int rows = Integer.parseInt( p.getProperty("nrows") );
        int cols = Integer.parseInt( p.getProperty("ncols") );
        
        Graphics g;
        BufferedImage data = Tools.loadImage(file);
        for (int i = 0; i < images.length; i++){
            images[i] = Tools.createImage(width, height);
            g = images[i].getGraphics();
            
            int row = i / cols;
            int col = i % cols;
            g.drawImage( data.getSubimage(col * width, row * height, width - 1, height - 1), 0, 0, null);
        }
    }
    
    /** Creates an image containing the specified string.
     * @param str the string to display
     */
    public BufferedImage createText(String str){
        if (str == null || str.length() == 0)
            return null;
        
        BufferedImage text = Tools.createImage(width * str.length(), height);
        Graphics g = text.getGraphics();
        for (int i = 0; i < str.length(); i++) {
            int c = getCharPosition( str.charAt(i) );
            if ( c != -1 )
                g.drawImage( images[c], width * i, 0, null );
        }
        
        return text;
    }
    
    private int getCharPosition(char c){
        return chars.indexOf(c);
    }
}

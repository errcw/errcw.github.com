/*
 * DisplayFullscreen.java
 *
 * Created on January 24, 2003, 4:21 PM
 */

package pyro.display;

import java.awt.*;
import java.awt.image.BufferStrategy;
import java.awt.event.KeyListener;

public class DisplayFullscreen implements DisplayProvider {
    Frame screen;
    BufferStrategy buffer;
    GraphicsDevice device;
    Graphics gfx;
    
    public DisplayFullscreen() { }
    
    public void addKeyListener(KeyListener listener) {
        screen.addKeyListener(listener);
    }
    
    public void close() {
        device.setFullScreenWindow(null);
        screen.dispose();
        System.exit(0);
    }
    
    public void draw(Image img) {
        gfx = buffer.getDrawGraphics();
        gfx.fillRect(0, 0, 5000, 5000);
        gfx.drawImage(img, 0, 0, null);
        buffer.show();
        gfx.dispose();
    }
    
    public Graphics getGraphics() {
        return buffer.getDrawGraphics();
    }
    
    public void showGraphics() {
        buffer.show();
    }
    
    public void initializeDisplay(Dimension resolution, String title) {
        GraphicsEnvironment env = GraphicsEnvironment.getLocalGraphicsEnvironment();
        device = env.getDefaultScreenDevice();
        GraphicsConfiguration gc = device.getDefaultConfiguration();
        
        screen = new Frame(gc);
        
        screen.setUndecorated(true);
        screen.setIgnoreRepaint(true);
        device.setFullScreenWindow(screen);
        
        //If the device supports it, change to the desired resolution
        if (device.isDisplayChangeSupported()) {
            DisplayMode best = new DisplayMode(resolution.width, resolution.height, 16, 0);
            if (supportsDisplayMode(device, best))
                device.setDisplayMode(best);
        }
        
        //Inititalize double buffering
        screen.createBufferStrategy(2);
        buffer = screen.getBufferStrategy();
    }
    
    private boolean supportsDisplayMode(GraphicsDevice device, DisplayMode mode){
        DisplayMode[] modes = device.getDisplayModes();
        for (int j = 0; j < modes.length; j++) {
            if (modes[j].getWidth() == mode.getWidth()
            && modes[j].getHeight() == mode.getHeight()
            && modes[j].getBitDepth() == mode.getBitDepth()
            )
                return true;
        }
        return false;
    }

    
}

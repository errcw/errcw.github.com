/*
 * DisplayProvider.java
 *
 * Created on January 22, 2003, 5:20 PM
 */

package pyro.display;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.KeyListener;

/** An abstraction of a display device.  Provides a method for the game to use
 * various devices without having to set them up or have any knowledge of how they
 * work.
 */
public interface DisplayProvider {
    /** Performs all of the initialization code, and activates the display mode.
     * Initialization must be called before any other methods are called!
     * @param resolution the desried resolution of the display
     * @param title the title given to the display, if applicable
     */    
    public void initializeDisplay(Dimension resolution, String title);
    
    /** Closes the display, and exits the program. */    
    public void close();
    
    /** Get a graphical context from the display provider.
     */
    public Graphics getGraphics();
    
    /** Display the graphics
     */
    public void showGraphics();
    
    /** Registers a key listener with the display.
     * @param listener the key listener to add
     */    
    public void addKeyListener(KeyListener listener);
}

/*
 * DisplayWindowed.java
 *
 * Created on January 22, 2003, 7:30 PM
 */

package pyro.display;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferStrategy;

public class DisplayWindow implements DisplayProvider {
    Frame window;
    
    Insets insets;
    BufferStrategy buffer;
    Graphics gfx;
    
    public DisplayWindow() { }
    
    public void addKeyListener(KeyListener listener) {
        window.addKeyListener(listener);
    }
    
    public void close() {
        window.setVisible(true);
        window.dispose();
    }
    
    public Graphics getGraphics() {
        return buffer.getDrawGraphics();
    }   
    
    public void showGraphics() {
        buffer.show();
    }
    
    public void initializeDisplay(Dimension resolution, String title) {
        GraphicsEnvironment env = GraphicsEnvironment.getLocalGraphicsEnvironment();
        GraphicsDevice device = env.getDefaultScreenDevice();
        GraphicsConfiguration gc = device.getDefaultConfiguration();
        
        window = new Frame(title, gc);
        
        window.setLayout(new BorderLayout());
        window.setIgnoreRepaint(true);
        window.setUndecorated(true);
        //Close the window when the "X" button is pressed
        window.addWindowListener(new WindowAdapter(){
            public void windowClosing(WindowEvent evt){ System.exit(0); }
        });
        window.pack();
        window.setVisible(true);
        
        window.setSize(resolution);
        window.setResizable(false);        
       
        //center the window on the screen
        window.setLocationRelativeTo(null);
        
        //get the size of the border so images are not clipped by it
        insets = window.getInsets(); 
        
        //create the double buffering system
        window.createBufferStrategy(2);
        buffer = window.getBufferStrategy();
        
        //bring the window to the front, and get keyboard focus
        window.requestFocus();
    }    
    
}

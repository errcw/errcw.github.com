/*
 * Created on Apr 30, 2003 at 5:37:52 PM
 * Project: Pyromaniac
 */
package pyro;

import pyro.sound.*;
import pyro.gui.*;

import java.awt.*;
import java.awt.image.BufferedImage;

/**
 * @author MASTER
 * Class: TitleScreen
 */
public class TitleScreen extends Screen {
	/** The menu items on the title screen */
	private static final String[] CHOICES = { "BATTLE", "OPTIONS", "CREDITS", "QUIT" };
	/** The start position for the white bomber's jump */
	private static final int JUMP_START = 180;
	/** Images for the title screen */
	private BufferedImage title, blackBomber, jumpBomber;
	/** The position and direction of the jumping bomber */
	private int jumpPos, jumpDir;
	/** ID of the background music */
	private int music;
	private ALSound sfxMusic;

	/** The main menu */
	private CyclableMenu menu;

	public TitleScreen() throws Exception {
		title = ImagePool.getImage("title/title.jpg");
		blackBomber = ImagePool.getImage("title/cloaked.jpg");
		jumpBomber = ImagePool.getImage("title/jump.jpg");

		//music = SoundPool.getSound(SoundPool.TITLE_MUSIC);
		sfxMusic = ALSoundPool.getSound("music/menu.ogg");

		SpriteFont f = FontPool.getFont("black");
		SingleMenuItem[] items = new SingleMenuItem[CHOICES.length];
		for (int i = 0; i < items.length; i++)
			items[i] = new SingleMenuItem(f.createText(CHOICES[i]));
		menu = new CyclableMenu(items, 32);
	}

	/* @see pyro.Screen#initialize()
	 */
	public void initialize() {
		//IMAGE CONVERSION HACK!
		/*try {
			BufferedImage[] img = new BufferedImage[7];
			BufferedImage[] lg = new BufferedImage[img.length];
			for (int i = 0; i < img.length; i++) {
				img[i] = ImagePool.getImage("toconv/pokal" + (i + 1) + ".gif");
				lg[i] = Tools.createImage(48, 48);
		
				Graphics g = lg[i].getGraphics();
				g.drawImage(img[i], 0, 0, 48, 48, null);
		
				java.io.File f = new java.io.File("pyro/res/heads/cup" + i + ".png");
				javax.imageio.ImageIO.write(lg[i], "png", f);
			}
		} catch (java.io.IOException e) {
			e.printStackTrace();
			System.exit(0);
		}*/
		///////////////////////
		
		//Reset the number of ties
		Config.get().ties = 0;
		
		jumpPos = JUMP_START;
		jumpDir = -1;

		//MusicSystem.reset();
		//MusicSystem.play(music);s
		if (!ALSoundManager.isPlaying(sfxMusic)) {
			ALSoundManager.stopAll();
			ALSoundManager.play(sfxMusic);
		}
	}

	/** Determines the screen to display based on the selected menu item.
	 * @param menuID the selected menu item
	 */
	private void switchScreen(int menuID) {
		switch (menuID) {
			case 0 :
				ScreenDisplay.setScreen(ScreenPool.getScreen("PlayerSelect"));
				break;
			case 1 :
				ScreenDisplay.setScreen(ScreenPool.getScreen("KeyConfig"));
				break;
			case 2 :
				ScreenDisplay.setScreen(ScreenPool.getScreen("Credits"));
				break;
			case 3 :
				ScreenDisplay.stop();
				break;
			default :
				break;
		}
	}

	/* @see pyro.Screen#step()
	 */
	public void step() {
		boolean[] keys = ScreenDisplay.getKeyState();
		menu.step(keys);

		if (menu.enterPressed())
			switchScreen(menu.getSelectedIndex());

		jumpPos += jumpDir;

		if (jumpPos > JUMP_START || jumpPos < 120)
			jumpDir *= -1; //go in the opposite direction

	}

	/* @see pyro.Screen#draw(java.awt.Graphics)
	 */
	public void draw(Graphics g) {
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, 450, 450);

		menu.draw(g, 75, 100);

		g.drawImage(title, 47, 20, null);
		g.drawImage(blackBomber, 0, 281, null);
		g.drawImage(jumpBomber, 280, jumpPos, null);
	}
}

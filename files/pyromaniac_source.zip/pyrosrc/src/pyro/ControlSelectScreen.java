/*
 * Created on May 7, 2003 at 7:35:21 PM
 * Project: Pyromaniac
 */
package pyro;

import pyro.gui.*;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

/**
 * @author MASTER
 * Class: ControlSelectScreen
 */
public class ControlSelectScreen extends AbstractMenuScreen {
	private BufferedImage title;
	private CyclableMenu menu;

	public ControlSelectScreen() throws Exception {
		super();
	}

	private void buildGUI() {
		SpriteFont wFont = FontPool.getFont("white");
		title = wFont.createText("INPUT");

		BufferedImage label = wFont.createText(" ");
		BufferedImage[] heads = new BufferedImage[4];
		for (int i = 0; i < heads.length; i++)
			heads[i] = ImagePool.getImage("heads/bomber" + i + ".png");

		BufferedImage[] devices = new BufferedImage[4];
		for (int i = 0; i < devices.length; i++)
			devices[i] = wFont.createText("KEYBOARD " + (i + 1));

		Config.PlayerInfo[] players = Config.get().players;
		IconCyclableMenuItem[] items = new IconCyclableMenuItem[players.length];
		for (int i = 0; i < players.length; i++)
			items[i] =
				new IconCyclableMenuItem(heads[players[i].color], label, devices, 0);

		menu = new CyclableMenu(items, 50);
		menu.setDuplicateChecking(true);
	}

	public void initialize() {
		super.initialize();

		buildGUI();
	}

	public void step() {
		super.step();
		boolean[] keys = ScreenDisplay.getKeyState();

		menu.step(keys);

		if (menu.enterPressed()) {

			Config.PlayerInfo[] players = Config.get().players;
			for (int i = 0; i < players.length; i++)
				players[i].input = menu.getItemAt(i).getSelectedIndex();

			ScreenDisplay.setScreen(ScreenPool.getScreen("MatchSetup"));
		}
	}

	public void draw(Graphics g) {
		super.draw(g);

		g.drawImage(title, 185, 60, null);
		menu.draw(g, 90, 100);
	}
}

/*
 * ScreenDisplay.java
 *
 * Created on March 28, 2003, 7:15 PM
 */

package pyro;

import pyro.display.*;

import java.awt.Graphics;
import java.awt.Color;
import java.awt.event.KeyEvent;

/** Class responsible for displaying Screens. The main loop is housed within the
 * start() method.
 */
public class ScreenDisplay {
	private static boolean running = true;
	private static KeyboardHandler keyboard;
	private static DisplayProvider display;
	private static Screen screen;

	private static boolean showingQuitScreen = false;
	private static TickTimer keyTick;
	private static QuitScreen quitScreen;

	/** Do not allow construction */
	private ScreenDisplay() {}

	/** Initializes the ScreenDisplay.
	 */
	public static void init() {
		keyboard = new KeyboardHandler();
		keyTick = new TickTimer(6);
		FrameRateMonitor.setFrameRate(60);
	}

	/** Starts the display. Updates and draws the currently displayed Screen
	 * every frame, maintaining a constant 60 frames per second. This method
	 * will not return until stop() is called. The main loop resides in this
	 * method - OPTIMIZE!
	 */
	public static void start() {
		Graphics g;
		FrameRateMonitor.start();

		while (running) {
			FrameRateMonitor.startFrame(); //START

			g = display.getGraphics();

			if (keyTick.timeUp() && keyboard.keys[KeyEvent.VK_ESCAPE]) {
				keyTick.reset();
				quitScreen = (QuitScreen)ScreenPool.getScreen("Quit");
				quitScreen.initialize();
				showingQuitScreen = !showingQuitScreen;
			}

			g.setColor(Color.BLACK);
			g.fillRect(0, 0, 800, 600);

			g.setColor(Color.WHITE);
			g.drawString(String.valueOf(FrameRateMonitor.getFramesPerSecond()), 0, 600);

			//Globally update all timers
			TickTimer.step();

			//Moves the graphics context to the point where the square starts
			g.translate(175, 75);

			//Steps and draws the current screen - CORE GAME LOGIC
			if (!showingQuitScreen)
				screen.step();
			screen.draw(g);

			//Display the quit screen if necessary
			if (showingQuitScreen) {
				quitScreen.step();
				quitScreen.draw(g);
				if (quitScreen.shouldQuit())
					stop();
				else if (quitScreen.shouldResume()){
					showingQuitScreen = false;
					keyTick.reset();
				}
					
			}

			//Steps the sound system
			//SoundSystem.step();

			//**Perform the actual drawing**
			display.showGraphics();

			FrameRateMonitor.endFrame(); //END
		}
	}

	/** Gets the current state of the keyboard, represented by an array of
	 * booleans.  The index of the array refers to the key (as specified by
	 * java.awt.event.KeyEvent.VK_??) and the element defines whether or not
	 * the key is down.  For example, to determine if the Enter key is pressed,
	 * you would do the following:
	 * <pre>
	 *   boolean[] state = ScreenDisplay.getKeyState();
	 *   if (state[ java.awt.KeyEvent.VK_ENTER ])
	 *     //enter is pressed
	 * </pre>
	 * @return the key states
	 */
	public static boolean[] getKeyState() {
		return keyboard.keys;
	}

	/** Sets the device used to display the screens.
	 */
	public static void setDisplayProvider(DisplayProvider p) {
		display = p;
		display.addKeyListener(keyboard);
	}

	/** Sets the currently displayed screen.
	 */
	public static void setScreen(Screen s) {
		screen = s;
		screen.initialize();
	}

	/** Stops the screen display.  The start() method will now return.
	 */
	public static void stop() {
		running = false;
	}
}
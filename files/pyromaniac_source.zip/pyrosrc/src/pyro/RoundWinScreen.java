/*
 * Created on May 20, 2003 at 9:51:19 PM
 * Project: Pyromaniac
 */
package pyro;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

/**
 * Class: RoundWinScreen
 * @author MASTER
 */
public class RoundWinScreen extends AbstractMenuScreen {
	/** Graphics for the screen */
	private BufferedImage[] cup;
	private BufferedImage[] winner;
	private BufferedImage[] loser;
	private BufferedImage title;

	private TickTimer anim, endDelay;
	private int delayTickCount;
	private Config.PlayerInfo[] info;

	/** Current animation frame for the cup */
	private int frame;
	/** Player that won the last round */
	private int pWinner;
	/** Whether to continue the game or go to the title screen */
	private boolean continueGame;

	public RoundWinScreen() throws Exception {
		SpriteFont wFont = FontPool.getFont("white");
		title = wFont.createText("SCOREBOARD");

		cup = new BufferedImage[6];
		for (int i = 0; i < cup.length; i++)
			cup[i] = ImagePool.getImage("heads/cup" + i + ".png");

		winner = new BufferedImage[4];
		for (int i = 0; i < winner.length; i++)
			winner[i] = ImagePool.getImage("heads/winner" + i + ".png");

		loser = new BufferedImage[4];
		for (int i = 0; i < loser.length; i++)
			loser[i] = ImagePool.getImage("heads/loser" + i + ".png");

		anim = new TickTimer(5);
		endDelay = null;
	}

	public void initialize() {
		super.initialize();
		anim.reset();
		endDelay = null;
		delayTickCount = 0;

		info = Config.get().players;
		pWinner = Config.get().lastWinner;
		if (pWinner > -1)
			continueGame = info[pWinner].wins < Config.get().winsNeeded;
		else
			continueGame = true;

	}

	public void step() {
		super.step();
		delayTickCount++;

		if (anim.timeUp()) {
			frame++;
			if (frame >= cup.length)
				frame = 0;
		}

		boolean[] keys = ScreenDisplay.getKeyState();
		for (int i = 0; i < keys.length; i++)
			if (keys[i] && delayTickCount >= 120 && endDelay == null)
				endDelay = new TickTimer(60);

		if (endDelay != null && endDelay.timeUp())
			if (continueGame)
				ScreenDisplay.setScreen(ScreenPool.getScreen("Game"));
			else
				ScreenDisplay.setScreen(ScreenPool.getScreen("Title"));
	}

	public void draw(Graphics g) {
		super.draw(g);

		g.drawImage(title, 140, 60, null);

		final int V_GAP = 85;
		final int H_GAP = 55;
		int ypos = 90;

		for (int i = 0; i < Config.get().players.length; i++) {
			if (i == pWinner) {
				g.drawImage(winner[info[i].color], 80, ypos, null);
				for (int j = 0; j < Config.get().players[i].wins; j++)
					g.drawImage(cup[frame], 160 + (j * H_GAP), ypos + 5, null);
				ypos += 90;
			} else {
				g.drawImage(loser[info[i].color], 80, ypos, null);
				for (int j = 0; j < Config.get().players[i].wins; j++)
					g.drawImage(cup[0], 160 + (j * H_GAP), ypos + 5, null);
				ypos += 65;
			}

		}
	}
}
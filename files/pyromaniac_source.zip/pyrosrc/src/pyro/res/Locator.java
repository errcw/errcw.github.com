/*
 * Created on May 2, 2003 at 4:11:33 PM
 * Project: Pyromaniac
 */
package pyro.res;

/**
 * @author MASTER
 * Class: Locator
 */
public class Locator {}

/*
 * Created on Apr 30, 2003 at 7:21:26 PM
 * Project: Pyromaniac
 */

package pyro;

import java.io.*;

/**
 * @author MASTER
 * Defines a variety of parameters for setting up a game.
 * Keys needed for input: UP, DOWN, LEFT, RIGHT, ACTION1, ACTION2
 */
public class Config implements Serializable {
	private static Config instance;

	/**
	 * The maximum number of players in a game.
	 */
	public final int MAX_PLAYERS = 4;

	/**
	 * Defines the different input schemes (keyboard 1-4).
	 */
	public InputScheme[] schemes = new InputScheme[MAX_PLAYERS];

	/**
	 * Defines info about all the players playing.
	 */
	public PlayerInfo[] players;

	/**
	 * The total time in one round.
	 */
	public int time = 100;

	/**
	 * The time when "hurry up!" begins
	 */
	public int hurry = 50;

	/**
	 * The number of round wins needed to win the match.
	 */
	public int winsNeeded = 1;

	/**
	 * The arena to play the match in.
	 */
	public int arena = 0;
	
	/**
	 * The number of tie games in the current match.
	 */
	public int ties = 0;
	
	/**
	 * The winner of the last round.
	 */
	public int lastWinner = -1;

	public void createDefaultSchemes() {
		for (int i = 0; i < schemes.length; i++) {
			schemes[i] = new InputScheme();
			schemes[i].action1 = 32;
			schemes[i].action2 = 32;
			schemes[i].down = 32;
			schemes[i].left = 32;
			schemes[i].right = 32;
			schemes[i].up = 32;
		}
	}

	/**
	 * Gets the singleton instance of the configration class. Although using
	 * static varaibles would be preferable, instance variables are required
	 * for serialization.
	 * @return the config instance
	 */
	public static Config get() {
		if (instance == null)
			instance = new Config();
		return instance;
	}

	public static void saveConfiguration(String file) throws Exception {
		ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(file));
		out.writeObject(instance);
		out.close();
	}

	public static void loadConfiguration(String file) throws Exception {
		ObjectInputStream in = new ObjectInputStream(new FileInputStream(file));
		instance = (Config)in.readObject();
	}

	public class InputScheme implements Serializable {
		public int up, down, left, right, action1, action2;
	}
	
	public class PlayerInfo implements Serializable {
		public int color, input, wins;
	}
}

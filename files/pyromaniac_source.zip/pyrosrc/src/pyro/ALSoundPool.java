/*
 * Created on May 16, 2003 at 8:24:37 PM
 * Project: Pyromaniac
 */
package pyro;

import pyro.sound.*;
import pyro.res.Locator;

import java.util.HashMap;

/**
 * @author MASTER
 * Class: ALSoundPool
 */
public class ALSoundPool {
	private static HashMap pool;

	public static void init() {
		pool = new HashMap();

		ALSound snd;

		//Load the sound effects
		snd = new ALSound(Locator.class.getResource("sounds/menu_switch.wav"));
		pool.put("sounds/menu_switch.wav", snd);
		snd = new ALSound(Locator.class.getResource("sounds/menu_select.wav"));
		pool.put("sounds/menu_select.wav", snd);
		snd = new ALSound(Locator.class.getResource("sounds/boom.wav"));
		pool.put("sounds/boom.wav", snd);
		snd = new ALSound(Locator.class.getResource("sounds/bomb_drop.wav"));
		pool.put("sounds/bomb_drop.wav", snd);
		snd = new ALSound(Locator.class.getResource("sounds/pickup.wav"));
		pool.put("sounds/pickup.wav", snd);
		snd = new ALSound(Locator.class.getResource("sounds/death.wav"));
		pool.put("sounds/death.wav", snd);
		snd = new ALSound(Locator.class.getResource("sounds/warning.wav"));
		pool.put("sounds/warning.wav", snd);
		snd = new ALSound(Locator.class.getResource("sounds/round_over.wav"));
		pool.put("sounds/round_over.wav", snd);
		snd = new ALSound(Locator.class.getResource("sounds/block_drop.wav"));
		pool.put("sounds/block_drop.wav", snd);

		//Load the music
		snd = new ALOggSound(Locator.class.getResource("music/menu.ogg"));
		pool.put("music/menu.ogg", snd);
		snd = new ALOggSound(Locator.class.getResource("music/battle.ogg"));
		pool.put("music/battle.ogg", snd);
	}

	public static ALSound getSound(String filename) {
		return (ALSound)pool.get(filename);
	}
}
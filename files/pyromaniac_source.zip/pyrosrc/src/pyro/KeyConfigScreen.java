/*
 * Created on May 4, 2003 at 11:31:03 AM
 * Project: Pyromaniac
 */
package pyro;

import pyro.gui.*;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

/**
 * @author MASTER
 * Class: KeyConfigScreen
 */
public class KeyConfigScreen extends AbstractMenuScreen {
	/** The names of the keys to configure. */
	private static final String[] KEYS =
		{ "UP", "DOWN", "LEFT", "RIGHT", "ACTION1", "ACTION2" };

	private BufferedImage title;
	private CyclableMenu menu;
	private CyclableMenuItem[] items;
	/** The keyboard device currently being configured. */
	private int curDevice;
	private int music;

	public KeyConfigScreen() throws Exception {
		super();

		SpriteFont font = FontPool.getFont("white");
		title = font.createText("KEY CONFIGURATION");

		//music = SoundPool.getSound(SoundPool.KEY_MUSIC);

		buildGUI();
		initKeys();
	}

	/**
	 * @see pyro.Screen#initialize()
	 */
	public void initialize() {
		super.initialize();

		//MusicSystem.play(music);
		//MusicSystem.setVolume(0.5d);
	}

	/** Builds the GUI for the key configuration screen.
	 */
	private void buildGUI() {
		SpriteFont font = FontPool.getFont("white");
		SpriteFont rfont = FontPool.getFont("red");
		items = new CyclableMenuItem[7];

		BufferedImage keyboard = font.createText("DEVICE");
		BufferedImage[] devices = new BufferedImage[4];
		for (int i = 0; i < devices.length; i++)
			devices[i] = font.createText("KEYBOARD " + (i + 1));

		items[0] = new BasicCyclableMenuItem(keyboard, devices, 125);

		for (int i = 1; i < items.length; i++)
			items[i] = new KeyConfigMenuItem(font.createText(KEYS[i - 1]), 32, 125);

		menu = new CyclableMenu(items, 32);
		curDevice = 0;
	}

	/** Given the current keyboard device being configured, displays all the
	 * current values for the keys.
	 */
	private void initKeys() {
		Config.InputScheme input = Config.get().schemes[curDevice];

		((KeyConfigMenuItem)items[1]).createKeyEntry(input.up);
		((KeyConfigMenuItem)items[2]).createKeyEntry(input.down);
		((KeyConfigMenuItem)items[3]).createKeyEntry(input.left);
		((KeyConfigMenuItem)items[4]).createKeyEntry(input.right);
		((KeyConfigMenuItem)items[5]).createKeyEntry(input.action1);
		((KeyConfigMenuItem)items[6]).createKeyEntry(input.action2);
	}

	private void saveKeys() {
		Config.InputScheme input = Config.get().schemes[curDevice];

		input.up = items[1].getSelectedIndex();
		input.down = items[2].getSelectedIndex();
		input.left = items[3].getSelectedIndex();
		input.right = items[4].getSelectedIndex();
		input.action1 = items[5].getSelectedIndex();
		input.action2 = items[6].getSelectedIndex();
	}

	/**
	 * @see pyro.Screen#step()
	 */
	public void step() {
		super.step();

		boolean[] keys = ScreenDisplay.getKeyState();
		menu.step(keys);

		if (menu.enterPressed()) {
			saveKeys();
			ScreenDisplay.setScreen(ScreenPool.getScreen("Title"));
		}

		//Check if the user has changed devices.
		int kbd = menu.getItemAt(0).getSelectedIndex();
		if (kbd != curDevice) {
			saveKeys();
			curDevice = kbd;
			initKeys();
		}
	}

	/**
	 * @see pyro.Screen#draw(java.awt.Graphics)
	 */
	public void draw(Graphics g) {
		super.draw(g);

		g.drawImage(title, 89, 60, null);
		menu.draw(g, 50, 110);
	}

}

/*
 * AbstractMenuScreen.java
 *
 * Created on April 4, 2003, 5:32 PM
 */

package pyro;

//import pyro.sound.*;

import java.awt.*;
import java.awt.image.*;

/** An abstract menu class defining the base behavior of a menu.  The class handles
 * the animation of the background.  Classes extending AbstractMenuScreen should call
 * super.intialize(), super.draw(Graphics), and super.step() every time those methods
 * are called in the child method.
 */
public abstract class AbstractMenuScreen extends Screen {
	/** The number of ticks before the bomb spinning changes frames */
	private static final int ANIM_DURATION = 3;

	/** The edges of the background */
	private static BufferedImage backTop, backLeft, backRight, backBottom;
	/** The centre of the background */
	private BufferedImage[] spin;
	/** Timer timing the animation */
	private TickTimer timer;
	/** ID of the background music */
	public static int music;
	/** The image of the hand pointing to the selected menu item */
	public static BufferedImage hand;

	private int dir, frame;

	/** Creates a new instance of AbstractMenuScreen */
	public AbstractMenuScreen() throws Exception {
		spin = new BufferedImage[20];
		timer = new TickTimer(ANIM_DURATION);

		//load the edges of the background
		backTop = ImagePool.getImage("menu/menuspintop.jpg");
		backLeft = ImagePool.getImage("menu/menuspinleft.jpg");
		backRight = ImagePool.getImage("menu/menuspinright.jpg");
		backBottom = ImagePool.getImage("menu/menuspinbottom.jpg");
		hand = ImagePool.getImage("menu/hand.png");

		//load the centres
		for (int i = 0; i < spin.length; i++)
			spin[i] = ImagePool.getImage("menu/menuspin" + i + ".jpg");

		//music = SoundPool.getSound(SoundPool.MENU_MUSIC);
	}

	/** Initializes the Screen.
	 */
	public void initialize() {
		frame = 1; //initial frame for the bomb spinning animation
		dir = 1; //initial direction to traverse the array of frames
		timer.reset();

		//if (!MusicSystem.isPlaying(music))
			//MusicSystem.play(music);
		//MusicSystem.setVolume(0.5d);
	}

	/** Updates the Screen for the current frame.  Animates the spinning bomb,
	 * chaning the frame if enough game ticks have passed since the last frame
	 * change.
	 */
	public void step() {

		if (timer.timeUp()) {
			if (frame == 0 || frame == 19)
				dir *= -1; //go in the opposite direction

			frame += dir;
		}

		//if (!MusicSystem.isPlaying())
			//MusicSystem.play(music);
	}

	/** Draws background of the menu screen.
	 * @param g the graphical context on which to draw
	 */
	public void draw(Graphics g) {
		//draw the edges of the background
		g.drawImage(backTop, 0, 0, null);
		g.drawImage(backLeft, 0, 64, null);
		g.drawImage(backRight, 375, 64, null);
		g.drawImage(backBottom, 75, 385, null);

		//draw the centre, spinning bomb
		g.drawImage(spin[frame], 75, 65, null);
	}
}
/*
 * Created on May 11, 2003 at 6:31:15 PM
 * Project: Pyromaniac
 */
package pyro;

import pyro.gui.*;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

/**
 * @author MASTER
 * Class: MatchSetupScreen
 */
public class MatchSetupScreen extends AbstractMenuScreen {
	private BufferedImage title;
	private CyclableMenu menu;

	public MatchSetupScreen() throws Exception {
		SpriteFont wFont = FontPool.getFont("white");
		SpriteFont rFont = FontPool.getFont("red");

		title = wFont.createText("MATCH SETUP");

		BasicCyclableMenuItem[] items = new BasicCyclableMenuItem[3];

		//Create the item for the number of wins needed to win the match.
		BufferedImage battleLbl = wFont.createText("BATTLE");
		BufferedImage[] number = new BufferedImage[4];
		for (int i = 0; i < number.length; i++)
			number[i] = rFont.createText(String.valueOf(i + 1));
		items[0] = new BasicCyclableMenuItem(battleLbl, number, 150);

		//Create the item listing the match times available
		BufferedImage timeLbl = wFont.createText("START");
		BufferedImage[] sTimes = new BufferedImage[13];
		int time = 60;
		for (int i = 0; i < sTimes.length; i++) {
			sTimes[i] = rFont.createText(Tools.secondsToTime(time));
			time += 15;
		}
		items[1] = new BasicCyclableMenuItem(timeLbl, sTimes, 150);

		//Create the item listing when the "hurry up!" period should begin.
		BufferedImage hurryLbl = wFont.createText("HURRY");
		BufferedImage[] hTimes = new BufferedImage[5];
		int htime = 0;
		for (int i = 0; i < hTimes.length; i++) {
			hTimes[i] = rFont.createText(Tools.secondsToTime(htime));
			htime += 15;
		}
		items[2] = new BasicCyclableMenuItem(hurryLbl, hTimes, 150);

		menu = new CyclableMenu(items, 50);
	}

	public void initialize() {
		super.initialize();
	}

	public void step() {
		super.step();

		boolean[] keys = ScreenDisplay.getKeyState();
		menu.step(keys);

		if (menu.enterPressed()) {
			Config.get().winsNeeded = menu.getItemAt(0).getSelectedIndex() + 1;
			//the time measured in ticks - seconds x 60, since 60 fps
			Config.get().time = (60 + (menu.getItemAt(1).getSelectedIndex() * 15)) * 60;
			Config.get().hurry = (menu.getItemAt(2).getSelectedIndex() * 15) * 60;

			ScreenDisplay.setScreen(ScreenPool.getScreen("ArenaSelect"));
		}
	}

	public void draw(Graphics g) {
		super.draw(g);

		g.drawImage(title, 137, 60, null);
		menu.draw(g, 90, 125);
	}
}

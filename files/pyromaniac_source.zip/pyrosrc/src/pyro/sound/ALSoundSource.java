/*
 * Created on May 16, 2003 at 6:07:09 PM
 * Project: Pyromaniac
 */
package pyro.sound;

import org.lwjgl.Sys;
import org.lwjgl.openal.*;

import java.nio.IntBuffer;

/**
 * @author MASTER
 * Class: ALSoundSource
 */
public class ALSoundSource {
	private final IntBuffer source;
	
	/** The sound currently being played by the source, or the last sound
	 * played by the AL source.
	 */
	private ALSound currentSound;

	public ALSoundSource() throws OpenALException {
		int error;

		source = pyro.Tools.createIntBuffer(1);

		//Generate the source
		ALSoundManager.al.genSources(1, Sys.getDirectBufferAddress(source));
		if ((error = ALSoundManager.al.getError()) != AL.NO_ERROR)
			throw new OpenALException("Error generating buffer!");

	}

	/**
	 * Unloads the AL source associated with this instance.
	 */
	public void dispose() {
		ALSoundManager.al.deleteSources(1, Sys.getDirectBufferAddress(source));
	}

	/**
	 * Plays the currently attatched ALSound
	 */
	private void play() {
		ALSoundManager.al.sourcePlay(source.get(0));
	}

	public void stop() {
		ALSoundManager.al.sourceStop(source.get(0));
	}

	/**
	 * @return if the source is currently playing a sound
	 */
	public boolean isPlaying() {
		IntBuffer b = pyro.Tools.createIntBuffer(1);
		ALSoundManager.al.getSourcei(
			source.get(0),
			AL.SOURCE_STATE,
			Sys.getDirectBufferAddress(b));

		int result = b.get(0);
		if (result == AL.PLAYING)
			return true;
		else
			return false;
	}
	
	/**
	 * @return if the specified sound is being played by this source
	 */
	public boolean isPlaying(ALSound sound){
		return sound.equals(currentSound) && isPlaying();
	}

	/**
	 * Attatches a the AL sound buffer to the AL sound to the source, and plays it.
	 * @param sound the sound to play
	 */
	protected void attatch(ALSound sound) {
		currentSound = sound;
		
		//Set up the source input
		ALSoundManager.al.sourcei(source.get(0), AL.BUFFER, sound.getBuffer());
		
		//Loop the sound if necessary
		if (sound.looping())
			ALSoundManager.al.sourcei(source.get(0), AL.LOOPING, AL.TRUE);
		else
			ALSoundManager.al.sourcei(source.get(0), AL.LOOPING, AL.FALSE);
		
		//Set the gain (volume)
		ALSoundManager.al.sourcef(source.get(0), AL.GAIN, sound.getGain());
		
		//Play the sound
		play();
	}
}

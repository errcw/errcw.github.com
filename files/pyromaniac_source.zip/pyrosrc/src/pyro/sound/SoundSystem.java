/*
 * SoundSystem.java
 *
 * Created on April 11, 2003, 7:06 PM
 */

package pyro.sound;

import org.lwjgl.Sys;

import java.net.URL;
import java.io.*;

import javax.sound.sampled.*;

/** Sound engine designed to load and play '.wav' files.  The engine operates
 * statically, and therefore does not need to be instantiated prior to use. Up
 * to 32 clips can be loaded into memory, and up to 64 separate instances can
 * be played simultaneously.
 *
 * A note on IDs:  When a sound is loaded, an ID referring to the _data_ is returned.
 * When, however, a sound is played using the data ID, a reference to the specific
 * instance of that sound being played is returned.  Thus, multiple instances of the
 * same sound can be played and controlled separately.  The distiction is made in
 * method parameters, with dataID and instanceID
 */
public class SoundSystem {
    private static SourceDataLine[] lines;
    private static SoundData[] sounds;
    private static SoundClip[] clips;
    
    private static int loadID = 0;
    private static long then, now;
    private static float seconds;
    
    /** Do not allow construction */
    private SoundSystem() {}
    
    /** Initializes the sound system.  Must be called prior to using any other
     * methods!
     */
    public static void init() throws Exception{
        lines = new SourceDataLine[32];
        sounds = new SoundData[32];
        clips = new SoundClip[64];
        for (int i = 0; i < clips.length; i++) {
            clips[i] = new SoundClip();
            clips[i].position = -1;
        }
    }
    
    /** Loads a sound clip into memory and returns an id to identify the clip.
     */
    public static int load(URL file)
    throws IOException, UnsupportedAudioFileException, LineUnavailableException {
        AudioInputStream ain = AudioSystem.getAudioInputStream(file);
        AudioFormat format = ain.getFormat();
        DataLine.Info info = new DataLine.Info(SourceDataLine.class, format, AudioSystem.NOT_SPECIFIED);
        SoundData sound = new SoundData(ain);
        
        sounds[loadID] = sound;
        lines[loadID] = (SourceDataLine)AudioSystem.getLine(info);
        lines[loadID].open(format);
        
        loadID++;
        return loadID - 1;
    }
    
    /** Commences playback of the selected clip.  The ID returned by the method
     * uniquely identifies the new copy of the clip being played. If one copy of the
     * clip is already playing, another new one is started.  If the clip ID is invalid,
     * the method simply returns.
     * @param id the identity of the clip to play, as returned by load()
     * @return id of the instance of the sound playing
     */
    public static int play(int dataID) {
        if (lines[dataID] == null) return -1;
        
        for (int i = 0; i < clips.length; i++)
            if (clips[i].position < 0) { //the clip is unused
                clips[i].position = 0;
                clips[i].id = dataID;
                return i;
            }
        return -1;
    }
    
    public static boolean isPlaying(int instanceID){
        return clips[instanceID].position >= 0;
    }
    
    public static void stop(int instanceID){
        if (clips[instanceID] == null) return;
        clips[instanceID].position = -1;
    }
    
    /** Plays back sound for the frame.  Determines the length of time since the
     * last frame and plays back an according amount of sound.  If too much time
     * elapses between updates, the SoundSystem should continue normally
     */
    public static void step() {
        now = Sys.getTime();
        seconds = (now - then) / (float)Sys.getTimerResolution();
        int bytes, bytesToPlay;
        
        if (then == 0) {
            then = Sys.getTime();
            return;
        }
        
        for (int i = 0; i < clips.length; i++){
            if (clips[i].position < 0) continue;
            
            int dataID = clips[i].id;
            bytesToPlay = sounds[dataID].getBytesToPlay(seconds);
            bytes = Math.min(bytesToPlay, sounds[dataID].data.length - clips[i].position);
            
            if (bytes > 0){
                lines[dataID].write(sounds[dataID].data, clips[i].position, bytes);
                clips[i].position += bytes;
            }
            
            if (clips[i].position >= sounds[dataID].data.length) clips[i].position = -1;
            
            if(!lines[dataID].isRunning()) lines[dataID].start();
        }
        
        then = now;
    }    
}
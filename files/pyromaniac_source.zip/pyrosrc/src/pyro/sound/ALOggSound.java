/*
 * Created on May 17, 2003 at 12:41:27 PM
 * Project: Pyromaniac
 */
package pyro.sound;

import org.lwjgl.Sys;
import org.lwjgl.openal.AL;
import org.lwjgl.openal.OpenALException;

import java.net.URL;
import java.nio.IntBuffer;

/**
 * @author MASTER
 * Class: ALOggSound
 */
public class ALOggSound extends ALSound {
	private IntBuffer buffer;
	private int ibuffer;

	/**
	 * Creates a new AL sound.
	 * @param file the source audio file
	 * @throws OpenALException if an error occurs loading the file
	 */
	public ALOggSound(URL file) throws OpenALException {
		int error;

		//Create the buffer
		buffer = pyro.Tools.createIntBuffer(1);

		//AL generate the buffer
		ALSoundManager.al.genBuffers(1, Sys.getDirectBufferAddress(buffer));
		if ((error = ALSoundManager.al.getError()) != AL.NO_ERROR)
			throw new OpenALException("Error generating buffer!");

		OggVorbisData oggfile;
		//Load the ogg data
		try {
			oggfile = OggVorbisData.create(file);
		} catch (Exception e) {
			System.out.println("Error creating ogg vorbis data!");
			e.printStackTrace();
			throw new OpenALException("Error opening Ogg file!");
		}

		//Copy to buffers
		ibuffer = buffer.get(0);
		int addr = Sys.getDirectBufferAddress(oggfile.data);
		int cap = oggfile.data.capacity();
		int sample = oggfile.samplerate;

		ALSoundManager.al.bufferData(ibuffer, oggfile.format, addr, cap, sample);
		if ((error = ALSoundManager.al.getError()) != AL.NO_ERROR)
			throw new OpenALException("Error copying to buffer!");

		//Unload the file
		oggfile.dispose();
		super.looping = true;
		super.setGain(1.0f);
	}

	/**
	 * Unloads the AL buffer associated with the sound.
	 */
	public void dispose() {
		ALSoundManager.al.deleteBuffers(1, Sys.getDirectBufferAddress(buffer));
	}

	/**
	 * @return the pointer to the buffer
	 */
	public int getBuffer() {
		return ibuffer;
	}

	/**
	 * @return if the sound should be looped, default true for ".ogg" files
	 */
	public boolean looping() {
		return true;
	}
}

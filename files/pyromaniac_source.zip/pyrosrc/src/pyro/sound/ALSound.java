/*
 * Created on May 16, 2003 at 6:06:48 PM
 * Project: Pyromaniac
 */
package pyro.sound;

import org.lwjgl.Sys;
import org.lwjgl.openal.AL;
import org.lwjgl.openal.OpenALException;

import java.net.URL;
import java.nio.IntBuffer;

/**
 * @author MASTER
 * Class: ALSound
 */
public class ALSound {
	/** The AL buffer holding the sound*/
	private IntBuffer buffer;
	/** Pointer to the AL buffer */
	private int ibuffer;
	/** If the sound is looping */
	protected boolean looping;
	/** The gain of the sound */
	protected float gain;

	public ALSound() {}

	/**
	 * Creates a new AL sound.
	 * @param file the source audio file
	 * @throws OpenALException if an error occurs loading the file
	 */
	public ALSound(URL file) throws OpenALException {
		int error;

		//Create the buffer
		buffer = pyro.Tools.createIntBuffer(1);

		//AL generate the buffer
		ALSoundManager.al.genBuffers(1, Sys.getDirectBufferAddress(buffer));
		if ((error = ALSoundManager.al.getError()) != AL.NO_ERROR)
			throw new OpenALException("Error generating buffer!");

		//Load the wave data
		WaveData wavefile = WaveData.create(file);

		//Copy to buffers
		ibuffer = buffer.get(0);
		int addr = Sys.getDirectBufferAddress(wavefile.data);
		int cap = wavefile.data.capacity();
		int sample = wavefile.samplerate;

		ALSoundManager.al.bufferData(ibuffer, wavefile.format, addr, cap, sample);
		if ((error = ALSoundManager.al.getError()) != AL.NO_ERROR)
			throw new OpenALException("Error copying to buffer!");

		//Unload the file
		wavefile.dispose();
		
		setGain(1.0f);
	}

	/**
	 * Unloads the AL buffer associated with the sound.
	 */
	public void dispose() {
		ALSoundManager.al.deleteBuffers(1, Sys.getDirectBufferAddress(buffer));
	}

	/**
	 * @return the pointer to the buffer
	 */
	public int getBuffer() {
		return ibuffer;
	}
	
	public void setGain(float ngain){
		gain = ngain;
	}
	
	public void setLooping(boolean state){
		looping = state;
	}

	/**
	 * @return if the sound should be looped, default false for .wav files
	 */
	public boolean looping() {
		return looping;
	}
	
	/**
	 * @return the requested gain of the ALSound
	 */
	public float getGain(){
		return gain;
	}
}

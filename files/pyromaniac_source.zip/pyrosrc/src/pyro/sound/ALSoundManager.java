/*
 * Created on May 16, 2003 at 6:07:25 PM
 * Project: Pyromaniac
 */
package pyro.sound;

import org.lwjgl.openal.*;

/**
 * @author MASTER
 * Class: ALSoundManager
 */
public class ALSoundManager {
	/** Instance of OpenAL */
	public static AL al;

	/** OpenAL context instance */
	//private static ALC alc;

	/** OpenAL context */
	//private static ALCcontext context;

	/** OpenAL device */
	//private static ALCdevice device;

	/** The number of sources available to play sounds. */
	private static ALSoundSource[] sources;

	public static void init() throws Exception {
		al = new AL();
		//alc = new ALC();

		al.create();
		/*alc.create();

		//Get the default device
		device = alc.openDevice(null);
		
		//Create the context (no attributes specified)
		context = alc.createContext(device, 0);
		
		//Make the context current
		alc.makeContextCurrent(context);*/

		ALSoundSource[] temp = new ALSoundSource[32];
		int nsources = 0;
		//Continue to create sources until no more can be created, or
		//the limit of 32 has been reached
		try {
			for (nsources = 0; nsources < temp.length; nsources++)
				temp[nsources] = new ALSoundSource();
		} catch (OpenALException e) {}

		sources = new ALSoundSource[nsources];

		//Copy the sources from the temp array to the "real" array
		System.arraycopy(temp, 0, sources, 0, nsources);
	}

	/**
	 * Disposes of all the sources, and destroys the AL instance.
	 */
	public static void destroy() {
		for (int i = 0; i < sources.length; i++)
			sources[i].dispose();
		al.destroy();
	}

	/**
	 * Plays the specified ALSound. If no sources are available to play the 
	 * sound, the sound is not played.
	 * @param sound the sound to play
	 */
	public static void play(ALSound sound) {
		for (int i = 0; i < sources.length; i++)
			if (!sources[i].isPlaying()) {
				sources[i].attatch(sound);
				return;
			}
	}

	/**
	 * Determines if any of the AL sources are playing the specified sound.
	 * @param sound the sound to check
	 */
	public static boolean isPlaying(ALSound sound) {
		for (int i = 0; i < sources.length; i++)
			if (sources[i].isPlaying(sound))
				return true;
		return false;
	}

	/**
	 * Stops all of the currently playing sources.
	 */
	public static void stopAll() {
		for (int i = 0; i < sources.length; i++)
			if (sources[i].isPlaying())
				sources[i].stop();
	}
}
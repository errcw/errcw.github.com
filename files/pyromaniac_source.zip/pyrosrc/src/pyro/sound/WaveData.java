/*
 * Created on May 16, 2003 at 7:00:30 PM
 * Project: Pyromaniac
 */
package pyro.sound;

import org.lwjgl.openal.AL;

import javax.sound.sampled.*;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.nio.ByteBuffer;

import java.net.URL;

/**
 * @author MASTER
 * Class: WaveData
 */
public class WaveData {
	/** Actual wave data */
	public final ByteBuffer data;

	/** Format type of data */
	public final int format;

	/** Sample rate of data */
	public final int samplerate;

	private WaveData(ByteBuffer data, int format, int samplerate) {
		this.data = data;
		this.format = format;
		this.samplerate = samplerate;
	}

	public void dispose() {
		data.clear();
	}

	/**
	 * Creates a WaveData container from the specified URL
	 * 
	 * @param file path to file (relative, and in classpath) 
	 * @return WaveData containing data, or null if a failure occured
	 */
	public static WaveData create(URL file) {
		try {
			BufferedInputStream in = new BufferedInputStream(file.openStream());
			return create(AudioSystem.getAudioInputStream(in));
		} catch (Exception e) {
			System.err.println(" - Error opening " + file.toString());
			return null;
		}
	}

	/**
	 * Creates a WaveData container from the specified stream
	 * 
	 * @param ais AudioInputStream to read from
	 * @return WaveData containing data, or null if a failure occured
	 */
	public static WaveData create(AudioInputStream ain) {
		AudioFormat audioformat = ain.getFormat();

		int channels = 0;
		if (audioformat.getChannels() == 1) {
			if (audioformat.getSampleSizeInBits() == 8)
				channels = AL.FORMAT_MONO8;
			else if (audioformat.getSampleSizeInBits() == 16)
				channels = AL.FORMAT_MONO16;
			else
				System.err.println(" -- Unsupported sample size");
		} else if (audioformat.getSampleRate() == 2) {
			if (audioformat.getSampleSizeInBits() == 8)
				channels = AL.FORMAT_STEREO8;
			else if (audioformat.getSampleSizeInBits() == 16)
				channels = AL.FORMAT_STEREO16;
			else
				System.err.println(" -- Unsupported sample size");
		} else {
			System.err.println(" -- Only MONO and STERO are supported!");
		}

		byte[] buf =
			new byte[audioformat.getChannels()
				* (int)ain.getFrameLength()
				* audioformat.getSampleSizeInBits()
				/ 8];

		int read = 0, total = 0;
		try {
			while ((read = ain.read(buf, total, buf.length - total)) != -1
				&& total < buf.length)
				total += read;
		} catch (IOException e) {
			return null;
		}

		//Insert data into byte buffer
		ByteBuffer buffer = ByteBuffer.allocateDirect(buf.length);
		buffer.put(buf);

		//Create the result
		WaveData wave = new WaveData(buffer, channels, (int)audioformat.getSampleRate());

		//Close the audio input stream
		try {
			ain.close();
		} catch (IOException ioe) {}

		return wave;
	}
}

/*
 * SoundClip.java
 *
 * Created on April 11, 2003, 8:25 PM
 */

package pyro.sound;

/** Contains all the data of a sound clip
 */
class SoundClip {
    public int position, id;
}

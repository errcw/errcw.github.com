/*
 * SoundData.java
 *
 * Created on April 11, 2003, 8:34 PM
 */

package pyro.sound;

import java.io.IOException;
import java.io.ByteArrayOutputStream;

import javax.sound.sampled.*;

/** Contains all the data of a sound clip
 */
public class SoundData {    
    public byte[] data;
    private AudioFormat format;
    
    public SoundData(AudioInputStream in) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        int dat;
        
        while ( (dat = in.read()) >= 0) out.write(dat);
        in.close();
        out.close();
        
        data = out.toByteArray();
        format = in.getFormat();
    }
    
    public int getBytesToPlay(float seconds){
        //Bytes per second:
        float bytes = format.getSampleRate() * (format.getSampleSizeInBits() / 8);
        return (int)(seconds * bytes);
    }
}

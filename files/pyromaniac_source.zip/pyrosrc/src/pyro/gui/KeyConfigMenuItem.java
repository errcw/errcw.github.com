/*
 * Created on May 1, 2003 at 6:39:11 PM
 * Project: Pyromaniac
 */
package pyro.gui;

import pyro.*;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.awt.event.KeyEvent;

/**
 * @author MASTER
 * Class: KeyConfigMenuItem
 */
public class KeyConfigMenuItem extends CyclableMenuItem {
	private static SpriteFont font = null;

	private BufferedImage label, keyEntry;
	private boolean[] prevkeys;
	private int keyCode, gap;
	private boolean waitingForKey;

	/**
	 * Creates a new key configuration menu item.
	 * @param label the label for the key entry
	 * @param initcode the initial key code to display
	 * @param hGap the gap between the label and the key entry
	 */
	public KeyConfigMenuItem(BufferedImage label, int initcode, int hGap) {
		if (font == null)
			font = FontPool.getFont("red");
		
		gap = hGap;
		this.label = label;
		createKeyEntry(initcode);
	}

	/** @see pyro.gui.CyclableMenuItem#getSelectedIndex()
	 */
	public int getSelectedIndex() {
		return keyCode;
	}

	/** if enter is pressed while this item has the focus, clears the current 
	 * key entry and waits until a key is pressed. 
	 * @return
	 */
	public boolean handleEnter() {
		prevkeys = ScreenDisplay.getKeyState();

		keyEntry = null;
		waitingForKey = true;

		return true;
	}

	private int getPressedKey() {
		boolean[] keys = ScreenDisplay.getKeyState();
		int key = -1;

		//if the key is pressed, and wasn't pressed before...
		for (int i = 0; i < keys.length; i++)
			if (keys[i]) {
				//log the first key that is pressed
				key = (key == -1) ? i : key;

				if (keys[i] != prevkeys[i])
					return i;
			}
		return key;
	}

	public void keyPressed() {
		if (!waitingForKey)
			return;

		//if a key is pressed, log it
		if ((keyCode = getPressedKey()) != -1) {
			createKeyEntry(keyCode);
			waitingForKey = false;
		}
	}

	public void createKeyEntry(int code) {
		keyCode = code;
		String keyname = KeyEvent.getKeyText(keyCode).toUpperCase();
		keyEntry = font.createText(keyname);
	}

	/** @see pyro.gui.CyclableMenuItem#draw(java.awt.Graphics, int, int)
	 */
	public void draw(Graphics g, int x, int y) {
		g.drawImage(label, x, y, null);
		if (keyEntry != null)
			g.drawImage(keyEntry, x + gap, y, null);
	}

	//No cycling is performed, thus the methods are not needed.
	public void cycleForward() {}
	public void cycleBack() {}
}

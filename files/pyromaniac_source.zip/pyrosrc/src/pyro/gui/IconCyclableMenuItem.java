/*
 * IconCyclableMenuItem.java
 *
 * Created on April 27, 2003, 4:35 PM
 */

package pyro.gui;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

/** Extension of a BasicCyclableMenuItem to provide support for an icon.
 * @author  MASTER
 */
public class IconCyclableMenuItem extends BasicCyclableMenuItem {
    private BufferedImage icon;
    private int iconWidth, iconHeight;
    
    /** Creates a new instance of IconCyclableMenuItem */
    public IconCyclableMenuItem(BufferedImage icon, BufferedImage label, BufferedImage[] items, int gap) {
        super (label, items, gap);
        this.icon = icon;
        iconWidth = icon.getWidth();
        iconHeight = icon.getHeight();
    }
    
    public void draw(Graphics g, int x, int y){
        g.drawImage(icon, x, y, null);
        super.draw(g, x + iconWidth + 10, y - (16 - iconHeight));
    }
}

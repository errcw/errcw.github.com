/*
 * SingleMenuItem.java
 *
 * Created on April 27, 2003, 6:17 PM
 */

package pyro.gui;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

/** Menu item consisting only of a label.  Its behavior is identical to that
 * of a BufferedImage, however this class can be plugges into a CyclableMenu.
 * @author  MASTER
 */
public class SingleMenuItem extends CyclableMenuItem {
    private BufferedImage choice;
    
    /** Creates a new instance of SingleMenuItem */
    public SingleMenuItem(BufferedImage choice) {
        this.choice = choice;
    }       
    
    public void draw(Graphics g, int x, int y) {
        g.drawImage(choice, x, y, null);
    }

    /** Gets the currently selected item.
     * @return always zero, because there is only one item
     */
    public int getSelectedIndex() {
        return 0;
    }
    
    //Not needed since there is no cycling
    public void cycleBack() {}
    public void cycleForward() {}
}

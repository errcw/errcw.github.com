/*
 * BasicCyclableMenuItem.java
 *
 * Created on April 27, 2003, 3:37 PM
 */

package pyro.gui;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

public class BasicCyclableMenuItem extends CyclableMenuItem {
    private BufferedImage label;
    private BufferedImage[] items;
    private int index, gap;
    
    /** Creates a new instance of BasicCyclableMenuItem
     * @param label the name of the item
     * @param items the items to cycle through
     * @param gap the gap between the items and the label
     */
    public BasicCyclableMenuItem(BufferedImage label, BufferedImage[] items, int gap) {
        index = 0;
        this.label = label;
        this.items = items;
        this.gap = gap;
    }
    
    /** Cycles the item backward.  If the beginning of the list is reached, the
     * last item is displayed.
     */
    public void cycleBack() {
        index--;
        if (index < 0)
            index = items.length - 1;
    }
    
    /** Cycles the item forward.  If the end of the list is reached, the first
     * item is displayed.
     */
    public void cycleForward() {
        index++;
        if (index >= items.length)
            index = 0;
    }
    
    /** 
     * @return the index of the currently displayed item
     */
    public int getSelectedIndex() {
        return index;
    }
    
    public void draw(Graphics g, int x, int y) {
        g.drawImage(label, x, y, null);
        g.drawImage(items[index], x + gap, y, null);
    }
    
}

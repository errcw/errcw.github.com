/*
 * CyclableMenuItem.java
 *
 * Created on April 27, 2003, 3:32 PM
 */

package pyro.gui;

public abstract class CyclableMenuItem {
	private boolean focused;

	/** Cycles the item forward.  If the end of the list is reached, the first
	 * item is displayed.
	 */
	public abstract void cycleForward();

	/** Cycles the item backward.  If the beginning of the list is reached, the
	 * last item is displayed.
	 */
	public abstract void cycleBack();

	/**
	 * @return the index of the currently displayed item
	 */
	public abstract int getSelectedIndex();

	/** Performs an action.
	 * @return whether the item handles an "enter" press
	 */
	public boolean handleEnter() {
		return false;
	}

	/** Sets if the item is currently focused. Focus is defined as being
	 * pointed to with the selector.
	 * @param f if the item currently has the focus
	 */
	public void setHasFocus(boolean f) {
		focused = f;
	}

	/**
	 * @return whether the item has the focus.
	 */
	public boolean getHasFocus() {
		return focused;
	}

	/** Notifies the menu item of a key being pressed.
	 */
	public void keyPressed() {}

	public abstract void draw(java.awt.Graphics g, int x, int y);
}

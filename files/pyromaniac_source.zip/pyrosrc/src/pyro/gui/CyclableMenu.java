/*
 * CyclableMenu.java
 *
 * Created on April 27, 2003, 4:03 PM
 */

package pyro.gui;

import pyro.*;
import pyro.sound.*;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.util.Arrays;

public class CyclableMenu {
	private static final int UP = KeyEvent.VK_UP;
	private static final int DOWN = KeyEvent.VK_DOWN;
	private static final int LEFT = KeyEvent.VK_LEFT;
	private static final int RIGHT = KeyEvent.VK_RIGHT;
	private static final int ENTER = KeyEvent.VK_ENTER;

	/** IDs for menu sound effects */
	private int fxSwitch, fxSelect;
	private ALSound sfxSwitch, sfxSelect, sfxWarning;

	/** Timer to avoid checking the keystate once every 1/60 seconds */
	private TickTimer keyCheck;
	/** The menu items present in the cyclable menu */
	private CyclableMenuItem[] items;
	/** The currently selected item */
	private int selected;
	/** The vertical gap between menu items */
	private int vGap;
	private boolean enterPressed, assertNoDuplicates, assertType;
	/** Type checking numbers */
	private int typeToCheck, typeMinimum;

	private boolean[] prevkeys = new boolean[256];

	/** Creates a new instance of CyclableMenu
	 * @param items the items this menu contains
	 * @param vGap the vertical gap between items
	 */
	public CyclableMenu(CyclableMenuItem[] items, int vGap) {
		keyCheck = new TickTimer(15);
		this.items = items;
		this.vGap = vGap;
		selected = 0;
		assertNoDuplicates = false;
		assertType = false;

		//fxSwitch = SoundPool.getSound(SoundPool.SWITCH);
		//fxSelect = SoundPool.getSound(SoundPool.SELECT);

		sfxSwitch = ALSoundPool.getSound("sounds/menu_switch.wav");
		sfxSelect = ALSoundPool.getSound("sounds/menu_select.wav");
		sfxWarning = ALSoundPool.getSound("sounds/warning.wav");
	}

	/** Returns the item at the selected index.
	 */
	public CyclableMenuItem getItemAt(int index) {
		if (index < 0 || index > items.length)
			return null;

		return items[index];
	}

	/** Gets the index of the currently selected item.
	 */
	public int getSelectedIndex() {
		return selected;
	}

	/** Returns whether enter has been pressed.
	 */
	public boolean enterPressed() {
		return enterPressed;
	}

	/**
	 * Enables or disables duplicate entry checking.
	 * @param state
	 */
	public void setDuplicateChecking(boolean state) {
		assertNoDuplicates = state;
	}

	/**
	 * Ensures that no items in the menu have duplicate entries.
	 */
	private boolean assertNoDuplicates() {
		if (!assertNoDuplicates)
			return true;

		boolean[] taken = new boolean[256];
		for (int i = 0; i < items.length; i++) {
			int selected = items[i].getSelectedIndex();
			if (!taken[selected])
				taken[selected] = true;
			else {
				ALSoundManager.play(sfxWarning);
				return false;
			}

		}

		return true;
	}

	/**
	 * Enables or disables type checking.
	 */
	public void setTypeChecking(boolean state, int typeToCheck, int minimum) {
		assertType = state;
		this.typeToCheck = typeToCheck;
		this.typeMinimum = minimum;
	}

	private boolean assertType() {
		if (!assertType)
			return true;

		int count = 0;
		for (int i = 0; i < items.length; i++)
			if (items[i].getSelectedIndex() == typeToCheck)
				count++;

		if (count < typeMinimum) {
			ALSoundManager.play(sfxWarning);
			return false;
		} else {
			return true;
		}
	}

	public void step(boolean[] keys) {
		if (!Arrays.equals(keys, prevkeys) || keyCheck.timeUp()) {
			enterPressed = false;

			for (int i = 0; i < items.length; i++)
				items[i].keyPressed();

			if (keys[ENTER]
				&& !items[selected].handleEnter()
				&& assertNoDuplicates()
				&& assertType()) {

				//SoundSystem.play(fxSelect);
				ALSoundManager.play(sfxSelect);
				enterPressed = true;
			}

			if (keys[LEFT])
				items[selected].cycleBack();

			if (keys[RIGHT])
				items[selected].cycleForward();

			if (keys[UP]) {
				items[selected].setHasFocus(false);
				selected--;
				if (selected < 0)
					selected = items.length - 1;
				items[selected].setHasFocus(true);
			}

			if (keys[DOWN]) {
				items[selected].setHasFocus(false);
				selected++;
				if (selected >= items.length)
					selected = 0;
				items[selected].setHasFocus(true);
			}

			if (keys[LEFT] || keys[RIGHT] || keys[UP] || keys[DOWN])
				//SoundSystem.play(fxSwitch);
				ALSoundManager.play(sfxSwitch);

			keyCheck.reset();
			//Set Enter to be unpressed
			keys[ENTER] = false;

			//Set the previous set of keys to be the current keys
			System.arraycopy(keys, 0, prevkeys, 0, keys.length);
		}
	}

	public void draw(Graphics g, int x, int y) {
		for (int i = 0; i < items.length; i++) {
			if (i == selected)
				g.drawImage(AbstractMenuScreen.hand, x, y + (vGap * i), null);

			items[i].draw(g, x + 40, y + (vGap * i));
		}
	}
}

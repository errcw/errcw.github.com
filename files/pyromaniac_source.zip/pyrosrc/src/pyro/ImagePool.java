/*
 * Created on May 7, 2003 at 7:52:07 PM
 * Project: Pyromaniac
 */
package pyro;

import java.awt.image.BufferedImage;
import java.io.File;
import java.net.URL;
import java.util.HashMap;

/**
 * @author MASTER
 * Class: ImagePool
 */
public class ImagePool {
	private static final String resourceDir = "pyro/res";
	private static HashMap pool;

	public static void init() throws Exception {
		pool = new HashMap();

		File root = new File(resourceDir);
		loadFileTree(root);
	}

	/**
	 * Given a directory root, check all the files inside the directory and
	 * load any images present.
	 * @param directory
	 */
	private static void loadFileTree(File directory) throws Exception {
		if (!directory.isDirectory())
			return;

		File[] files = directory.listFiles();

		for (int i = 0; i < files.length; i++) {

			if (files[i].isDirectory())
				loadFileTree(files[i]);

			if (isImageFile(files[i])) {
				String dirName = files[i].getParentFile().getName();
				String name = dirName + "/" + files[i].getName();

				URL location = files[i].toURL();
				BufferedImage img = Tools.loadImage(location);

				pool.put(name, img);
			}
		}

	}

	/** Determines, by extension, if the specified file is an image file.
	 * @param f the file to assess
	 * @return whether the file is an image
	 */
	private static boolean isImageFile(File f) {
		String name = f.getName();

		int extensionEnd = name.lastIndexOf(".");
		if (extensionEnd <= -1)
			return false;

		String extension = name.substring(extensionEnd);

		if (extension.equals(".jpg")
			|| extension.equals(".png")
			|| extension.equals(".gif"))
			return true;

		return false;
	}

	/**
	 * Gets an image from the pool based on its file name.
	 */
	public static BufferedImage getImage(String file) {
		return (BufferedImage)pool.get(file);
	}
}

/*
 * Created on May 11, 2003 at 9:29:42 PM
 * Project: Pyromaniac
 */
package pyro;

import pyro.sound.*;

import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;

import java.util.Arrays;

/**
 * @author MASTER
 * Class: ArenaSelectScreen
 */
public class ArenaSelectScreen extends AbstractMenuScreen {
	private static final int LEFT = KeyEvent.VK_LEFT;
	private static final int RIGHT = KeyEvent.VK_RIGHT;
	private static final int ENTER = KeyEvent.VK_ENTER;

	/** IDs for menu sound effects */
	private int fxSwitch, fxSelect;
	private ALSound sfxSwitch, sfxSelect;
	/** Font used to draw the arena name */
	private SpriteFont wFont;
	/** The name of the level, i.e. "Arena 1" */
	private BufferedImage levelName;
	private BufferedImage[] previews;
	/** Timer to avoid checking the keystate once every 1/60 seconds */
	private TickTimer keyCheck;
	/** The currently displayed arena. */
	private int arena;
	private int titlex;

	private boolean[] prevkeys = new boolean[256];

	public ArenaSelectScreen() throws Exception {
		keyCheck = new TickTimer(15);

		wFont = FontPool.getFont("white");
		int arenas = ArenaPool.getNumArenas();

		//Create the previews
		previews = new BufferedImage[arenas];
		for (int i = 0; i < arenas; i++)
			previews[i] = Tools.createArenaPreview(ArenaPool.getArena(i));

		//fxSwitch = SoundPool.getSound(SoundPool.SWITCH);
		//fxSelect = SoundPool.getSound(SoundPool.SELECT);
		
		sfxSwitch = ALSoundPool.getSound("sounds/menu_switch.wav");
		sfxSelect = ALSoundPool.getSound("sounds/menu_select.wav");
	}

	private void showArena(int id) {
		arena = id;

		levelName = wFont.createText("ARENA " + (arena + 1));
		titlex = (450 - levelName.getWidth()) / 2;
	}

	public void initialize() {
		super.initialize();

		arena = 0;
		showArena(arena);
	}

	public void step() {
		super.step();

		boolean[] keys = ScreenDisplay.getKeyState();
		if (!Arrays.equals(keys, prevkeys) || keyCheck.timeUp()) {
			if (keys[ENTER]) {
				//SoundSystem.play(fxSelect);
				ALSoundManager.play(sfxSelect);
				
				Config.get().arena = arena;
				ScreenDisplay.setScreen(ScreenPool.getScreen("Game"));
			}

			if (keys[LEFT]) {
				arena--;
				if (arena < 0)
					arena = previews.length - 1;					
			}

			if (keys[RIGHT]) {
				arena++;
				if (arena >= previews.length)
					arena = 0;
			}
			
			if (keys[LEFT] || keys[RIGHT]){
				//SoundSystem.play(fxSwitch);
				ALSoundManager.play(sfxSwitch);
				showArena(arena);
			}

			keyCheck.reset();

			//Set the previous set of keys to be the current keys
			System.arraycopy(keys, 0, prevkeys, 0, keys.length);
		}
	}

	public void draw(Graphics g) {
		super.draw(g);

		g.drawImage(levelName, titlex, 60, null);
		g.drawImage(previews[arena], 90, 125, null);
	}
}

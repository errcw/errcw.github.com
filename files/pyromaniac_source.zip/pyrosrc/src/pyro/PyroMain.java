/*
 *  Student name       Eric Woroshow
 *  Program name       PyroMain.java
 *  Course code        ICS3MO-03
 *  Date               2003-05-22
 *  Teacher            Mrs. Rucinska
 * 
 * PROBLEM STATEMENT: Note that this is an abbreviated version; the full text
 * can be found in the system definition. Pyromaniac is, essentially, a clone of
 * the classic Bomberman game created by HudsonSoft.  In a nutshell, the 
 * gameplay consists of several players destroying both the landscape and each 
 * other with miniature bombs.  The ultimate objective is a fast, frenzied and 
 * fun multiplayer game.
 * 
 * Played from a top-down perspective, players use bombs to destroy blocks in 
 * the level and attempt to knock each other out.  By destroying blocks, users 
 * can earn powerups such as extra speed, extra firepower, and the ability to 
 * kick bombs.  A player wins when he or she is the sole surviving player.
 */

package pyro;

import pyro.display.*;
import pyro.sound.*;

import org.lwjgl.Sys;

import java.io.*;
import java.awt.Dimension;

/**
 * Defines the entry point for Pyromaniac. Initializes all required game
 * subsystems, creates a log file, and begins to load all of the game's
 * resources.
 * @author MASTER
 */
public class PyroMain {
	private static PrintStream out;
	private static DisplayProvider display;

	/** Global initialization. Calls the static initializers on objects which are
	 * used throughout the program.
	 *@throws Exception if the initialization failed
	 */
	private static void init() throws Exception {
		out = new PrintStream(new FileOutputStream("pyro/log.txt"));
		System.setErr(out);
		System.err.println("LOG FOR " + new java.util.Date());

		Sys.setTime(0);
		TickTimer.timerGlobalReset();
		System.err.println("-- Timers initialized OK");

		ScreenDisplay.init();
		System.err.println("-- ScreenDisplay initialized OK");

		SoundSystem.init();
		ALSoundManager.init();
		System.err.println("-- OpenAL Sound system initialized OK");

		Config.loadConfiguration("pyro/config.dat");
		System.err.println("-- Configuration loaded OK");
	}

	/** Cleans up. Terminates the log, closes the display, and destroys the
	 * OpenAL sound system.
	 */
	private static void cleanup() {
		ALSoundManager.destroy();
		System.err.println("-- AL sound system destroyed OK");
		
		display.close();
		System.err.println("-- Display closed OK");

		System.err.println("END OF LOG");
		out.close();
	}

	/** Parses the command line arguments.  Looks for the switch specifying
	 * the display mode the game should run in. Note that the current
	 * implementation of fullscreen is NOT functional. Attempting to run the
	 * program with this option will cause a crash.
	 * 
	 * @param args command line arguments to parse
	 */
	private static void parseArguments(String[] args) {
		if (args.length > 0 && args[0].equals("-fullscreen"))
			display = new DisplayFullscreen();
		else
			display = new DisplayWindow();
	}

	/** Entry point for the application.
	 * @param args the command line arguments
	 */
	public static void main(String[] args) {

		try {
			//Config.get().createDefaultSchemes();
			//Config.saveConfiguration("pyro/config.dat");

			parseArguments(args);
			init();

			display.initializeDisplay(new Dimension(800, 600), "Pyromaniac (v1.0)");
			System.err.println("-- Primary display initialized OK");

			LoadingScreen s = new LoadingScreen();

			ScreenDisplay.setDisplayProvider(display);
			ScreenDisplay.setScreen(s);
			ScreenDisplay.start();

			Config.saveConfiguration("pyro/config.dat");
			System.err.println("-- Configuration saved OK");
		} catch (Throwable t) {
			t.printStackTrace();
			System.err.println("Fatal error. Program terminated");
		} finally {
			cleanup();
			System.exit(0);
		}

	}
}

/*
 * KeyboardHandler.java
 *
 * Created on April 4, 2003, 5:16 PM
 */

package pyro;

import java.awt.event.*;

/** Class managing key pressing.  KeyboardHandler logs all the keys which are
 * currently depressed, which can be accessed via [code]keys[/code].
 */
public class KeyboardHandler implements KeyListener {
	public boolean[] keys = new boolean[256];
	public int lastKeyTyped = -1;

	public void keyPressed(KeyEvent e) {
		keys[e.getKeyCode()] = true;
	}

	public void keyReleased(KeyEvent e) {
		keys[e.getKeyCode()] = false;
	}

	public void keyTyped(KeyEvent e) {
		lastKeyTyped = e.getKeyCode();
	}
}

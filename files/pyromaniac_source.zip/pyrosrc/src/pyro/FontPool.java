/*
 * FontPool.java
 *
 * Created on April 27, 2003, 6:06 PM
 */

package pyro;

import pyro.res.Locator;
import java.util.HashMap;

/**
 *
 * @author  MASTER
 */
public class FontPool {
	private static HashMap fonts;

	/** Do not allow construction */
	private FontPool() {
	}

	public static void init() throws Exception {
		SpriteFont temp;
		fonts = new HashMap(3);

		temp = new SpriteFont(Locator.class.getResource("fonts/whiteFont.dat"));
		fonts.put("white", temp);
		temp = new SpriteFont(Locator.class.getResource("fonts/redFont.dat"));
		fonts.put("red", temp);
		temp = new SpriteFont(Locator.class.getResource("fonts/yellowFont.dat"));
		fonts.put("yellow", temp);
		temp = new SpriteFont(Locator.class.getResource("fonts/blackFont.dat"));
		fonts.put("black", temp);
	}

	public static SpriteFont getFont(String name) {
		return (SpriteFont)fonts.get(name);
	}
}

/*
 * Created on May 12, 2003 at 8:09:49 PM
 * Project: Pyromaniac
 */
package pyro.game;

import pyro.*;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.awt.Point;

import java.util.Stack;

/**
 * Class: Player
 * @author MASTER
 */
public class Player {
	/*
	 * Public Data
	 */
	/** The radius of the player's bomb explosions. */
	public int explosionSize = 2;

	/** The number of bombs the player currently has available to use */
	public int bombPool = 1;

	/** Player speed, in pixels per tick (p/t) */
	public float speed;

	/** Powerup abilities */
	public boolean abilityKick, abilityThrow, abilityPunch;

	/** If the player has been killed */
	public boolean dead;

	/** The movement direction of the player */
	public int direction;

	/*
	 * Private Data
	 */
	/** The actual VISUAL position of the player. */
	private float posx, posy;

	/** The input scheme used by the player (defines keys) */
	private Config.InputScheme input;

	/** Times the frequency with which players can place bombs. */
	private final static int BOMB_DELAY = 10;
	private int bombTimer;

	/** Link to the game containing the player. */
	private PyroGame game;

	/** The powerups currently owned by the player */
	private Stack powerups;

	private TickTimer anim;
	private BufferedImage[] current;
	private BufferedImage[] up, down, left, right;
	private int frame;
	private boolean moving;

	/**
	 * Creates a new player.
	 */
	public Player(Config.PlayerInfo info, Point start, PyroGame pgame) {
		powerups = new Stack();
		dead = false;

		input = Config.get().schemes[info.input];
		game = pgame;

		posx = (start.y * 32) + 16;
		posy = (start.x * 32) + 16;

		speed = 1.8f;

		anim = new TickTimer(7);

		loadImages(info.color);
		frame = 0;
	}

	/**
	 * Loads the images for a given player color. Includes all the movement
	 * and idle sprites.
	 * @param pcolor the color of the player
	 */
	private void loadImages(int pcolor) {
		String prefix = "players/player0-";

		up = new BufferedImage[4];
		up[0] = ImagePool.getImage(prefix + "u0.png");
		up[1] = ImagePool.getImage(prefix + "u1.png");
		up[2] = ImagePool.getImage(prefix + "u0.png");
		up[3] = ImagePool.getImage(prefix + "u2.png");

		down = new BufferedImage[4];
		down[0] = ImagePool.getImage(prefix + "d0.png");
		down[1] = ImagePool.getImage(prefix + "d1.png");
		down[2] = ImagePool.getImage(prefix + "d0.png");
		down[3] = ImagePool.getImage(prefix + "d2.png");

		left = new BufferedImage[4];
		left[0] = ImagePool.getImage(prefix + "l0.png");
		left[1] = ImagePool.getImage(prefix + "l1.png");
		left[2] = ImagePool.getImage(prefix + "l0.png");
		left[3] = ImagePool.getImage(prefix + "l2.png");

		right = new BufferedImage[4];
		right[0] = ImagePool.getImage(prefix + "r0.png");
		right[1] = ImagePool.getImage(prefix + "r1.png");
		right[2] = ImagePool.getImage(prefix + "r0.png");
		right[3] = ImagePool.getImage(prefix + "r2.png");

		current = down;
	}

	/**
	 * @return the current row location of the player
	 */
	public int getRow() {
		return (int) (posy / 32);
	}

	/**
	 * @return the current column location of the player
	 */
	public int getCol() {
		return (int) (posx / 32);
	}

	/**
	 * Determines the player's current movement direction and action. Based on
	 * the keyboard state, the method determines if any keys defined in the
	 * player's input scheme are currently pressed.
	 * @param keys
	 */
	private void evaluateControls(boolean[] keys) {
		float prevx = posx, prevy = posy;

		if (keys[input.up])
			moveUp(true, speed);
		if (keys[input.down])
			moveDown(true, speed);
		if (keys[input.left])
			moveLeft(true, speed);
		if (keys[input.right])
			moveRight(true, speed);

		moving =
			(keys[input.up] || keys[input.down] || keys[input.left] || keys[input.right]);

		evaluateMovement();

		if (bombTimer >= BOMB_DELAY && keys[input.action1] && bombPool > 0) {
			game.dropBomb(this);			
			bombTimer = 0;
		}

	}

	/**
	 * Checks to see if the player has acquired a powerup while moving.
	 */
	private void evaluateMovement() {
		Object obj = game.objectOnTile(getRow(), getCol());
		if (obj == null)
			return;

		if (obj instanceof Powerup) {
			Powerup p = (Powerup)obj;
			p.grant(this);
			powerups.push(p);
		}
	}

	/** @see pyro.game.Player#moveUp()
	 */
	private void moveRight(boolean evalSlide, float speed) {
		if (speed != 1.0f) {
			direction = 2;
			current = right;
		}
			

		int ncol = (int) ((posx + speed + 16) / 32);

		int nrowU = (int) ((posy - 15) / 32);
		int nrowD = (int) ((posy + 15) / 32);

		boolean passableUp = game.isPassable(nrowU, ncol, this);
		boolean passableDown = game.isPassable(nrowD, ncol, this);

		if (passableUp && passableDown) {
			posx += speed;
			return;
		}

		if (evalSlide)
			checkVerticalSlide(passableUp, passableDown);
	}

	/** @see pyro.game.Player#moveUp()
	 */
	private void moveLeft(boolean evalSlide, float speed) {
		if (speed != 1.0f) {
			direction = 3;
			current = left;
		}

		int ncol = (int) ((posx - speed - 16) / 32);

		int nrowU = (int) ((posy - 15) / 32);
		int nrowD = (int) ((posy + 15) / 32);

		boolean passableUp = game.isPassable(nrowU, ncol, this);
		boolean passableDown = game.isPassable(nrowD, ncol, this);

		if (passableUp && passableDown) {
			posx -= speed;
			return;
		}

		if (evalSlide)
			checkVerticalSlide(passableUp, passableDown);
	}

	/**
	 * Moves the player up. If the tile above the player is empty, the player
	 * moves directly upward. If the player is below two tiles - one empty and
	 * one closed - the player slides toward the open tile at a speed of
	 * 1 pixel per tick.
	 */
	private void moveUp(boolean evalSlide, float speed) {
		if (speed != 1.0f) {
			direction = 0;
			current = up; //Set the current sprite set to use
		}

		//The new row if the player moves up by speed
		int nrow = (int) ((posy - speed - 16) / 32);
		//Checks to column the left and right of the CENTER of character image
		int ncolL = (int) ((posx - 15) / 32);
		int ncolR = (int) ((posx + 15) / 32);

		boolean passableLeft = game.isPassable(nrow, ncolL, this);
		boolean passableRight = game.isPassable(nrow, ncolR, this);

		//Directly above is empty, move straight upwards
		if (passableLeft && passableRight) {
			posy -= speed;
			return;
		}

		//If we are checking for sliding, move in the correct direction
		if (evalSlide)
			checkHorizontalSlide(passableLeft, passableRight);
	}

	/** @see pyro.game.Player#moveUp()
	 */
	private void moveDown(boolean evalSlide, float speed) {
		if (speed != 1.0f) {
			direction = 1;
			current = down;
		}

		int nrow = (int) ((posy + speed + 16) / 32);

		int ncolL = (int) ((posx - 15) / 32);
		int ncolR = (int) ((posx + 15) / 32);

		boolean passableLeft = game.isPassable(nrow, ncolL, this);
		boolean passableRight = game.isPassable(nrow, ncolR, this);

		if (passableLeft && passableRight) {
			posy += speed;
			return;
		}

		if (evalSlide)
			checkHorizontalSlide(passableLeft, passableRight);
	}

	/**
	 * Checks to see if the player can slide horizontally.  If the two tiles
	 * above the player are not the same type (i.e. both open or closed), the
	 * player slides in the direction of the open tile. Note that the sliding
	 * movement does NOT check for further sliding.
	 */
	private void checkHorizontalSlide(boolean passableLeft, boolean passableRight) {
		if (passableLeft != passableRight) {
			float spd = Math.min(speed, 1.0f);
			if (passableLeft)
				moveLeft(false, spd);
			if (passableRight)
				moveRight(false, spd);
		}
	}

	/** @see pyro.game.Player#checkHorizontalSlide()
	 */
	private void checkVerticalSlide(boolean passableUp, boolean passableDown) {
		if (passableUp != passableDown) {
			float spd = Math.min(speed, 1.0f);
			if (passableUp)
				moveUp(false, spd);
			if (passableDown)
				moveDown(false, spd);
		}
	}
	/***/

	public void step() {
		boolean[] keys = ScreenDisplay.getKeyState();
		bombTimer++; //update the bomb timer

		evaluateControls(keys);

		if (anim.timeUp()) {
			frame++;
			if (frame >= current.length)
				frame = 0;
		}
	}

	public void draw(Graphics g) {
		if (moving)
			g.drawImage(current[frame], (int)posx - 16, (int)posy - 30, null);
		else
			g.drawImage(current[0], (int)posx - 16, (int)posy - 30, null);
	}

}

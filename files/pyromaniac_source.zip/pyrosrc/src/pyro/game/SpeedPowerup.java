/*
 * Created on May 19, 2003 at 2:22:01 PM
 * Project: Pyromaniac
 */
package pyro.game;

/**
 * Class: SpeedPowerup
 * @author MASTER
 */
public class SpeedPowerup extends Powerup {

	/** Adds 0.4f to the player's speed, for a maximum of 4.0f
	 * @see pyro.game.Powerup#grant(pyro.game.Player)
	 */
	void grant(Player p) {
		if (p.speed < 4.0f)
			p.speed += 0.4;
	}

	/** Removes 0.4f from the player's speed, for a minumum of 2.0f
	 * @see pyro.game.Powerup#revoke(pyro.game.Player)
	 */
	void revoke(Player p) {
		if (p.speed > 2.0f)
			p.speed -= 0.4f;
	}

}

/*
 * Created on May 19, 2003 at 12:10:09 PM
 * Project: Pyromaniac
 */
package pyro.game;

/**
 * Class: Powerup
 * @author MASTER
 */
public abstract class Powerup {
	/**
	 * Grants the abilities of the powerup to the specified player. If the
	 * provided player is <code>null</code>, the method simply returns. Note
	 * that powerups operate on the public data of a player; no methods are
	 * called.
	 * @param p player to upgrade
	 */
	abstract void grant(Player p);
	
	/**
	 * Revokes the abilities of the powerup from the specified player. If the
	 * procided player is <code>null</code>, the method simply returns.
	 * @param p player to downgrade
	 */
	abstract void revoke(Player p);
}

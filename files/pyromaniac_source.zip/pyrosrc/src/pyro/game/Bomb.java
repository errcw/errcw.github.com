/*
 * Created on May 12, 2003 at 8:09:58 PM
 * Project: Pyromaniac
 */
package pyro.game;

import pyro.*;
import pyro.sound.*;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

/** Describes a bomb.
 * @author MASTER
 * Class: Bomb
 */
public class Bomb {
	private static boolean imagesLoaded;

	/** Expanding/contracting bomb */
	private static BufferedImage[] idle;

	/** Shadow under an idle bomb */
	private static BufferedImage shadow;

	/** Flame images, in the form flame[TYPE][FRAME], where type is:
	 * 0 - center
	 * 1 - left
	 * 2 - left ends
	 * 3 - right
	 * 4 - right ends
	 * 5 - up/down
	 * 6 - up ends
	 * 7 - down ends*/
	private static BufferedImage[][] flame;

	/** ID for explosion sound */
	private static int boom;
	private static ALSound sfxBoom;

	/**
	 * Load all the images for a bomb and its resulting explosion, and share
	 * them with all instances of Bomb.
	 */
	private static void init() {
		if (imagesLoaded)
			return;

		//boom = SoundPool.getSound(SoundPool.BOOM);
		sfxBoom = ALSoundPool.getSound("sounds/boom.wav");

		idle = new BufferedImage[3];
		for (int i = 0; i < idle.length; i++)
			idle[i] = ImagePool.getImage("bomb/bomb" + i + ".png");

		shadow = ImagePool.getImage("heads/shadow.png");

		flame = new BufferedImage[8][4];
		for (int i = 0; i < 4; i++) //center
			flame[0][i] = ImagePool.getImage("bomb/explCtr" + i + ".png");
		for (int i = 0; i < 4; i++) //left
			flame[1][i] = ImagePool.getImage("bomb/explLeft" + i + ".png");
		for (int i = 0; i < 4; i++) //left ends
			flame[2][i] = ImagePool.getImage("bomb/explLeftE" + i + ".png");
		for (int i = 0; i < 4; i++) //right
			flame[3][i] = ImagePool.getImage("bomb/explRt" + i + ".png");
		for (int i = 0; i < 4; i++) //right ends
			flame[4][i] = ImagePool.getImage("bomb/explRtE" + i + ".png");
		for (int i = 0; i < 4; i++) //up/down
			flame[5][i] = ImagePool.getImage("bomb/explUpDn" + i + ".png");
		for (int i = 0; i < 4; i++) //up ends
			flame[6][i] = ImagePool.getImage("bomb/explUpE" + i + ".png");
		for (int i = 0; i < 4; i++) //down ends
			flame[7][i] = ImagePool.getImage("bomb/explDownE" + i + ".png");

		imagesLoaded = true;
	}

	/** If the bomb is currently exploding/moving */
	public boolean exploding, moving;
	/** If the bomb has exploded */
	private boolean done;
	/** Animation and detonation timers. */
	private TickTimer detonation, anim;
	/** Current animation frame, and current animation frame vector */
	private int frame, frameDir;
	/** Location of the bomb. */
	private int row, col;

	private float posx, posy;
	private float velx, vely;

	/** The size for each "spoke" of the explosion. */
	private int usize, dsize, lsize, rsize, size;

	private Player owner;
	private Arena arena;
	private PyroGame game;

	public Bomb(Player owner, Arena arena, PyroGame game) {
		init();

		this.owner = owner;
		this.arena = arena;
		this.game = game;

		//Place the bomb at the player's position
		row = owner.getRow();
		posy = row * 32 + 16;
		col = owner.getCol();
		posx = col * 32 + 16;

		size = owner.explosionSize;

		exploding = false;

		detonation = new TickTimer(180); //three second detonation time
		anim = new TickTimer(6); //6 tick delay between frame changes

		frame = 1;
		frameDir = 1;
	}

	/**
	 * @return the current row location of the bomb
	 */
	public int getRow() {
		return (int)(posy / 32);
	}

	/**
	 * @return the current column location of the bomb
	 */
	public int getCol() {
		return (int)(posx / 32);
	}

	/**
	 * @return if the bomb has exploded, and needs to be removed from the game
	 */
	public boolean hasExploded() {
		return done;
	}

	/**
	 * Detonates the bomb at the current location following 10 game ticks.
	 */
	public void detonate() {
		detonation = new TickTimer(10);
	}

	/**
	 * Kicks the bomb in the specified direction.
	 */
	public void kick(int direction) {
		if (moving)
			return;
			
		//Pause the timers
		detonation.pause();
		anim.pause();

		moving = true;
		switch (direction) {
			case 0 :
				velx = 0.0f;
				vely = -3.0f;
				break;
			case 1 :
				velx = 0.0f;
				vely = 3.0f;
				break;
			case 2 :
				velx = 3.0f;
				vely = 0.0f;
				break;
			case 3 :
				velx = -3.0f;
				vely = 0.0f;
				break;
			default :
				break;
		}
	}

	private void moveBomb() {
		if (!moving)
			return;

		int nrow = (int) ((posy + vely) / 32);
		int ncol = (int) ((posx + velx) / 32);
		
		if (game.isPassable(nrow, ncol, this)) {
			posx += velx;
			posy += vely;
		} else {
			moving = false;
			
			row = (int)(posy / 32);
			col = (int)(posx / 32);
			
			detonation.resume();
			anim.resume();
		}
	}

	/**
	 * Detonates the bomb at its current location. Players inside the blast
	 * radius are killed, and any tiles within range are vaporised.
	 */
	private void explode() {
		exploding = true;

		owner.bombPool++; //return the bomb to the player
		
		//SoundSystem.play(boom);
		ALSoundManager.play(sfxBoom);

		//Change the animation delay
		anim = new TickTimer(4);
		//Reset the animation
		frame = 0;
		frameDir = 1;

		arena.destroyBlock(row, col);
		game.destroyTile(row, col);

		//calculate "up" size
		for (int i = 1; i <= size; i++) {
			if (arena.destroyBlock(row - i, col))
				break;
			game.destroyTile(row - i, col);
			usize = i;
		}

		//calculate "down" size
		for (int i = 1; i <= size; i++) {
			if (arena.destroyBlock(row + i, col))
				break;
			game.destroyTile(row + i, col);
			dsize = i;
		}

		//calculate "left" size
		for (int i = 1; i <= size; i++) {
			if (arena.destroyBlock(row, col - i))
				break;
			game.destroyTile(row, col - i);
			lsize = i;
		}

		//calculate "right" size
		for (int i = 1; i <= size; i++) {
			if (arena.destroyBlock(row, col + i))
				break;
			game.destroyTile(row, col + i);
			rsize = i;
		}

		//Stop the detonation countdown
		detonation.stop();
	}

	/** Prior to advancing the animation, ensures that the current frame vector
	 * (forward or backward) is valid given the current state.
	 */
	private void checkFrame() {
		if (!exploding && (frame == 0 || frame == idle.length - 1))
			frameDir *= -1;

		if (exploding && frame == flame[0].length - 1)
			frameDir *= -1;

		if (exploding && frame == 0 && frameDir == -1)
			done = true;
	}

	/**
	 * Updates the bomb for the current frame.
	 */
	public void step() {
		if (anim.timeUp()) {
			checkFrame();
			frame += frameDir;
		}

		moveBomb();

		if (detonation.timeUp())
			explode();
	}

	/**
	 * Draws the bomb given its current state. If the bomb is idle, the
	 * expanding/contracting animation is drawn. If the bomb is exploding,
	 * the fire is drawn.
	 * @param g the graphical context on which to draw the bomb.
	 */
	public void draw(Graphics g) {
		if (moving){
			g.drawImage(idle[1], (int)posx - 16, (int)posy - 16, null);
			return;
		}
		if (!exploding) {
			g.drawImage(shadow, col * 32, row * 32, null);
			g.drawImage(idle[frame], col * 32, row * 32, null);
		} else {
			g.drawImage(flame[0][frame], col * 32, row * 32, null);

			for (int i = 1; i <= rsize; i++) //RIGHT
				if (i == size)
					g.drawImage(flame[4][frame], (col + i) * 32, row * 32, null);
				else
					g.drawImage(flame[3][frame], (col + i) * 32, row * 32, null);

			for (int i = 1; i <= lsize; i++) //LEFT
				if (i == size)
					g.drawImage(flame[2][frame], (col - i) * 32, row * 32, null);
				else
					g.drawImage(flame[1][frame], (col - i) * 32, row * 32, null);

			for (int i = 1; i <= usize; i++) //UP
				if (i == size)
					g.drawImage(flame[6][frame], col * 32, (row - i) * 32, null);
				else
					g.drawImage(flame[5][frame], col * 32, (row - i) * 32, null);

			for (int i = 1; i <= dsize; i++) //DOWN
				if (i == size)
					g.drawImage(flame[7][frame], col * 32, (row + i) * 32, null);
				else
					g.drawImage(flame[5][frame], col * 32, (row + i) * 32, null);
		}
	}
} //End of Bomb class
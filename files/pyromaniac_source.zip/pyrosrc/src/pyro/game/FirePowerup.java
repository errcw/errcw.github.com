/*
 * Created on May 19, 2003 at 12:18:23 PM
 * Project: Pyromaniac
 */
package pyro.game;

/**
 * Class: FirePowerup
 * @author MASTER
 */
public class FirePowerup extends Powerup {

	/**
	 * Increases the explosion radius of the player by one if the current
	 * radius if smaller than eight.
	 * @see pyro.game.Powerup#grant(pyro.game.Player)
	 */
	void grant(Player p) {
		if (p.explosionSize < 8)
			p.explosionSize++;
	}

	/**
	 * Decreases the explosion radius of the player by one if the current
	 * radius is greater than two.
	 * @see pyro.game.Powerup#revoke(pyro.game.Player)
	 */
	void revoke(Player p) {
		if (p.explosionSize > 2)
			p.explosionSize--;
	}

}

/*
 * Created on May 18, 2003 at 1:58:22 PM
 * Project: Pyromaniac
 */
package pyro.game;

import pyro.*;
import pyro.sound.*;

import java.awt.Graphics;
import java.awt.Point;
import java.awt.image.BufferedImage;

/**
 * Class: BlockDropper
 * Drops blocks in a random pattern to fill in the arena.
 * @author MASTER
 */
public class BlockDropper {
	/** If the dropper is currently active and filling in the arena */
	private boolean active;
	/** Shadow the block dropping */
	private BufferedImage shadow;
	/** Times when the next block should drop */
	private TickTimer dropTimer;
	/** Pattern to dicate how the blocks drop */
	private DropPattern pattern;

	private ALSound sfxDrop, sfxWarn;
	private Point dropPos;

	/** Links to critical game classes */
	private Arena arena;
	private PyroGame game;

	/** Hurry related */
	private int hurryTimer;
	private TickTimer warnTimer;
	private BufferedImage hurryText;

	public BlockDropper(Arena arena, PyroGame game) {
		this.arena = arena;
		this.game = game;

		shadow = ImagePool.getImage("heads/shadow.png");
		sfxDrop = ALSoundPool.getSound("sounds/block_drop.wav");
		sfxWarn = ALSoundPool.getSound("sounds/warning.wav");
		hurryText = FontPool.getFont("red").createText("HURRY UP!");

		dropTimer = new TickTimer(20);
		warnTimer = new TickTimer(25);
		pattern = new CircularDropper();
		dropPos = new Point(1, 1);
	}

	/**
	 * Sets if the block dropper is currently active or not.
	 * @param state the new state (active or disabled)
	 */
	public void setActive(boolean state) {
		active = state;

		if (active) {
			hurryTimer = 0;
			warnTimer.reset();
		}
	}

	public void step() {
		if (!active)
			return;

		if (hurryTimer < 240) {
			if (warnTimer.timeUp())
				ALSoundManager.play(sfxWarn);
			hurryTimer++;
		}

		if (dropTimer.timeUp()) {
			//Play the dropping sound
			ALSoundManager.play(sfxDrop);

			//Fill in the tile
			game.destroyTile(dropPos.x, dropPos.y);
			arena.setTileValue(dropPos.x, dropPos.y, -3);

			//Get the next location in order to draw the shadow
			dropPos = pattern.getNextLocation();
		}

	}

	public void draw(Graphics g) {
		if (!active)
			return;

		if (hurryTimer < 240)
			g.drawImage(hurryText, 125, 200, null);

		g.drawImage(shadow, dropPos.y * 32, dropPos.x * 32, null);
	}

	private interface DropPattern {
		/**
		 * @return the next location to drop a block in the pattern
		 */
		public Point getNextLocation();
	}

	/**
	 * Drops the blocks in a circular pattern, in a clockwise direction starting
	 * in tile [1,1].
	 * @author MASTER
	 */
	private class CircularDropper implements DropPattern {
		private int row, col, rowDir, colDir;

		public CircularDropper() {
			//Start at [1,1]
			row = 1;
			col = 1;
			//Start moving across the column, but not down
			rowDir = 0;
			colDir = 1;
		}

		public Point getNextLocation() {
			Point previous = new Point(row, col);

			if (arena.getTileValue(row + rowDir, col + colDir) == -3) {
				if (rowDir == 0) {
					rowDir = (row > 4) ? -1 : 1;
					colDir = 0;
				} else if (colDir == 0) {
					colDir = (row > 4) ? -1 : 1;
					rowDir = 0;
				}
			}
			//Move the "pointer"
			row += rowDir;
			col += colDir;

			return previous;
		}

	}
}

/*
 * Created on May 19, 2003 at 2:19:43 PM
 * Project: Pyromaniac
 */
package pyro.game;

/**
 * Class: BombPowerup
 * @author MASTER
 */
public class BombPowerup extends Powerup {

	/** Adds one bomb to the player's arsenal, for a maximum of 10.
	 * @see pyro.game.Powerup#grant(pyro.game.Player)
	 */
	void grant(Player p) {
		p.bombPool++;
	}

	/** Removes one bomb from the player's arsenal, for a minimum of 1.
	 * @see pyro.game.Powerup#revoke(pyro.game.Player)
	 */
	void revoke(Player p) {
		if (p.bombPool > 1)
			p.bombPool--;
	}

}

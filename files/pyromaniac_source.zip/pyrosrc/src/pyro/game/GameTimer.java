/*
 * Created on May 18, 2003 at 1:35:54 PM
 * Project: Pyromaniac
 */
package pyro.game;

import pyro.*;
import pyro.res.Locator;

import java.awt.Graphics;
import java.awt.Font;
import java.awt.Color;
import java.awt.image.BufferedImage;

/**
 * Class: GameTimer
 * 
 * Manages time for the current match. Keeps track of the total time, as well
 * as the "Hurry Up" time. Draws a clock timer as well.
 * 
 * @author MASTER
 */
public class GameTimer {
	private BufferedImage clock;
	/** The number of ticks remaining in the game */
	private int ticks;
	/** The time when "hurry" begins */
	private int hurry;
	/** The font used to draw the remaining time */
	private Font font;

	public GameTimer() {
		clock = ImagePool.getImage("heads/clock.jpg");
		font = Tools.loadTruetypeFont(Locator.class.getResource("fonts/credits.ttf"), 40);

		ticks = Config.get().time;
		hurry = Config.get().hurry;
	}

	/**
	 * Tick down by one.
	 */
	public void step() {
		ticks--;
	}

	/**
	 * NOTE: isGameTimeUp() returns true when there are 3 seconds remaining
	 * in the game, since the gameOverTimer in PyroGame takes 2 seconds to
	 * complete.
	 * @return if the time has run out
	 */
	public boolean isGameTimeUp() {
		return ticks <= 180;
	}

	/**
	 * NOTE: isHurryTime() will only return true ONCE per game, so be sure
	 * not to miss the signal!
	 * @return if the current tick is time to start hurry.
	 */
	public boolean isHurryTime() {
		return ticks == hurry;
	}

	public void draw(Graphics g, int x, int y) {
		String time = Tools.ticksToTime(ticks);

		g.setColor(Color.WHITE);
		g.setFont(font);
		g.drawImage(clock, x, y, null);
		g.drawString(time, x + 45, y + 40);
	}
}

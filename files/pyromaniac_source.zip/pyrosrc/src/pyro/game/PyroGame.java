/*
 * Created on May 12, 2003 at 8:07:02 PM
 * Project: Pyromaniac
 */
package pyro.game;

import pyro.*;
import pyro.sound.*;

import java.awt.Graphics;
import java.awt.Color;
import java.awt.image.BufferedImage;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * @author MASTER
 * Class: PyroGame
 */
public class PyroGame extends Screen {
	/** The playing field */
	private Arena arena;
	/** The players present in the game */
	private Player[] players;
	/** The bombs in the arena */
	private ArrayList bombs;
	/** Block dropper to fill in the arena */
	private BlockDropper dropper;

	/** The background music in Ogg Vorbis format */
	private ALSound sfxMusic;
	/** Various sound effects */
	private ALSound sfxBombDrop, sfxPlayerDie, sfxEndRound;

	/** Status display showing number of wins per player */
	private BufferedImage statusDisplay;

	/** Timer for the current game, ticking down to 0:00 */
	private GameTimer timer;

	private int bodyCount;
	private TickTimer endGameTimer;
	private Color back;

	public PyroGame() {
		bombs = new ArrayList();
		back = new Color(192, 192, 192);
		sfxMusic = ALSoundPool.getSound("music/battle.ogg");
		sfxBombDrop = ALSoundPool.getSound("sounds/bomb_drop.wav");
		sfxPlayerDie = ALSoundPool.getSound("sounds/death.wav");
		sfxEndRound = ALSoundPool.getSound("sounds/round_over.wav");
	}

	/**
	 * @see pyro.Screen#initialize()
	 */
	public void initialize() {
		//Stop all currently playing sounds
		ALSoundManager.stopAll();
		//Play the background music, automatically looped (since Ogg format)
		ALSoundManager.play(sfxMusic);

		//Create the arena
		int arenaID = Config.get().arena;
		arena = new Arena(ArenaPool.getArena(arenaID));

		//Initialize the players
		Config.PlayerInfo[] info = Config.get().players;
		players = new Player[info.length];
		for (int i = 0; i < players.length; i++)
			players[i] = new Player(info[i], arena.getPlayerStartPosition(i), this);

		//Clear all of the bombs
		bombs.clear();

		//Reset the body count
		bodyCount = 0;

		//Reset the end game timer
		endGameTimer = null;

		//Create the status display
		statusDisplay = Tools.createStatusDisplay();

		//Create the timer
		timer = new GameTimer();

		//Create new block dropper
		dropper = new BlockDropper(arena, this);
	}

	/**
	 * Places a bomb at the specified row and column.
	 * @param placer the owner of the dropped bomb
	 * @param row the row position of the bomb
	 * @param col the column position of the bomb
	 */
	public void dropBomb(Player placer) {
		//Make sure the tile is empty before placing a bomb
		if (isPassable(placer.getRow(), placer.getCol())) {
			ALSoundManager.play(sfxBombDrop);
			placer.bombPool--;
			bombs.add(new Bomb(placer, arena, this));
		}
	}

	/**
	 * @return the object on the tile - bomb, powerup, whatever...
	 */
	public Object objectOnTile(int row, int col) {
		Powerup pow = arena.walkOverTile(row, col);
		Bomb bomb = bombOnTile(row, col);

		if (pow == null)
			if (bomb == null || (bomb != null && bomb.moving))
				return null;
			else
				return bomb;
		else
			return pow;
		//get player as well - to punch and stun
	}

	/**
	 * @return if the specified tile is passable
	 */
	public boolean isPassable(int row, int col, Bomb bomb) {
		//Check if the arena blocks the movement:
		if (!arena.isPassable(row, col))
			return false;

		Bomb b = bombOnTile(row, col);
		//If the bomb is blocking the specified tile, and the bomb
		//is not itself, the tile is NOT passable
		if (b != null && !b.equals(bomb))
			return false;

		for (int i = 0; i < players.length; i++)
			if (players[i].getRow() == row && players[i].getCol() == col)
				return false;

		return true;
	}

	/**
	 * @return if the specified tile is passable
	 */
	public boolean isPassable(int row, int col, Player p) {

		//Check if the arena blocks the movement:
		if (!arena.isPassable(row, col))
			return false;

		Bomb b = bombOnTile(row, col);
		//If the bomb is blocking the specified tile, and the player
		//is not already on top of the tile, the tile is NOT passable
		if (b != null && (b.getRow() != p.getRow() || b.getCol() != p.getCol())) {
			if (p.abilityKick)
				b.kick(p.direction);

			return false;
		}

		return true;
	}

	/**
	 * @return if the specified tile is passable
	 */
	public boolean isPassable(int row, int col) {
		if (!arena.isPassable(row, col))
			return false;
		if (bombOnTile(row, col) != null)
			return false;
		return true;
	}

	/**
	 * @return the bomb on the specified tile, or null for none
	 */
	private Bomb bombOnTile(int row, int col) {
		for (Iterator i = bombs.iterator(); i.hasNext();) {
			Bomb bomb = (Bomb)i.next();
			if (bomb.getRow() == row && bomb.getCol() == col)
				return bomb;
		}

		return null;
	}

	/**
	 * Kills any players present on the given tile, and detonates any bombs
	 * present.
	 */
	public void destroyTile(int row, int col) {
		for (int i = 0; i < players.length; i++)
			if (players[i].getRow() == row
				&& players[i].getCol() == col
				&& !players[i].dead) {
				players[i].dead = true;
				ALSoundManager.play(sfxPlayerDie);
				bodyCount++;
			}

		for (Iterator i = bombs.iterator(); i.hasNext();) {
			Bomb bomb = (Bomb)i.next();
			if (bomb.getRow() == row && bomb.getCol() == col && !bomb.exploding)
				bomb.detonate();
		}
	}

	private void checkForWinner() {
		if (endGameTimer != null && endGameTimer.timeUp())
			ScreenDisplay.setScreen(ScreenPool.getScreen("RoundWin"));

		if ((bodyCount >= (players.length - 1) || timer.isGameTimeUp())
			&& endGameTimer == null) {

			//Stop the dropper
			dropper.setActive(false);
			
			//Erase the last winner
			Config.get().lastWinner = -1;

			boolean winner = false;
			if (!timer.isGameTimeUp())
				for (int i = 0; i < players.length; i++)
					if (!players[i].dead) {
						Config.get().players[i].wins++;
						Config.get().lastWinner = i;
						winner = true;
						break;
					}
			//If there is no clear winner, increment the ties by one
			if (!winner)
				Config.get().ties++;

			endGameTimer = new TickTimer(180);
			ALSoundManager.play(sfxEndRound);
		}
	}

	/**
	 * @see pyro.Screen#step()
	 */
	public void step() {
		//Update the arena
		arena.step();

		//Update all the players who are not dead
		for (int i = 0; i < players.length; i++)
			if (!players[i].dead)
				players[i].step();

		//Update all the bombs, removing any exploded ones
		for (Iterator i = bombs.iterator(); i.hasNext();) {
			Bomb b = (Bomb)i.next();
			b.step();

			if (b.hasExploded())
				i.remove();
		}
		//Update the dropper
		dropper.step();

		//On hurry up, activate the block dropper
		if (timer.isHurryTime())
			dropper.setActive(true);

		//Update the timer
		timer.step();

		//Check for any winners
		checkForWinner();
	}

	/**
	 * @see pyro.Screen#draw(java.awt.Graphics)
	 */
	public void draw(Graphics g) {
		//Draw in the background
		g.setColor(back);
		g.fillRect(0, 0, 450, 450);

		//Draw the status display
		g.drawImage(statusDisplay, 150, 20, null);

		timer.draw(g, 10, 10);

		//Move the origin to draw the Arena
		g.translate(15, 75);

		//Draw the arena
		arena.draw(g);

		//Draw all of the bombs
		for (Iterator i = bombs.iterator(); i.hasNext();)
			 ((Bomb)i.next()).draw(g);

		//Draw all of the players
		for (int i = 0; i < players.length; i++)
			if (!players[i].dead)
				players[i].draw(g);

		//Last, draw the dropper
		dropper.draw(g);
	}
}

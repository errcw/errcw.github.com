/*
 * Created on May 12, 2003 at 8:09:37 PM
 * Project: Pyromaniac
 */
package pyro.game;

import pyro.*;
import pyro.sound.*;

import java.awt.Graphics;
import java.awt.Point;
import java.awt.image.BufferedImage;

import java.util.Iterator;
import java.util.Random;
import java.util.ArrayList;

/**
 * @author MASTER
 * Class: Arena
 */
public class Arena {
	/** The array describing the arena. Negative numbers represent unpassable
	 * tiles, while positive numbers are open. */
	private int[][] grid;

	/** The array describing any powerups present in the level. */
	private int[][] powerups;

	/** Array listing the possible powerup types */
	private Powerup[] powerTypes =
		{
			new FirePowerup(),
			new BombPowerup(),
			new SpeedPowerup(),
			new KickBombPowerup()};

	/** The start positions of each player, in grid space (i.e. row/column). */
	private Point[] startPositions;

	/** Images of the arena tiles. */
	private BufferedImage edge, indestructible, destructible, empty;

	/** Images of a block/powerup being vaporised. */
	private BufferedImage[] tdestruction, pdestruction;

	/** Powerup images */
	private BufferedImage[] back, powerupImg;

	/** Variable sized array of all the explosions currently displayed. */
	private ArrayList explosions;

	/** Sound effects for powerups */
	private ALSound sfxPickup;

	private TickTimer frameTimer;
	private int pwrFrame;

	/**
	 * Creates a new Arena and populates it with powerups.
	 * @param data the array describing the arena
	 */
	public Arena(int[][] data) {
		grid = data;
		startPositions = new Point[Config.get().MAX_PLAYERS];
		powerups = new int[11][13];

		//Load the grid.
		int player = 0;
		Random rand = new Random();
		for (int i = 0; i < grid.length; i++)
			for (int j = 0; j < grid[i].length; j++) {
				player = 0;
				powerups[i][j] = -1;
				switch (grid[i][j]) {
					case -1 :
						//15% random chance that a destructible block is removed
						if (rand.nextDouble() < 0.15d)
							grid[i][j] = 0;
						//60% chance of adding a powerup to the block
						else if (rand.nextDouble() < 0.6d)
							powerups[i][j] = Math.abs(rand.nextInt()) % powerTypes.length;

						break;
					case 2 :
						player++;
					case 3 :
						player++;
					case 4 :
						player++;
					case 5 :
						player++;
						startPositions[4 - player] = new Point(i, j);
						//Clear the position
						grid[i][j] = 0;
						break;
					default :
						break;
				}
			}
		//End loading grid.

		explosions = new ArrayList();

		//Load the images
		edge = ImagePool.getImage("tiles/edge.jpg");
		indestructible = ImagePool.getImage("tiles/firmblock.jpg");
		destructible = ImagePool.getImage("tiles/block.jpg");
		empty = ImagePool.getImage("tiles/empty.jpg");

		tdestruction = new BufferedImage[5];
		for (int i = 0; i < tdestruction.length; i++)
			tdestruction[i] = ImagePool.getImage("tiles/explode" + i + ".jpg");

		pdestruction = new BufferedImage[7];
		for (int i = 0; i < pdestruction.length; i++)
			pdestruction[i] = ImagePool.getImage("powerups/explosion" + i + ".png");

		frameTimer = new TickTimer(6);
		pwrFrame = 0;

		back = new BufferedImage[2];
		for (int i = 0; i < back.length; i++)
			back[i] = ImagePool.getImage("powerups/frame" + i + ".png");

		powerupImg = new BufferedImage[4];
		powerupImg[0] = ImagePool.getImage("powerups/flame.png");
		powerupImg[1] = ImagePool.getImage("powerups/bomb.png");
		powerupImg[2] = ImagePool.getImage("powerups/speed.png");
		powerupImg[3] = ImagePool.getImage("powerups/kick.png");

		sfxPickup = ALSoundPool.getSound("sounds/pickup.wav");
	}

	/**
	 * @return the initial position (row and column) of the specified player. 
	 * @throws ArrayIndexOutOfBoundsException if the player ID is invalid
	 */
	public Point getPlayerStartPosition(int player)
		throws ArrayIndexOutOfBoundsException {
		if (player < 0 || player > startPositions.length)
			throw new ArrayIndexOutOfBoundsException("No such player.");

		return startPositions[player];
	}

	/**
	 * @return if the given tile is passable (i.e. empty)
	 */
	public boolean isPassable(int row, int column) {
		return grid[row][column] >= 0;
	}

	/**
	 * Destroys the block at the given position. If the tile is empty or
	 * indestructible, nothing occurs. If the tile contains a powerup, the
	 * powerup is destroyed. If anything is present to stop the flame, the
	 * method returns true.
	 * @param row the row position of the tile to destroy
	 * @param col the column position of the tile to destroy
	 */
	public boolean destroyBlock(int row, int col) {
		//If the block is destructible, destroy it
		if (grid[row][col] == -1)
			explosions.add(new TileExplosion(row, col));
		else if (powerups[row][col] >= 0)
			explosions.add(new PowerupExplosion(row, col));

		return grid[row][col] < 0 || powerups[row][col] >= 0;
	}

	/**
	 * @return any powerup present on the tile, or null for none
	 */
	public Powerup walkOverTile(int row, int col) {
		if (row < 0 || col < 0 || row >= 11 || col >= 13)
			return null;

		int type = powerups[row][col];

		if (type == -1)
			return null;
		else {
			ALSoundManager.play(sfxPickup);
			powerups[row][col] = -1;
			return powerTypes[type];
		}
	}
	
	/**
	 * Sets the specified tile to be a different type.
	 */
	public void setTileValue(int row, int col, int value){
		grid[row][col] = value;
	}
	
	/**
	 * @return the value of the tile at the specified location
	 */
	public int getTileValue(int row, int col){
		return grid[row][col];
	}

	/**
	 * Updates all the visual effects for the current frame.
	 */
	public void step() {
		//Flash the powerups
		if (frameTimer.timeUp())
			pwrFrame = 1 - pwrFrame;

		for (Iterator i = explosions.iterator(); i.hasNext();) {
			Explosion expl = (Explosion)i.next();
			expl.step();
			//Remove the explosion when it has run its course
			if (expl.isComplete())
				i.remove();
		}
	}

	/**
	 * Draws the arena to the specified graphical context. The method also draws
	 * any explosion effects currently present, and powerups.
	 */
	public void draw(Graphics g) {
		for (int i = 0; i < grid.length; i++)
			for (int j = 0; j < grid[i].length; j++)
				switch (grid[i][j]) {
					case -3 :
						g.drawImage(edge, j * 32, i * 32, null);
						break;
					case -2 :
						g.drawImage(indestructible, j * 32, i * 32, null);
						break;
					case -1 :
						g.drawImage(destructible, j * 32, i * 32, null);
						break;
					case 0 :
						g.drawImage(empty, j * 32, i * 32, null);
						if (powerups[i][j] >= 0) {
							g.drawImage(back[pwrFrame], j * 32, i * 32, null);
							g.drawImage(powerupImg[powerups[i][j]], j * 32, i * 32, null);
						}
						break;
				}

		for (Iterator iter = explosions.iterator(); iter.hasNext();)
			 ((Explosion)iter.next()).draw(g);
	}

	//--------------------------//
	//--------------------------//

	/**
	 * Interface describing an explosion of some form.
	 * @see pyro.game.Arena.TileExplosion
	 * @see pyro.game.Arena.PowerupExplosion
	 */
	private interface Explosion {
		public boolean isComplete();
		public void step();
		public void draw(Graphics g);
	}

	/**
	 * Explosion type of a tile. Shows a destruction animation, and when completely
	 * vaporised the tile is removed from the grid.
	 */
	private class TileExplosion implements Explosion {
		private TickTimer animTimer;
		private int animFrame;
		private int row, col;

		public TileExplosion(int row, int col) {
			this.row = row;
			this.col = col;
			animFrame = 0;
			animTimer = new TickTimer(7);
		}

		public boolean isComplete() {
			return animFrame >= tdestruction.length;
		}

		public void step() {
			if (animTimer.timeUp()) {
				animFrame++;
				if (isComplete())
					grid[row][col] = 0;
			}
		}

		public void draw(Graphics g) {
			g.drawImage(tdestruction[animFrame], col * 32, row * 32, null);
		}
	}

	/**
	 * Explosion of a Powerup. Shows the destruction animation, and removes
	 * the powerup from the grid.
	 * @author MASTER
	 */
	private class PowerupExplosion implements Explosion {
		private TickTimer animTimer;
		private int animFrame;
		private int row, col;

		public PowerupExplosion(int row, int col) {
			this.row = row;
			this.col = col;
			animFrame = 0;
			animTimer = new TickTimer(5);
		}

		public boolean isComplete() {
			return animFrame >= pdestruction.length;
		}

		public void step() {
			if (animTimer.timeUp()) {
				animFrame++;
				if (isComplete())
					powerups[row][col] = -1;
			}
		}

		public void draw(Graphics g) {
			g.drawImage(pdestruction[animFrame], col * 32 - 25, row * 32 - 40, null);
		}
	}
}

/*
 * Created on May 19, 2003 at 2:23:54 PM
 * Project: Pyromaniac
 */
package pyro.game;

/**
 * Class: KickBombPowerup
 * @author MASTER
 */
public class KickBombPowerup extends Powerup {

	/** Grants the ability to kick bombs.
	 * @see pyro.game.Powerup#grant(pyro.game.Player)
	 */
	void grant(Player p) {
		p.abilityKick = true;
	}

	/** Removes the ability to kick bombs.
	 * @see pyro.game.Powerup#revoke(pyro.game.Player)
	 */
	void revoke(Player p) {
		p.abilityKick = false;
	}

}

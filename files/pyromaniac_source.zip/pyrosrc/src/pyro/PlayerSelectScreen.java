/*
 * Created on May 4, 2003 at 1:10:30 PM
 * Project: Pyromaniac
 */
package pyro;

import pyro.gui.*;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

public class PlayerSelectScreen extends AbstractMenuScreen {
	private BufferedImage title;
	private CyclableMenu menu;

	/** Creates a new instance of PlayerSelectScreen */
	public PlayerSelectScreen() throws Exception {
		super();

		BufferedImage[] heads = new BufferedImage[4];
		for (int i = 0; i < heads.length; i++)
			heads[i] = ImagePool.getImage("heads/bomber" + i + ".png");

		SpriteFont wfont = FontPool.getFont("white");
		SpriteFont rfont = FontPool.getFont("red");
		SpriteFont yfont = FontPool.getFont("yellow");
		title = wfont.createText("BOMBER TYPE");

		BufferedImage label = wfont.createText("BOMBER");
		BufferedImage[] items = { rfont.createText("MAN"), yfont.createText("OFF")};

		IconCyclableMenuItem[] itms = new IconCyclableMenuItem[4];
		for (int i = 0; i < itms.length; i++)
			itms[i] = new IconCyclableMenuItem(heads[i], label, items, 150);

		menu = new CyclableMenu(itms, 50);
		menu.setTypeChecking(true, 0, 2);
	}

	public void initialize() {
		super.initialize();
	}

	public void step() {
		super.step();
		boolean[] keys = ScreenDisplay.getKeyState();

		menu.step(keys);
		if (menu.enterPressed()) {
			int[] colors = new int[4];
			int numPlayers = 0, cnt = 0;

			//count the number of active players
			for (int i = 0; i < Config.get().MAX_PLAYERS; i++)
				if (menu.getItemAt(i).getSelectedIndex() == 0) {
					colors[cnt++] = i;
					numPlayers++;
				}

			//if there are at least two players, play can continue
			if (numPlayers >= 2) {
				Config.get().players = new Config.PlayerInfo[numPlayers];
				for (int i = 0; i < Config.get().players.length; i++) {
					Config.get().players[i] = Config.get().new PlayerInfo();
					Config.get().players[i].color = colors[i];
				}
				ScreenDisplay.setScreen(ScreenPool.getScreen("ControlSelect"));
			}
		}
	}

	public void draw(Graphics g) {
		super.draw(g);

		g.drawImage(title, 137, 60, null);
		menu.draw(g, 75, 110);
	}
}

/*
 * ScreenPool.java
 *
 * Created on April 12, 2003, 12:17 PM
 */

package pyro;

import java.util.HashMap;

/** Class pooling all of the screens into a single location.  Calling init() on
 * the ScreenPool loads all of the resources required for the screens.
 */
public class ScreenPool {
	private static HashMap pool;

	/** Load all the screens and their associated resources.
	 */
	public static void init() throws Exception {
		pool = new HashMap(5);
		
		pool.put("Title", new TitleScreen());
		pool.put("Quit", new QuitScreen());
		pool.put("Credits", new CreditScreen());
		pool.put("KeyConfig", new KeyConfigScreen());
		
		pool.put("PlayerSelect", new PlayerSelectScreen());
		pool.put("ControlSelect", new ControlSelectScreen());
		pool.put("MatchSetup", new MatchSetupScreen());
		pool.put("ArenaSelect", new ArenaSelectScreen());
		pool.put("RoundWin", new RoundWinScreen());
		
		pool.put("Game", new pyro.game.PyroGame());
	}

	/** Gets a screen from the pool with the selected ID. IDs are defined in Screen
	 * Pool as static constants. If the ID number is invalid, null is returned.
	 * @param id the identifier of the screen to return
	 * @return the requested screen
	 */
	public static Screen getScreen(String id) {
		return (Screen)pool.get(id);
	}
}

/*
 * CreditScreen.java
 *
 * Created on April 18, 2003, 8:05 PM
 */

package pyro;

import pyro.res.Locator;
//import pyro.sound.*;

import java.awt.*;
import java.awt.image.BufferedImage;

import java.io.*;
import java.util.*;

/** Screen to display scrolling credits.
 */
public class CreditScreen extends Screen {
	/** The number of ticks before a new line is added */
	private static final int CREDIT_TICK_DELAY = 30;
	/** The point at which a credit appears */
	private static final int CREDIT_START_LINE = 375;
	/** The point at which a credit disappears */
	private static final int CREDIT_STOP_LINE = 135;

	/** Images for the border */
	private BufferedImage top, bottom, side;
	/** Dynamic array holding the currently displayed credits */
	private ArrayList lines;
	/** Reads the credits text file */
	private BufferedReader reader;
	/** Times adding lines to the scroller */
	private TickTimer timer;
	/** Font used to display the credits */
	private Font font;
	/** ID of background music */
	private int music;

	/** Creates a new instance of CreditScreen */
	public CreditScreen() throws Exception {
		lines = new ArrayList();
		timer = new TickTimer(CREDIT_TICK_DELAY);

		top = ImagePool.getImage("credits/credit_top.jpg");
		bottom = ImagePool.getImage("credits/credit_bottom.jpg");
		side = ImagePool.getImage("credits/credit_side.jpg");

		//music = SoundPool.getSound(SoundPool.CREDIT_MUSIC);

		font = Tools.loadTruetypeFont(Locator.class.getResource("fonts/credits.ttf"), 20);
	}

	/** Initializes the credits.  Resets all variables and opens the credits
	 * text file for reading.
	 */
	public void initialize() {
		lines.clear();
		timer.reset();

		//MusicSystem.play(music);
		//MusicSystem.setVolume(0.6d);		

		InputStream cin = Locator.class.getResourceAsStream("credits/credits.txt");
		reader = new BufferedReader(new InputStreamReader(cin));

		addLine();
	}

	/** Adds a line to the currently displayed credits.
	 */
	private void addLine() {
		try {
			String line = reader.readLine();
			if (line != null)
				lines.add(new CreditLine(line));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/** Updates the credits for this frame.
	 */
	public void step() {
		if (timer.timeUp()) //time to add a new line
			addLine();

		if (lines.size() == 0) //the credits are over
			ScreenDisplay.setScreen(ScreenPool.getScreen("Title"));

		for (int i = 0; i < lines.size(); i++) {
			CreditLine line = (CreditLine)lines.get(i);
			line.step();

			if (line.ypos < CREDIT_STOP_LINE)
				lines.remove(i);
		}
	}

	public void draw(Graphics g) {
		//draw the border
		g.drawImage(top, 0, 0, null);
		g.drawImage(side, 0, 64, null);
		g.drawImage(side, 446, 64, null);
		g.drawImage(bottom, 0, 386, null);

		for (int i = 0; i < lines.size(); i++)
			 ((CreditLine)lines.get(i)).draw(g);
	}

	/** Class describing one line of the credits.
	 */
	private class CreditLine {
		/** The text of the line */
		private final String line;
		/** The y position of the line */
		public int ypos;
		/** The direction of the color transition (white <-> black) */
		private int colorDir;
		/** The current color */
		private Color color;

		/** Creates a new instance of CreditLine
		 * @param line the immutable text of the line
		 */
		protected CreditLine(String line) {
			this.line = line;

			ypos = CREDIT_START_LINE;
			color = Color.BLACK;
			colorDir = 2;
		}

		/** Changes the Red, Green, and Blue values of a color the given amount.
		 * @param orig the color to change
		 * @param amt the amount to change RGB
		 * @return the new color
		 */
		private Color incrementColor(Color orig, int amt) {
			Color newcol =
				new Color(
					orig.getRed() + amt,
					orig.getGreen() + amt,
					orig.getBlue() + amt);

			return newcol;
		}

		/** Updates the line for the frame.
		 */
		protected void step() {
			ypos--;

			if (color.getRed() >= 253)
				colorDir = -2;

			color = incrementColor(color, colorDir);
		}

		/** Draws the line to the given graphical context.
		 */
		protected void draw(Graphics g) {
			g.setColor(color);
			g.setFont(font);
			g.drawString(line, 100, ypos);
		}
	}
}

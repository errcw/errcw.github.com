/*
 * LoadingScreen.java
 *
 * Created on April 6, 2003, 9:20 PM
 */

package pyro;

import pyro.res.Locator;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

public class LoadingScreen extends Screen {
	/** The number of ticks before the bomb spinning changes sizes */
	private static final int ANIM_DURATION = 12;

	private LoaderThread loader;
	private BufferedImage[] bombs;
	private BufferedImage block, loadbar;
	private int progress, frame, dir;
	private TickTimer timer;

	/** Creates a new instance of LoadingScreen */
	public LoadingScreen() throws Exception {
		bombs = new BufferedImage[3];
		timer = new TickTimer(ANIM_DURATION);

		for (int i = 0; i < bombs.length; i++)
			bombs[i] =
				Tools.loadImage(
					Locator.class.getResource("loadscreen/fbomb" + i + ".jpg"));
		block = Tools.loadImage(Locator.class.getResource("loadscreen/block.jpg"));
		loadbar = Tools.loadImage(Locator.class.getResource("loadscreen/load.jpg"));
	}

	public void initialize() {
		frame = dir = 1;
		timer.reset();

		loader = new LoaderThread();
		loader.start();
	}

	public void step() {
		if (timer.timeUp()) {
			if (frame == 0 || frame == 2)
				dir *= -1; //go in the opposite direction

			frame += dir;
		}

		progress = loader.getProgress();
		if (loader.isFinished())
			ScreenDisplay.setScreen(ScreenPool.getScreen("Title"));
	}

	public void draw(Graphics g) {
		//the third frame is oddly sized, and must be repositioned
		g.drawImage(bombs[frame], (frame == 2) ? 25 : 65, 25, null);
		g.drawImage(loadbar, 25, 385, null);
		for (int i = 0; i < progress; i++)
			g.drawImage(block, 35 + (i * 39), 437, null);
	}

	/** Extension of Thread to load game resources in the background while
	 * the loading animation continues uninterrupted.
	 */
	class LoaderThread extends Thread {
		private int progress = 0;
		private boolean done = false;

		/** Has the loader loaded all the resources (graphics, sound, maps)
		 * required by the game?
		 * @return whether the process is finished
		 */
		public boolean isFinished() {
			return done;
		}

		/** Returns the amount of loading work already completed.  The value will
		 * lie between 0 (no work) and 9 (all work completed).
		 * @return the amount of work done
		 */
		public int getProgress() {
			return progress;
		}

		public void run() {
			try {
				ArenaPool.init();
				FontPool.init();
				progress += 1;

				//SoundPool.init();
				ALSoundPool.init();
				progress += 2;

				ImagePool.init();
				progress += 5;
				
				ScreenPool.init();
				progress += 1;

				Thread.sleep(100);
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				done = true;
			}
		}
	}
}

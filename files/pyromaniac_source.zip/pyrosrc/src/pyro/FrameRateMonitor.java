/*
 * FrameRateMonitor.java
 *
 * Created on March 29, 2003, 5:56 PM
 */

package pyro;

import org.lwjgl.Sys;

public class FrameRateMonitor {
    private static int frames;
    private static long startTime;
    private static long preferredTicksPerFrame;
    private static long frameStartTick;
    private static long frameDurationTicks;
    
    /** Do not allow construction */
    private FrameRateMonitor() {}

    /** Set preferred frame rate.  The class will make every attempt to maintain the
     * given frame rate.
     * @param fps the desired frame rate
     */    
    public static void setFrameRate(int fps){
        preferredTicksPerFrame = Sys.getTimerResolution() / fps;
    }
    
    /** Reset the frames per second counter */    
    public static void start(){
        startTime = Sys.getTime();
        frames = 0;
    }
    
    /** Begin monitoring the current frame.  This method should be called every frame
     * before update and drawing code.
     */    
    public static void startFrame() { frameStartTick = Sys.getTime(); }
    
    /** Ends the current frame.  Pads any excess time in the frame by sleep()-ing the
     * thread in order to maintain the desired frame rate.  No attempt is made to
     * rectify frames which have taken too much time.
     */
    public static void endFrame() {
        frames++;
        
        frameDurationTicks = Sys.getTime() - frameStartTick;
        
        while (frameDurationTicks < preferredTicksPerFrame){
            long sleepTime =  ((preferredTicksPerFrame - frameDurationTicks) * 1000) / Sys.getTimerResolution();
            
            try {
                Thread.sleep(sleepTime);
            } catch (InterruptedException e){ }
            
            frameDurationTicks = Sys.getTime() - frameStartTick;
        }
    }
    
    /** Returns the number of frames passed since getFramesPerSecond() was last called.
     * @return the number of frames
     */    
    public static int getFrames() { return frames; }
    
    /** Gets the current frame rate.
     * @return the current FPS
     */    
    public static float getFramesPerSecond() {
        float time =  (Sys.getTime() - startTime) / (float)Sys.getTimerResolution();
        float fps  = frames / time;
        start();
        return fps;
    }
}

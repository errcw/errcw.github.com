/*
 * TickTimer.java
 *
 * Created on April 19, 2003, 7:51 PM
 */

package pyro;

/** Timer class to sound the alarm after a certain time has passed.
 */
public class TickTimer {
	//Globally keeps track of time for all instances of TickTimer
	private static int ticks;
	//The number of ticks to wait before the time is up
	private int alarmTick;
	//When the timer was started
	private int startTick;
	//Ticks elapsed when the timer was paused
	private int ticksElapsed;
	//If the timer is paused
	private boolean paused;

	/** Creates a new instance of TickTimer
	 * @param tickToAlarm the number of ticks before timeUp() returns true
	 */
	public TickTimer(int tickToAlarm) {
		alarmTick = tickToAlarm;
		reset();
	}

	/** Determines if the specified number of ticks, or more, has passed.  If so,
	 * the timer is reset.
	 */
	public boolean timeUp() {
		if (!paused && (ticks - startTick) >= alarmTick) {
			reset();
			return true;
		}
		return false;
	}

	/** Stops the timer. Any further calls to timeUp() will return false, even
	 * if reset is called.
	 */
	public void stop() {
		alarmTick = Integer.MAX_VALUE;
	}

	/** Resets the timer. The number of ticks until the alarm is sounded starts
	 * counting from this point on.
	 */
	public void reset() {
		startTick = ticks;
	}

	/**
	 * Pauses the timer. <code>timeUp()</code> will not return true until
	 * resume is called, and the allotted amount of time has passed.
	 */
	public void pause() {
		ticksElapsed = (ticks - startTick);
		paused = true;
	}

	/**
	 * Resumes the timer.
	 * @see pyro.TickTimer#pause()
	 */
	public void resume() {
		startTick = ticks - ticksElapsed;
		paused = false;
	}

	/** Resets ALL of the timers.
	 */
	public static void timerGlobalReset() {
		ticks = 0;
	}

	/** Updates all of the timers. This method should be called once evevry frame
	 * to update all the timers at once.
	 */
	public static void step() {
		ticks++;
	}
}

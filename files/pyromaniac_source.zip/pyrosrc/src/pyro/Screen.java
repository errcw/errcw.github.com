/*
 * Screen.java
 *
 * Created on April 4, 2003, 5:23 PM
 */

package pyro;

import java.awt.Graphics;

/** Base class describing an object which can be shown on a ScreenDisplay.  Updating
 * the game environment and rendering is controlled via Screens.
 */
public abstract class Screen {    
    /** Initializes the Screen. Called every time the Screen is loaded into the
     * ScreenDisplay.  As this method is called with relative frequency, image
     * loading code should NOT appear in initialization, rather in the constructor.
     */
    public abstract void initialize();
    
    /** Updates the Screen for the current frame. */
    public abstract void step();
    
    /** Draws the screen to a graphical context.
     * @param g the graphical context on which to draw
     */    
    public abstract void draw(Graphics g);
}

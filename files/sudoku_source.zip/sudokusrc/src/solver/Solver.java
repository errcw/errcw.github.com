package solver;

import java.util.Arrays;
import java.util.Stack;

/**
 * Solves Sudoku puzzles. Accepts an unfilled grid as input and returns the
 * completed puzzle.
 * 
 * @author Eric Woroshow
 * @version 2005-10-29
 */
public class Solver {

    /** Representation of the grid */
    private int[] grid = new int[81];
    
    /** Number availibility */
    private boolean[][] avail = new boolean[81][10];
    private Stack<boolean[][]> stack = new Stack<boolean[][]> ();
    
    /** If we have solved it */
    private boolean solved = false;
    
    public Solver() {}
    
    /**
     * @param initial an unfilled Sudoku grid
     * @return a solved version of the initial grid
     */
    public int[] solve(int[] initial) {
        solved = false;
        
        System.arraycopy(initial, 0, grid, 0, initial.length);
        for (int i = 0; i < avail.length; i++) {
            Arrays.fill(avail[i], true);
            avail[i][0] = false;
        }
        
        solveImpl();
        
        return grid;
    }
    
    /**
     * Solves the Sudoku puzzle in the grid, recursively.
     */
    private void solveImpl() {
        for (int i = 0; i < grid.length; i++) {
            // if this grid element has a value, keep looking for an empty one
            if (grid[i] != 0) continue;
            
            // determine all the possible acceptable values in this grid location
            for (int j = 0; j < grid.length; j++)
                if (isSameRowColGrid(i, j))
                    avail[i][grid[j]] = false;
            
            // for all the possible values, try it and recurse
            for (int j = 1; j <= 9; j++)
                if (avail[i][j]) {
                    grid[i] = j;
                    
                    // store the current availability state, and restore to undo the guess
                    stack.push(copyAvailArray());
                    solveImpl();
                    avail = stack.pop();
                    
                    // if we have solved it, immediately break out
                    if (solved) return;
                }
            
            // no possibility yielded a solution; undo the guess and return
            grid[i] = 0;
            return;
        }
        
        // if we have reached this point, all grid elements have a valid number
        solved = true;
    }
    
    /**
     * @return a copy of the availability array
     */
    private boolean[][] copyAvailArray() {
        boolean[][] dest = new boolean[81][10];
        for (int i = 0; i < dest.length; i++)
            for (int j = 0; j < 10; j++)
                dest[i][j] = avail[i][j];
        
        return dest;
    }
    
    /**
     * @return if test is in the same row, column, or grid as base
     */
    private boolean isSameRowColGrid(int base, int test) {
        return base / 9 == test / 9 // same row 
            || base % 9 == test % 9 // same column
            || (base / 27 == test / 27 && base % 9 / 3 == test % 9 / 3); // same grid
    }
}

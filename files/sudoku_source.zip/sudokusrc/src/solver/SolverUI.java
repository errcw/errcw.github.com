package solver;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.PlainDocument;

public class SolverUI extends JFrame {
    
    /**
     * Entry point.
     * @param args command line arguments; unused
     */
    public static void main(String[] args) {
        new SolverUI();
    }
    
    /** Common UI font */
    private static final Font FONT = new Font("Verdana", Font.BOLD, 10);
    
    /** Sudoku grid */
    private static final JTextField[] FIELDS = new JTextField[81];
    private static int[] GRID = new int [81];
    
    /** Solver underlying the GUI */
    private Solver solver = new Solver();
    
    public SolverUI() {
        super();
        
        setTitle("Sudoku Solver");
        setContentPane(getUIContent());
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        pack();
        
        setVisible(true);
    }
    
    private Container getUIContent() {
        JPanel root = new JPanel(new BorderLayout());
        root.add(getControls(), BorderLayout.NORTH);
        root.add(getSudokuGrid(), BorderLayout.CENTER);
        return root;
    }
    
    private JComponent getControls() {
        JToolBar bar = new JToolBar();
        bar.setFloatable(false);
        bar.setRollover(true);
        
        JButton solve = new JButton(new ImageIcon(getClass().getResource("/solver/icons/solve.gif")));
        solve.setToolTipText("Solve");
        solve.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        solve.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                GRID = solver.solve(GRID);
                for (int i = 0; i < FIELDS.length; i++)
                    FIELDS[i].setText(GRID[i] + "");
            }
        });
        
        JButton reset = new JButton(new ImageIcon(getClass().getResource("/solver/icons/reset.gif")));
        reset.setToolTipText("Reset");
        reset.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        reset.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                for (int i = 0; i < FIELDS.length; i++) {
                    GRID[i] = 0;
                    FIELDS[i].setText(" ");
                }
            }
        });
        
        JButton quit = new JButton(new ImageIcon(getClass().getResource("/solver/icons/quit.gif")));
        quit.setToolTipText("Quit");
        quit.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        quit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        
        bar.add(solve);
        bar.add(reset);
        bar.add(quit);
        
        return bar;
    }
    
    private JComponent getSudokuGrid() {
        JPanel panel = new JPanel(new GridLayout(3, 3, 5, 5));
        panel.setPreferredSize(new Dimension(200, 200));
        panel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        panel.add(get3x3Grid(0, 0));
        panel.add(get3x3Grid(0, 3));
        panel.add(get3x3Grid(0, 6));
        panel.add(get3x3Grid(3, 0));
        panel.add(get3x3Grid(3, 3));
        panel.add(get3x3Grid(3, 6));
        panel.add(get3x3Grid(6, 0));
        panel.add(get3x3Grid(6, 3));
        panel.add(get3x3Grid(6, 6));
        return panel;
    }
    
    private JComponent get3x3Grid(int rowStart, int colStart) {
        JPanel grid = new JPanel(new GridLayout(3, 3, 1, 1));
        grid.add(getGridElement(rowStart, colStart));
        grid.add(getGridElement(rowStart, colStart+1));
        grid.add(getGridElement(rowStart, colStart+2));
        grid.add(getGridElement(rowStart+1, colStart));
        grid.add(getGridElement(rowStart+1, colStart+1));
        grid.add(getGridElement(rowStart+1, colStart+2));
        grid.add(getGridElement(rowStart+2, colStart));
        grid.add(getGridElement(rowStart+2, colStart+1));
        grid.add(getGridElement(rowStart+2, colStart+2));
        return grid;
    }
    
    /**
     * @return a text field for a single number entry
     * @param row the row inside the total grid
     * @param col the column inside the total grid
     */
    private JTextField getGridElement(int row, int col) {
        //alias row and column variables to access them in the inner class
        final int frow = row, fcol = col;
        
        FIELDS[frow * 9 + fcol] = new JTextField(new GridElemDocument(), "", 1);
        FIELDS[frow * 9 + fcol].setPreferredSize(new Dimension(20, 20));
        FIELDS[frow * 9 + fcol].setHorizontalAlignment(JTextField.CENTER);
        FIELDS[frow * 9 + fcol].setBorder(BorderFactory.createLineBorder(Color.GRAY));
        FIELDS[frow * 9 + fcol].setFont(FONT);
        
        // assume a number has been entered when the focus is lost
        FIELDS[frow * 9 + fcol].addFocusListener(new FocusAdapter() {
            public void focusLost(FocusEvent e) {
                if (FIELDS[frow * 9 + fcol].getText().length() > 0) {
                    int inum = Integer.parseInt( FIELDS[frow * 9 + fcol].getText() );
                    GRID[frow * 9 + fcol] = inum;
                }
            }
        });
        
        return FIELDS[frow * 9 + fcol];
    }
    
    /**
     * Document for each Sudoku grid element. Accepts single-digit numerical input.
     */
    private class GridElemDocument extends PlainDocument {
        private final int MAX_LENGTH = 1;
        
        public void insertString(int offset, String str, AttributeSet attr) throws BadLocationException {
            try {
                int num = Integer.parseInt(str);
                if (getLength()+str.length()<=MAX_LENGTH && 1 <= num && num <= 9) {
                    super.insertString(offset, str, attr);
                    return;
                }
            } catch (NumberFormatException exp) { /* ignore and fall through */ }
            
            // if we have reached here, some condition was unsatisfied: beep
            Toolkit.getDefaultToolkit().beep();
        }
    }

}

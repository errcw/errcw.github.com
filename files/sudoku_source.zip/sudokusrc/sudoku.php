<?php

header("Content-type: application/x-java-jnlp-file"); 

echo <<< EOD

<?xml version="1.0" encoding="UTF-8"?>
<jnlp spec="1.0+" 
	  codebase="http://www.eng.uwaterloo.ca/~eworosho/ns/webstart/" 
	  href="sudoku.php"> 

	<information>
		<title>ericw.ca Sudoku Solver</title>
		<vendor>ericw.ca</vendor>
		<homepage href="http://www.ericw.ca"/>
		<description>Sudoku Solver</description>
		<description kind="short">A simple GUI for solving Sudoku puzzles</description>
		<icon href="../images/sudoku_jnlp.jpg"/>
		<offline-allowed/>
	</information>
	
	<resources> 
		<j2se version="1.5+"/> 		
		<jar href="sudoku.jar" main="true"/>
	</resources>
	
	<application-desc main-class="solver.SolverUI"/>
</jnlp>

EOD;

?>